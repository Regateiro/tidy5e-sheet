var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
const CONSTANTS = {
  MODULE_ID: `tidy5e-sheet`
};
CONSTANTS.PATH = `modules/${CONSTANTS.ID}/`;
function RGBAToHexAFromColor(r, g, b, a) {
  r = r.toString(16);
  g = g.toString(16);
  b = b.toString(16);
  a = Math.round(a * 255).toString(16);
  if (r.length == 1) {
    r = "0" + r;
  }
  if (g.length == 1) {
    g = "0" + g;
  }
  if (b.length == 1) {
    b = "0" + b;
  }
  if (a.length == 1) {
    a = "0" + a;
  }
  return "#" + r + g + b + a;
}
__name(RGBAToHexAFromColor, "RGBAToHexAFromColor");
function HexToRGBA(hexCode, opacity = 1) {
  let rgba = _hexToRGBA(hexCode);
  let r = rgba[0];
  let g = rgba[1];
  let b = rgba[2];
  let a = rgba[3];
  return `rgba(${r},${g},${b},${a})`;
}
__name(HexToRGBA, "HexToRGBA");
function _convertHexUnitTo256(hexStr) {
  return parseInt(hexStr.repeat(2 / hexStr.length), 16);
}
__name(_convertHexUnitTo256, "_convertHexUnitTo256");
function _hexToRGBA(hex) {
  const hexArr = hex.slice(1).match(new RegExp(".{2}", "g"));
  const [r, g, b, a] = hexArr.map(_convertHexUnitTo256);
  return [r, g, b, Math.round((a / 256 + Number.EPSILON) * 100) / 100];
}
__name(_hexToRGBA, "_hexToRGBA");
const mapDefaultColorsRGB = {
  t5e_primary_font: "rgb(0, 0, 0)",
  t5e_background: "rgb(236, 233, 223)",
  t5e_faintest_color: "rgb(0, 0, 0)",
  t5e_faint_color: "rgb(0, 0, 0)",
  t5e_light_color: "rgb(0, 0, 0)",
  t5e_primary_color: "rgb(0, 0, 0)",
  t5e_secondary_color: "rgb(0, 0, 0)",
  t5e_tertiary_color: "rgb(0, 0, 0)",
  t5e_primary_accent: "rgb(255, 100, 0)",
  t5e_white: "rgb(255, 255, 255)",
  t5e_faint_white: "rgb(255, 255, 255)",
  t5e_linked_accent: "rgb(0, 255, 0)",
  t5e_unlinked_accent: "rgb(255, 0, 0)",
  t5e_linked_light: "rgb(0, 255, 0)",
  t5e_unlinked_light: "rgb(255, 0, 0)",
  t5e_safe_accent: "rgb(0, 150, 100)",
  t5e_unsafe_accent: "rgb(255, 0, 0)",
  t5e_header_background: "rgb(255, 255, 255)",
  t5e_header_border: "rgb(0, 0, 0)",
  t5e_stat_font: "rgb(236, 233, 223)",
  t5e_prepareable: "rgb(119, 136, 153)",
  t5e_equipped: "rgb(50, 205, 50)",
  t5e_equipped_outline: "rgb(50, 205, 50)",
  t5e_equipped_accent: "rgb(173, 255, 47)",
  t5e_prepared: "rgb(50, 205, 50)",
  t5e_prepared_outline: "rgb(50, 205, 50)",
  t5e_prepared_accent: "rgb(173, 255, 47)",
  t5e_pact: "rgb(250, 0, 180)",
  t5e_pact_outline: "rgb(250, 50, 213)",
  t5e_pact_accent: "rgb(198, 119, 193)",
  t5e_atwill: "rgb(226, 246, 4)",
  t5e_atwill_outline: "rgb(163, 165, 50)",
  t5e_atwill_accent: "rgb(255, 242, 0)",
  t5e_innate: "rgb(255, 0, 0)",
  t5e_innate_outline: "rgb(231, 23, 23)",
  t5e_innate_accent: "rgb(195, 69, 69)",
  t5e_alwaysprepared: "rgb(0, 0, 255)",
  t5e_alwaysprepared_outline: "rgb(65, 105, 225)",
  t5e_alwaysprepared_accent: "rgb(0, 191, 255)",
  t5e_magic_accent: "rgb(255, 255, 0)",
  t5e_faint_magic_accent: "rgb(255, 255, 0)",
  t5e_magic_outline: "rgb(175, 255, 47)",
  t5e_attunement_required: "rgb(205, 92, 92)",
  t5e_icon_attuned: "rgb(0, 0, 0)",
  t5e_xp_bar: "rgb(94, 225, 146)",
  t5e_encumbrance_bar: "rgb(108, 138, 165)",
  t5e_encumbrance_bar_outline: "rgb(205, 228, 255)",
  t5e_encumbrance_outline: "rgb(0, 0, 0)",
  t5e_warning_accent: "rgb(255, 0, 0)",
  t5e_icon_background: "rgb(236, 233, 223)",
  t5e_icon_shadow: "rgb(0, 0, 0)",
  t5e_icon_outline: "rgb(0, 0, 0)",
  t5e_icon_font: "rgb(0, 0, 0)",
  t5e_exhaustion_font: "rgb(0, 0, 0)",
  t5e_icon_hover: "rgb(0, 0, 0)",
  t5e_note_background: "rgb(0, 0, 0)",
  t5e_exhaustion_lvl1: "rgb(255, 230, 0)",
  t5e_exhaustion_lvl2: "rgb(255, 130, 0)",
  t5e_exhaustion_lvl3: "rgb(255, 50, 0)",
  t5e_ability_accent: "darkslategrey",
  t5e_context_outline: "rgb(0, 0, 0)",
  t5e_context_shadow: "rgb(0, 0, 0)",
  t5e_checkbox_font: "rgb(0, 0, 0)",
  t5e_checkbox_outline: "rgb(150, 150, 150)",
  t5e_checkbox_unchecked: "rgb(75, 75, 75)",
  t5e_checkbox_checked: "rgb(0, 255, 0)"
};
const mapDefaultColorsRGBA = {
  t5e_primary_font: "rgba(0, 0, 0, 0.9)",
  t5e_background: "rgba(236, 233, 223, 1)",
  t5e_faintest_color: "rgba(0, 0, 0, 0.05)",
  t5e_faint_color: "rgba(0, 0, 0, 0.1)",
  t5e_light_color: "rgba(0, 0, 0, 0.25)",
  t5e_primary_color: "rgba(0, 0, 0, 0.9)",
  t5e_secondary_color: "rgba(0, 0, 0, 0.65)",
  t5e_tertiary_color: "rgba(0, 0, 0, 0.4)",
  t5e_primary_accent: "rgba(255, 100, 0, 1)",
  t5e_white: "rgba(255, 255, 255, 1)",
  t5e_faint_white: "rgba(255, 255, 255, 0.2)",
  t5e_linked_accent: "rgba(0, 255, 0, 0.75)",
  t5e_unlinked_accent: "rgba(255, 0, 0, 0.75)",
  t5e_linked_light: "rgba(0, 255, 0, 0.4)",
  t5e_unlinked_light: "rgba(255, 0, 0, 0.4)",
  t5e_safe_accent: "rgba(0, 150, 100, 0.6)",
  t5e_unsafe_accent: "rgba(255, 0, 0, 0.6)",
  t5e_header_background: "rgba(255, 255, 255, 0.2)",
  t5e_header_border: "rgba(0, 0, 0, 0.25)",
  t5e_stat_font: "rgba(236, 233, 223, 1)",
  t5e_prepareable: "rgba(119, 136, 153, 1)",
  t5e_equipped: "rgba(50, 205, 50, 0.3)",
  t5e_equipped_outline: "rgba(50, 205, 50, 1)",
  t5e_equipped_accent: "rgba(173, 255, 47, 1)",
  t5e_prepared: "rgba(50, 205, 50, 0.3)",
  t5e_prepared_outline: "rgba(50, 205, 50, 1)",
  t5e_prepared_accent: "rgba(173, 255, 47, 1)",
  t5e_pact: "rgba(250, 0, 180, 0.3)",
  t5e_pact_outline: "rgba(250, 50, 213, 1)",
  t5e_pact_accent: "rgba(198, 119, 193, 1)",
  t5e_atwill: "rgba(226, 246, 4, 0.3)",
  t5e_atwill_outline: "rgba(163, 165, 50, 1)",
  t5e_atwill_accent: "rgba(255, 242, 0, 1)",
  t5e_innate: "rgba(255, 0, 0, 0.3)",
  t5e_innate_outline: "rgba(231, 23, 23, 1)",
  t5e_innate_accent: "rgba(195, 69, 69, 1)",
  t5e_alwaysprepared: "rgba(0, 0, 255, 0.15)",
  t5e_alwaysprepared_outline: "rgba(65, 105, 225, 1)",
  t5e_alwaysprepared_accent: "rgba(0, 191, 255, 1)",
  t5e_magic_accent: "rgba(255, 255, 0, 1)",
  t5e_faint_magic_accent: "rgba(255, 255, 0, 0.6)",
  t5e_magic_outline: "rgba(175, 255, 47, 1)",
  t5e_attunement_required: "rgba(205, 92, 92, 1)",
  t5e_icon_attuned: "rgba(0, 0, 0, 0.4)",
  t5e_xp_bar: "rgba(94, 225, 146, 1)",
  t5e_encumbrance_bar: "rgba(108, 138, 165, 1)",
  t5e_encumbrance_bar_outline: "rgba(205, 228, 255, 1)",
  t5e_encumbrance_outline: "rgba(0, 0, 0, 0.9)",
  t5e_warning_accent: "rgba(255, 0, 0, 0.6)",
  t5e_icon_background: "rgba(236, 233, 223, 1)",
  t5e_icon_shadow: "rgba(0, 0, 0, 0.4)",
  t5e_icon_outline: "rgba(0, 0, 0, 0.4)",
  t5e_icon_font: "rgba(0, 0, 0, 0.4)",
  t5e_exhaustion_font: "rgba(0, 0, 0, 0.4)",
  t5e_icon_hover: "rgba(0, 0, 0, 0.9)",
  t5e_note_background: "rgba(0, 0, 0, 0.9)",
  t5e_exhaustion_lvl1: "rgba(255, 230, 0, 1)",
  t5e_exhaustion_lvl2: "rgba(255, 130, 0, 1)",
  t5e_exhaustion_lvl3: "rgba(255, 50, 0, 1)",
  t5e_ability_accent: "darkslategrey",
  t5e_context_outline: "rgba(0, 0, 0, 0.4)",
  t5e_context_shadow: "rgba(0, 0, 0, 0.65)",
  t5e_checkbox_font: "rgba(0, 0, 0, 0.9)",
  t5e_checkbox_outline: "rgba(150, 150, 150, 1)",
  t5e_checkbox_unchecked: "rgba(75, 75, 75, 1)",
  t5e_checkbox_checked: "rgba(0, 255, 0, 0.3)"
};
const mapDefaultColorsDarkRGBA = {
  t5e_primary_font: "rgba(255, 255, 255, 0.8)",
  t5e_background: "rgba(30, 30, 30, 1)",
  t5e_white: "rgba(0, 0, 0, 1)",
  t5e_primary_color: "rgba(255, 255, 255, 0.8)",
  t5e_secondary_color: "rgba(255, 255, 255, 0.65)",
  t5e_tertiary_color: "rgba(255, 255, 255, 0.4)",
  t5e_light_color: "rgba(255, 255, 255, 0.25)",
  t5e_faint_color: "rgba(255, 255, 255, 0.1)",
  t5e_faintest_color: "rgba(255, 255, 255, 0.05)",
  t5e_ability_accent: "darkslategrey",
  t5e_header_background: "rgba(255, 255, 255, 0.05)",
  t5e_header_border: "rgba(255, 255, 255, 0.25)",
  t5e_primary_accent: "rgba(255, 100, 0, 1)",
  t5e_equipped: "rgba(0, 250, 180, 0.3)",
  t5e_prepared: "rgba(0, 250, 180, 0.3)",
  t5e_pact: "rgba(250, 0, 180, 0.3)",
  t5e_atwill: "rgba(226, 246, 4, 0.3)",
  t5e_innate: "rgba(255, 0, 0, 0.3)",
  t5e_alwaysprepared: "rgba(0, 100, 255, 0.3)",
  t5e_icon_background: "rgb(30, 30, 30)",
  t5e_icon_shadow: "rgba(0, 0, 0, 0.4)",
  t5e_icon_outline: "rgba(0, 0, 0, 0.4)",
  t5e_icon_font: "rgba(255, 255, 255, 0.4)",
  t5e_icon_hover: "rgba(255, 255, 255, 0.8)",
  t5e_warning_accent: "rgba(255, 30, 0, 0.65)",
  t5e_checkbox_font: "rgba(255, 255, 255, 0.8)",
  t5e_checkbox_outline: "rgba(50, 50, 50, 1)",
  t5e_checkbox_unchecked: "rgba(75, 75, 75, 1)",
  t5e_checkbox_checked: "rgba(0, 255, 0, 0.5)",
  /* added from default tidy */
  t5e_equipped_outline: "rgba(50, 205, 50, 1)",
  t5e_equipped_accent: "rgba(173, 255, 47, 1)",
  t5e_prepared_outline: "rgba(50, 205, 50, 1)",
  t5e_prepared_accent: "rgba(173, 255, 47, 1)",
  t5e_pact_outline: "rgba(250, 50, 213, 1)",
  t5e_pact_accent: "rgba(198, 119, 193, 1)",
  t5e_atwill_outline: "rgba(163, 165, 50, 1)",
  t5e_atwill_accent: "rgba(255, 242, 0, 1)",
  t5e_innate_outline: "rgba(231, 23, 23, 1)",
  t5e_innate_accent: "rgba(195, 69, 69, 1)",
  t5e_alwaysprepared_outline: "rgba(65, 105, 225, 1)",
  t5e_alwaysprepared_accent: "rgba(0, 191, 255, 1)",
  t5e_magic_accent: "rgba(255, 255, 0, 1)",
  t5e_faint_magic_accent: "rgba(255, 255, 0, 0.6)",
  t5e_magic_outline: "rgba(175, 255, 47, 1)",
  t5e_attunement_required: "rgba(205, 92, 92, 1)",
  t5e_icon_attuned: "rgba(0, 0, 0, 0.4)",
  t5e_xp_bar: "rgba(94, 225, 146, 1)",
  t5e_encumbrance_bar: "rgba(108, 138, 165, 1)",
  t5e_encumbrance_bar_outline: "rgba(205, 228, 255, 1)",
  t5e_encumbrance_outline: "rgba(0, 0, 0, 0.9)",
  t5e_exhaustion_font: "rgba(0, 0, 0, 0.4)",
  t5e_icon_hover: "rgba(0, 0, 0, 0.9)",
  t5e_note_background: "rgba(0, 0, 0, 0.9)",
  t5e_exhaustion_lvl1: "rgba(255, 230, 0, 1)",
  t5e_exhaustion_lvl2: "rgba(255, 130, 0, 1)",
  t5e_exhaustion_lvl3: "rgba(255, 50, 0, 1)",
  t5e_ability_accent: "darkslategrey",
  t5e_context_outline: "rgba(0, 0, 0, 0.4)",
  t5e_context_shadow: "rgba(0, 0, 0, 0.65)"
};
const mapDefaultColorsDarkRGB = {
  t5e_primary_font: "rgb(255, 255, 255",
  t5e_background: "rgb(30, 30, 30)",
  t5e_white: "rgb(0, 0, 0)",
  t5e_primary_color: "rgb(255, 255, 255)",
  t5e_secondary_color: "rgb(255, 255, 255)",
  t5e_tertiary_color: "rgb(255, 255, 255)",
  t5e_light_color: "rgb(255, 255, 255)",
  t5e_faint_color: "rgb(255, 255, 255)",
  t5e_faintest_color: "rgb(255, 255, 255)",
  t5e_ability_accent: "darkslategrey",
  t5e_header_background: "rgb(255, 255, 255)",
  t5e_header_border: "rgb(255, 255, 255)",
  t5e_primary_accent: "rgb(255, 100, 0)",
  t5e_equipped: "rgb(0, 250, 180)",
  t5e_prepared: "rgb(0, 250, 180)",
  t5e_pact: "rgb(250, 0, 180)",
  t5e_atwill: "rgb(226, 246, 4)",
  t5e_innate: "rgb(255, 0, 0)",
  t5e_alwaysprepared: "rgb(0, 100, 255)",
  t5e_icon_background: "rgb(30, 30, 30)",
  t5e_icon_shadow: "rgb(0, 0, 0)",
  t5e_icon_outline: "rgb(0, 0, 0)",
  t5e_icon_font: "rgb(255, 255, 255)",
  t5e_icon_hover: "rgb(255, 255, 255)",
  t5e_warning_accent: "rgb(255, 30, 0)",
  t5e_checkbox_font: "rgb(255, 255, 255)",
  t5e_checkbox_outline: "rgb(50, 50, 50)",
  t5e_checkbox_unchecked: "rgb(75, 75, 75)",
  t5e_checkbox_checked: "rgb(0, 255, 0)",
  /* added from default tidy */
  t5e_equipped_outline: "rgb(50, 205, 50)",
  t5e_equipped_accent: "rgb(173, 255, 47)",
  t5e_prepared_outline: "rgb(50, 205, 50)",
  t5e_prepared_accent: "rgb(173, 255, 47)",
  t5e_pact_outline: "rgb(250, 50, 213)",
  t5e_pact_accent: "rgb(198, 119, 193)",
  t5e_atwill_outline: "rgb(163, 165, 50)",
  t5e_atwill_accent: "rgb(255, 242, 0)",
  t5e_innate_outline: "rgb(231, 23, 23)",
  t5e_innate_accent: "rgb(195, 69, 69)",
  t5e_alwaysprepared_outline: "rgb(65, 105, 225)",
  t5e_alwaysprepared_accent: "rgb(0, 191, 255)",
  t5e_magic_accent: "rgb(255, 255, 0)",
  t5e_faint_magic_accent: "rgb(255, 255, 0)",
  t5e_magic_outline: "rgb(175, 255, 47)",
  t5e_attunement_required: "rgb(205, 92, 92)",
  t5e_icon_attuned: "rgb(0, 0, 0)",
  t5e_xp_bar: "rgb(94, 225, 146)",
  t5e_encumbrance_bar: "rgb(108, 138, 165)",
  t5e_encumbrance_bar_outline: "rgb(205, 228, 255)",
  t5e_encumbrance_outline: "rgb(0, 0, 0)",
  t5e_exhaustion_font: "rgb(0, 0, 0)",
  t5e_icon_hover: "rgb(0, 0, 0)",
  t5e_note_background: "rgb(0, 0, 0)",
  t5e_exhaustion_lvl1: "rgb(255, 230, 0)",
  t5e_exhaustion_lvl2: "rgb(255, 130, 0)",
  t5e_exhaustion_lvl3: "rgb(255, 50, 0)",
  t5e_ability_accent: "darkslategrey",
  t5e_context_outline: "rgb(0, 0, 0)",
  t5e_context_shadow: "rgb(0, 0, 0)"
};
function applyColorPickerCustomization(html) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "colorPickerEnabled")) {
    const vColorPickerEquipped = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerEquipped"), 0.3);
    const vColorPickerEquippedOutline = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerEquippedOutline"));
    const vColorPickerEquippedAccent = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerEquippedAccent"));
    const vColorPickerPrepared = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPrepared"), 0.3);
    const vColorPickerPreparedOutline = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPreparedOutline"));
    const vColorPickerPreparedAccent = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPreparedAccent"));
    const vColorPickerPact = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPact"), 0.3);
    const vColorPickerPactOutline = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPactOutline"));
    const vColorPickerPactAccent = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerPactAccent"));
    const vColorPickerAtWill = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAtWill"), 0.3);
    const vColorPickerAtWillOutline = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAtWillOutline"));
    const vColorPickerAtWillAccent = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAtWillAccent"));
    const vColorPickerInnate = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerInnate"), 0.3);
    const vColorPickerInnateOutline = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerInnateOutline"));
    const vColorPickerInnateAccent = HexToRGBA(game.settings.get(CONSTANTS.MODULE_ID, "colorPickerInnateAccent"));
    const vColorPickerAlwaysPrepared = HexToRGBA(
      game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAlwaysPrepared"),
      0.3
    );
    const vColorPickerAlwaysPreparedOutline = HexToRGBA(
      game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAlwaysPreparedOutline")
    );
    const vColorPickerAlwaysPreparedAccent = HexToRGBA(
      game.settings.get(CONSTANTS.MODULE_ID, "colorPickerAlwaysPreparedAccent")
    );
    html.find(".tidy5e-sheet #item-info-container-content .info-card.equipped").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_equipped, vColorPickerEquipped) : curValue.replace(mapDefaultColorsRGBA.t5e_equipped, vColorPickerEquipped);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_equipped, vColorPickerEquipped) : newValue.replace(mapDefaultColorsRGB.t5e_equipped, vColorPickerEquipped);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.equipped").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_equipped, vColorPickerEquipped) : curValue.replace(mapDefaultColorsRGBA.t5e_equipped, vColorPickerEquipped);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_equipped, vColorPickerEquipped) : newValue.replace(mapDefaultColorsRGB.t5e_equipped, vColorPickerEquipped);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.equipped").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_equipped_outline, vColorPickerEquippedOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_equipped_outline, vColorPickerEquippedOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_equipped_outline, vColorPickerEquippedOutline) : newValue.replace(mapDefaultColorsRGB.t5e_equipped_outline, vColorPickerEquippedOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_equipped_outline, vColorPickerEquippedOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_equipped_outline, vColorPickerEquippedOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_equipped_outline, vColorPickerEquippedOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_equipped_outline, vColorPickerEquippedOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.equipped .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_equipped_accent, vColorPickerEquippedAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_equipped_accent, vColorPickerEquippedAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_equipped_accent, vColorPickerEquippedAccent) : newValue.replace(mapDefaultColorsRGB.t5e_equipped_accent, vColorPickerEquippedAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_equipped_accent, vColorPickerEquippedAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_equipped_accent, vColorPickerEquippedAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_equipped_accent, vColorPickerEquippedAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_equipped_accent, vColorPickerEquippedAccent);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet #item-info-container-content .info-card.prepared").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_prepared, vColorPickerPrepared) : curValue.replace(mapDefaultColorsRGBA.t5e_prepared, vColorPickerPrepared);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_prepared, vColorPickerPrepared) : newValue.replace(mapDefaultColorsRGB.t5e_prepared, vColorPickerPrepared);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.prepared").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_prepared, vColorPickerPrepared) : curValue.replace(mapDefaultColorsRGBA.t5e_prepared, vColorPickerPrepared);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_prepared, vColorPickerPrepared) : newValue.replace(mapDefaultColorsRGB.t5e_prepared, vColorPickerPrepared);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.prepared").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_prepared_outline, vColorPickerPreparedOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_prepared_outline, vColorPickerPreparedOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_prepared_outline, vColorPickerPreparedOutline) : newValue.replace(mapDefaultColorsRGB.t5e_prepared_outline, vColorPickerPreparedOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_prepared_outline, vColorPickerPreparedOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_prepared_outline, vColorPickerPreparedOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_prepared_outline, vColorPickerPreparedOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_prepared_outline, vColorPickerPreparedOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.prepared .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_prepared_accent, vColorPickerPreparedAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_prepared_accent, vColorPickerPreparedAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_prepared_accent, vColorPickerPreparedAccent) : newValue.replace(mapDefaultColorsRGB.t5e_prepared_accent, vColorPickerPreparedAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_prepared_accent, vColorPickerPreparedAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_prepared_accent, vColorPickerPreparedAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_prepared_accent, vColorPickerPreparedAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_prepared_accent, vColorPickerPreparedAccent);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet #item-info-container-content .info-card.pact").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_pact, vColorPickerPact) : curValue.replace(mapDefaultColorsRGBA.t5e_pact, vColorPickerPact);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_pact, vColorPickerPact) : newValue.replace(mapDefaultColorsRGB.t5e_pact, vColorPickerPact);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.pact").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_pact, vColorPickerPact) : curValue.replace(mapDefaultColorsRGBA.t5e_pact, vColorPickerPact);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_pact, vColorPickerPact) : newValue.replace(mapDefaultColorsRGB.t5e_pact, vColorPickerPact);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.pact").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_pact_outline, vColorPickerPactOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_pact_outline, vColorPickerPactOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_pact_outline, vColorPickerPactOutline) : newValue.replace(mapDefaultColorsRGB.t5e_pact_outline, vColorPickerPactOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_pact_outline, vColorPickerPactOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_pact_outline, vColorPickerPactOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_pact_outline, vColorPickerPactOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_pact_outline, vColorPickerPactOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.pact .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_pact_accent, vColorPickerPactAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_pact_accent, vColorPickerPactAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_pact_accent, vColorPickerPactAccent) : newValue.replace(mapDefaultColorsRGB.t5e_pact_accent, vColorPickerPactAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_pact_accent, vColorPickerPactAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_pact_accent, vColorPickerPactAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_pact_accent, vColorPickerPactAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_pact_accent, vColorPickerPactAccent);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet #item-info-container-content .info-card.atwill").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_atwill, vColorPickerAtWill) : curValue.replace(mapDefaultColorsRGBA.t5e_atwill, vColorPickerAtWill);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_atwill, vColorPickerAtWill) : newValue.replace(mapDefaultColorsRGB.t5e_atwill, vColorPickerAtWill);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.atwill").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_atwill, vColorPickerAtWill) : curValue.replace(mapDefaultColorsRGBA.t5e_atwill, vColorPickerAtWill);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_atwill, vColorPickerAtWill) : newValue.replace(mapDefaultColorsRGB.t5e_atwill, vColorPickerAtWill);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.atwill").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_atwill_outline, vColorPickerAtWillOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_atwill_outline, vColorPickerAtWillOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_atwill_outline, vColorPickerAtWillOutline) : newValue.replace(mapDefaultColorsRGB.t5e_atwill_outline, vColorPickerAtWillOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_atwill_outline, vColorPickerAtWillOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_atwill_outline, vColorPickerAtWillOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_atwill_outline, vColorPickerAtWillOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_atwill_outline, vColorPickerAtWillOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.atwill .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_atwill_accent, vColorPickerAtWillAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_atwill_accent, vColorPickerAtWillAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_atwill_accent, vColorPickerAtWillAccent) : newValue.replace(mapDefaultColorsRGB.t5e_atwill_accent, vColorPickerAtWillAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_atwill_accent, vColorPickerAtWillAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_atwill_accent, vColorPickerAtWillAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_atwill_accent, vColorPickerAtWillAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_atwill_accent, vColorPickerAtWillAccent);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet #item-info-container-content .info-card.innate").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_innate, vColorPickerInnate) : curValue.replace(mapDefaultColorsRGBA.t5e_innate, vColorPickerInnate);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_innate, vColorPickerInnate) : newValue.replace(mapDefaultColorsRGB.t5e_innate, vColorPickerInnate);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.innate").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_innate, vColorPickerInnate) : curValue.replace(mapDefaultColorsRGBA.t5e_innate, vColorPickerInnate);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_innate, vColorPickerInnate) : newValue.replace(mapDefaultColorsRGB.t5e_innate, vColorPickerInnate);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.innate").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_innate_outline, vColorPickerInnateOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_innate_outline, vColorPickerInnateOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_innate_outline, vColorPickerInnateOutline) : newValue.replace(mapDefaultColorsRGB.t5e_innate_outline, vColorPickerInnateOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_innate_outline, vColorPickerInnateOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_innate_outline, vColorPickerInnateOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_innate_outline, vColorPickerInnateOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_innate_outline, vColorPickerInnateOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.innate .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_innate_accent, vColorPickerInnateAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_innate_accent, vColorPickerInnateAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_innate_accent, vColorPickerInnateAccent) : newValue.replace(mapDefaultColorsRGB.t5e_innate_accent, vColorPickerInnateAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_innate_accent, vColorPickerInnateAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_innate_accent, vColorPickerInnateAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_innate_accent, vColorPickerInnateAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_innate_accent, vColorPickerInnateAccent);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet #item-info-container-content .info-card.alwaysprepared").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared, vColorPickerAlwaysPrepared) : curValue.replace(mapDefaultColorsRGBA.t5e_alwaysprepared, vColorPickerAlwaysPrepared);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared, vColorPickerAlwaysPrepared) : newValue.replace(mapDefaultColorsRGB.t5e_alwaysprepared, vColorPickerAlwaysPrepared);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .items-list .item.alwaysprepared").each(function(index, element) {
      const curValue = $(element).css(`background`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared, vColorPickerAlwaysPrepared) : curValue.replace(mapDefaultColorsRGBA.t5e_alwaysprepared, vColorPickerAlwaysPrepared);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared, vColorPickerAlwaysPrepared) : newValue.replace(mapDefaultColorsRGB.t5e_alwaysprepared, vColorPickerAlwaysPrepared);
      $(element).css(`background`, newValue);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.alwaysprepared").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline) : curValue.replace(mapDefaultColorsRGBA.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline) : newValue.replace(mapDefaultColorsRGB.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline) : curValue2.replace(mapDefaultColorsRGBA.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline) : newValue2.replace(mapDefaultColorsRGB.t5e_alwaysprepared_outline, vColorPickerAlwaysPreparedOutline);
      $(element).css(`box-shadow`, newValue2);
    });
    html.find(".tidy5e-sheet .grid-layout .item-list .item.alwaysprepared .item-image").each(function(index, element) {
      const curValue = $(element).css(`-webkit-box-shadow`);
      let newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent) : curValue.replace(mapDefaultColorsRGBA.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent);
      newValue = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent) : newValue.replace(mapDefaultColorsRGB.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent);
      $(element).css(`-webkit-box-shadow`, newValue);
      const curValue2 = $(element).css(`box-shadow`);
      let newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? curValue2.replace(mapDefaultColorsDarkRGBA.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent) : curValue2.replace(mapDefaultColorsRGBA.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent);
      newValue2 = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme") === "dark" ? newValue2.replace(mapDefaultColorsDarkRGB.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent) : newValue2.replace(mapDefaultColorsRGB.t5e_alwaysprepared_accent, vColorPickerAlwaysPreparedAccent);
      $(element).css(`box-shadow`, newValue2);
    });
  }
}
__name(applyColorPickerCustomization, "applyColorPickerCustomization");
function debug(msg, args = "") {
  let isInDebug = false;
  try {
    isInDebug = game.settings.get(CONSTANTS.MODULE_ID, "debug");
  } catch (e) {
    isInDebug = game.modules.get("_dev-mode")?.api?.getPackageDebugValue(CONSTANTS.MODULE_ID);
  }
  if (isInDebug) {
    console.log(`DEBUG | ${CONSTANTS.MODULE_ID} | ${msg}`, args);
    if (game.modules.get("_dev-mode")?.api?.getPackageDebugValue(CONSTANTS.MODULE_ID)) {
      console.log(CONSTANTS.MODULE_ID, "|", ...args);
    }
  }
  return msg;
}
__name(debug, "debug");
function log(message, args = "") {
  message = `${CONSTANTS.MODULE_ID} | ${message}`;
  console.log(message.replace("<br>", "\n"));
  if (game.modules.get("_dev-mode")?.api?.getPackageDebugValue(CONSTANTS.MODULE_ID)) {
    console.log(CONSTANTS.MODULE_ID, "|", ...args);
  }
  return message;
}
__name(log, "log");
function warn(warning, notify = false) {
  warning = `${CONSTANTS.MODULE_ID} | ${warning}`;
  if (notify)
    ui.notifications?.warn(warning);
  console.warn(warning.replace("<br>", "\n"));
  return warning;
}
__name(warn, "warn");
function error(error2, notify = true) {
  error2 = `${CONSTANTS.MODULE_ID} | ${error2}`;
  if (notify)
    ui.notifications?.error(error2);
  return new Error(error2.replace("<br>", "\n"));
}
__name(error, "error");
function settingsList() {
  game.settings.registerMenu(CONSTANTS.MODULE_ID, "userMenu", {
    name: `TIDY5E.Settings.SheetMenu.name`,
    label: "TIDY5E.Settings.SheetMenu.label",
    hint: `TIDY5E.Settings.SheetMenu.hint`,
    icon: "fas fa-cog",
    type: Tidy5eUserSettings,
    restricted: false
  });
  game.settings.registerMenu(CONSTANTS.MODULE_ID, "resetAllSettings", {
    name: `TIDY5E.Settings.Reset.name`,
    hint: `TIDY5E.Settings.Reset.hint`,
    icon: "fas fa-database",
    type: ResetSettingsDialog,
    restricted: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorScheme", {
    name: `${game.i18n.localize("TIDY5E.Settings.SheetTheme.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.SheetTheme.hint"),
    scope: "client",
    config: true,
    type: String,
    choices: {
      default: game.i18n.localize("TIDY5E.Settings.SheetTheme.default"),
      dark: game.i18n.localize("TIDY5E.Settings.SheetTheme.dark")
    },
    default: "default",
    onChange: (data) => {
      data === "dark" ? document.querySelector("html").classList.add("tidy5eDark") : document.querySelector("html").classList.remove("tidy5eDark");
    }
  });
  const colorScheme = game.settings.get(CONSTANTS.MODULE_ID, "colorScheme");
  if (colorScheme === "dark") {
    document.querySelector("html").classList.add("tidy5eDark");
  }
  game.settings.register(CONSTANTS.MODULE_ID, "rightClickDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.RightClickDisabled.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.RightClickDisabled.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "classicControlsEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ClassicControls.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ClassicControls.hint"),
    scope: "client",
    config: false,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hideIconsNextToTheItemName", {
    name: `${game.i18n.localize("TIDY5E.Settings.HideIconsNextToTheItemName.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HideIconsNextToTheItemName.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "itemCardsForAllItems", {
    name: `${game.i18n.localize("TIDY5E.Settings.ItemCardsForAllItems.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ItemCardsForAllItems.hint"),
    scope: "client",
    config: true,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "itemCardsForNpcs", {
    name: `${game.i18n.localize("TIDY5E.Settings.ItemCardsForNpcs.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ItemCardsForNpcs.hint"),
    scope: "world",
    config: true,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "itemCardsAreFloating", {
    name: `${game.i18n.localize("TIDY5E.Settings.ItemCardsAreFloating.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ItemCardsAreFloating.hint"),
    scope: "client",
    config: true,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "itemCardsDelay", {
    name: `${game.i18n.localize("TIDY5E.Settings.ItemCardsDelay.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ItemCardsDelay.hint"),
    scope: "client",
    config: true,
    default: 300,
    type: Number
  });
  game.settings.register(CONSTANTS.MODULE_ID, "itemCardsFixKey", {
    name: `${game.i18n.localize("TIDY5E.Settings.ItemCardsFixKey.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ItemCardsFixKey.hint"),
    scope: "world",
    config: false,
    default: "x",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_ID, "contextRollButtons", {
    name: `${game.i18n.localize("TIDY5E.Settings.RollButtonsToCard.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.RollButtonsToCard.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "traitLabelsEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.TraitLabels.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.TraitLabels.hint"),
    scope: "world",
    config: false,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "journalTabDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.JournalTab.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.JournalTab.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "journalTabNPCDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.JournalTabNPCDisabled.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.JournalTabNPCDisabled.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "classListDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ClassList.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ClassList.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "inspirationAnimationDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.InspirationAnimation.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.InspirationAnimation.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hideIfZero", {
    name: `${game.i18n.localize("TIDY5E.Settings.HideIfZero.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HideIfZero.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "inspirationOnHover", {
    name: `${game.i18n.localize("TIDY5E.Settings.InspirationOnHover.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.InspirationOnHover.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionOnHover", {
    name: `${game.i18n.localize("TIDY5E.Settings.ExhaustionOnHover.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ExhaustionOnHover.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpBarDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpBar.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpBar.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlay.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlay.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "traitsTogglePc", {
    name: `${game.i18n.localize("TIDY5E.Settings.TraitsTogglePc.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.TraitsTogglePc.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "traitsMovedBelowResource", {
    name: `${game.i18n.localize("TIDY5E.Settings.TraitsMovedBelowResource.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.TraitsMovedBelowResource.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "ammoEquippedOnly", {
    name: `${game.i18n.localize("TIDY5E.Settings.AmmoEquippedOnly.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.AmmoEquippedOnly.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "traitsMovedBelowResourceNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.TraitsMovedBelowResource.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.TraitsMovedBelowResource.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpBarDisabledNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpBar.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpBar.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayDisabledNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlay.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlay.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "traitsAlwaysShownNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.TraitsAlwaysShown.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.TraitsAlwaysShown.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "skillsAlwaysShownNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.SkillsAlwaysShown.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.SkillsAlwaysShown.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hideSpellbookTabNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.SkillsAlwaysShown.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.SkillsAlwaysShown.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpBarDisabledVehicle", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpBar.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpBar.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayDisabledVehicle", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlay.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlay.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "playerNameEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.PlayerName.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.PlayerName.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "expandedSheetEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ExpandedSheet.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ExpandedSheet.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "portraitStyle", {
    name: `${game.i18n.localize("TIDY5E.Settings.PortraitStyle.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.PortraitStyle.hint"),
    scope: "world",
    config: false,
    type: String,
    choices: {
      default: game.i18n.localize("TIDY5E.Settings.PortraitStyle.default"),
      pc: game.i18n.localize("TIDY5E.Settings.PortraitStyle.pc"),
      npc: game.i18n.localize("TIDY5E.Settings.PortraitStyle.npc"),
      all: game.i18n.localize("TIDY5E.Settings.PortraitStyle.all")
    },
    default: "all",
    onChange: (data) => {
      if (data == "npc" || data == "all") {
        $(".tidy5e-sheet.tidy5e-npc .profile").addClass("roundPortrait");
        $(".tidy5e-sheet.tidy5e-vehicle .profile").addClass("roundPortrait");
      }
      if (data == "pc" || data == "all") {
        $(".tidy5e-sheet .profile").addClass("roundPortrait");
        $(".tidy5e-sheet.tidy5e-npc .profile").removeClass("roundPortrait");
        $(".tidy5e-sheet.tidy5e-vehicle .profile").removeClass("roundPortrait");
      }
      if (data == "default") {
        $(".tidy5e-sheet .profile").removeClass("roundPortrait");
        $(".tidy5e-sheet.tidy5e-npc .profile").removeClass("roundPortrait");
        $(".tidy5e-sheet.tidy5e-vehicle .profile").removeClass("roundPortrait");
      }
    }
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayBorder", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.hint"),
    scope: "world",
    config: false,
    default: 0,
    type: Number,
    onChange: (data) => {
      $(".system-dnd5e").get(0).style.setProperty("--pc-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorder") + "px");
    }
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayBorderNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.hint"),
    scope: "world",
    config: false,
    default: 0,
    type: Number,
    onChange: (data) => {
      $(".system-dnd5e").get(0).style.setProperty("--npc-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderNpc") + "px");
    }
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hpOverlayBorderVehicle", {
    name: `${game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HpOverlayBorder.hint"),
    scope: "world",
    config: false,
    default: 0,
    type: Number,
    onChange: (data) => {
      $(".system-dnd5e").get(0).style.setProperty("--vehicle-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderVehicle") + "px");
    }
  });
  game.settings.register(CONSTANTS.MODULE_ID, "editTotalLockEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.EditTotalLock.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EditTotalLock.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "editGmAlwaysEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.EditGmAlways.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EditGmAlways.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "editEffectsGmOnlyEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.EditEffectsGmOnly.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EditEffectsGmOnly.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hiddenDeathSavesEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.HiddenDeathSaves.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HiddenDeathSaves.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hideSpellSlotMarker", {
    name: `${game.i18n.localize("TIDY5E.Settings.HideSpellSlotMarker.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.HideSpellSlotMarker.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enableSpellLevelButtons", {
    name: `${game.i18n.localize("TIDY5E.Settings.EnableSpellLevelButtons.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.EnableSpellLevelButtons.hint")}`,
    scope: "world",
    config: false,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hideStandardEncumbranceBar", {
    name: `${game.i18n.localize("TIDY5E.Settings.HideStandardEncumbranceBar.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.HideStandardEncumbranceBar.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "quantityAlwaysShownEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.QuantityAlwaysShown.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.QuantityAlwaysShown.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.hint"),
    scope: "world",
    config: false,
    choices: {
      default: game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.default"),
      tidy5e: game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.default"),
      dfredce: game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.dfredce"),
      cub: game.i18n.localize("TIDY5E.Settings.ExhaustionEffects.cub")
    },
    type: String,
    default: "default"
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionEffectIcon", {
    name: `${game.i18n.localize("TIDY5E.Settings.CustomExhaustionIcon.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.CustomExhaustionIcon.hint"),
    scope: "world",
    config: false,
    type: String,
    default: "modules/tidy5e-sheet/images/exhaustion.svg"
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionEffectCustom", {
    name: `${game.i18n.localize("TIDY5E.Settings.CustomExhaustionEffect.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.CustomExhaustionEffect.hint"),
    scope: "world",
    config: false,
    default: "Exhaustion",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionEffectCustomTiers", {
    name: `${game.i18n.localize("TIDY5E.Settings.CustomExhaustionEffect.tiers")}`,
    hint: game.i18n.localize("TIDY5E.Settings.CustomExhaustionEffect.hint"),
    scope: "world",
    config: false,
    default: 5,
    type: Number
  });
  game.settings.register(CONSTANTS.MODULE_ID, "exhaustionDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ExhaustionDisabled.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ExhaustionDisabled.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "inspirationDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.InspirationDisabled.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.InspirationDisabled.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "restingForNpcsEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.RestingForNpcs.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.RestingForNpcs.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "restingForNpcsChatDisabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.RestingForNpcsChat.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.RestingForNpcsChat.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "linkMarkerNpc", {
    name: `${game.i18n.localize("TIDY5E.Settings.LinkMarker.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.LinkMarker.hint"),
    scope: "world",
    config: false,
    type: String,
    choices: {
      default: game.i18n.localize("TIDY5E.Settings.LinkMarker.default"),
      unlinked: game.i18n.localize("TIDY5E.Settings.LinkMarker.unlinked"),
      both: game.i18n.localize("TIDY5E.Settings.LinkMarker.both")
    },
    default: "default"
  });
  game.settings.register(CONSTANTS.MODULE_ID, "activeEffectsMarker", {
    name: `${game.i18n.localize("TIDY5E.Settings.ActiveEffectsMarker.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.ActiveEffectsMarker.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enableActionListOnFavoritePanel", {
    name: `${game.i18n.localize("TIDY5E.Settings.EnableActionListOnFavoritePanel.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EnableActionListOnFavoritePanel.hint"),
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "defaultActionsTab", {
    name: `${game.i18n.localize("TIDY5E.Settings.defaultActionsTab.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.hint"),
    scope: "world",
    config: false,
    type: String,
    choices: {
      default: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.default"),
      attributes: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.attributes"),
      inventory: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.inventory"),
      spellbook: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.spellbook"),
      features: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.features"),
      effects: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.effects"),
      biography: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.biography"),
      journal: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.journal"),
      actions: game.i18n.localize("TIDY5E.Settings.defaultActionsTab.actions")
    },
    default: "default"
  });
  game.settings.register(CONSTANTS.MODULE_ID, "playerSheetWidth", {
    name: `${game.i18n.localize("TIDY5E.Settings.playerSheetWidth")}`,
    scope: "client",
    config: false,
    type: Number,
    default: 740
  });
  game.settings.register(CONSTANTS.MODULE_ID, "npsSheetWidth", {
    name: `${game.i18n.localize("TIDY5E.Settings.npsSheetWidth")}`,
    scope: "client",
    config: false,
    type: Number,
    default: 740
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enablePermanentUnlockOnNPCIfYouAreGM", {
    name: `${game.i18n.localize("TIDY5E.Settings.EnablePermanentUnlockOnNPCIfYouAreGM.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EnablePermanentUnlockOnNPCIfYouAreGM.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "vehicleSheetWidth", {
    name: `${game.i18n.localize("TIDY5E.Settings.vehicleSheetWidth")}`,
    scope: "client",
    config: false,
    type: Number,
    default: 740
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enablePermanentUnlockOnVehicleIfYouAreGM", {
    name: `${game.i18n.localize("TIDY5E.Settings.EnablePermanentUnlockOnVehicleIfYouAreGM.name")}`,
    hint: game.i18n.localize("TIDY5E.Settings.EnablePermanentUnlockOnVehicleIfYouAreGM.hint"),
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lazyMoneyEnable", {
    name: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyEnable.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyEnable.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lazyMoneyAddConvert", {
    name: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyAddConvert.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyAddConvert.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lazyMoneyIgnoreElectrum", {
    name: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyIgnoreElectrum.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyIgnoreElectrum.hint")}`,
    scope: "world",
    config: false,
    default: true,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lazyMoneyChatLog", {
    name: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyChatLog.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LazyMoneyChatLog.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enableSortFavoritesItemsAlphabetically", {
    name: `${game.i18n.localize("TIDY5E.Settings.EnableSortFavoritesItemsAlphabetically.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.EnableSortFavoritesItemsAlphabetically.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockMoneyChanges", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockMoneyChanges.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockMoneyChanges.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockExpChanges", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockExpChanges.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockExpChanges.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockHpMaxChanges", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockHpMaxChanges.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockHpMaxChanges.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockLevelSelector", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockLevelSelector.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockLevelSelector.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockConfigureSheet", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockConfigureSheet.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockConfigureSheet.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lockItemQuantity", {
    name: `${game.i18n.localize("TIDY5E.Settings.LockItemQuantity.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.LockItemQuantity.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "allowCantripToBePreparedOnContext", {
    name: `${game.i18n.localize("TIDY5E.Settings.AllowCantripToBePreparedOnContext.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.AllowCantripToBePreparedOnContext.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "spellClassFilterSelect", {
    name: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterSelect.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterSelect.hint")}`,
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "spellClassFilterIconReplace", {
    name: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterIconReplace.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterIconReplace.hint")}`,
    scope: "client",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "spellClassFilterAdditionalClasses", {
    name: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterAdditionalClasses.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.SpellClassFilterAdditionalClasses.hint")}`,
    scope: "client",
    config: false,
    default: "",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_ID, "allowHpMaxOverride", {
    name: `${game.i18n.localize("TIDY5E.Settings.AllowHpMaxOverride.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.AllowHpMaxOverride.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "allowHpConfigOverride", {
    name: `${game.i18n.localize("TIDY5E.Settings.AllowHpConfigOverride.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.AllowHpConfigOverride.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "betterAttackDialog", {
    name: `${game.i18n.localize("TIDY5E.Settings.BetterAttackDialog.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.BetterAttackDialog.hint")}`,
    scope: "world",
    config: false,
    default: true,
    type: Boolean,
    onChange: (newValue) => {
      const style = `<style id="tidy5e-better-attack">
			.dialog-button.default.advantage {
			border: 2px groove green !important;
			}
			.dialog-button.default.disadvantage {
			border: 2px groove red !important;
			}
			</style>`;
      const styleElement = $("#tidy5e-sheet-better-attack");
      if (styleElement.length == 0 && newValue) {
        $("body").append(style);
      } else if (styleElement.length != 0 && !newValue) {
        styleElement.remove();
      }
    }
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerEnabled", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEnabled.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEnabled.hint")}`,
    scope: "client",
    type: Boolean,
    default: false,
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerEquipped", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquipped.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquipped.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(50, 205, 50, 0.3),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerEquippedOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquippedOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquippedOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(50, 205, 50, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerEquippedAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquippedAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerEquippedAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(173, 255, 47, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPrepared", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPrepared.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPrepared.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(50, 205, 50, 0.3),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPreparedOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPreparedOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPreparedOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(50, 205, 50, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPreparedAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPreparedAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPreparedAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(173, 255, 47, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPact", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPact.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPact.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(250, 0, 180, 0.3),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPactOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPactOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPactOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(250, 50, 213, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerPactAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPactAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerPactAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(198, 119, 193, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAtWill", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWill.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWill.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(226, 246, 4, 0.3),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAtWillOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWillOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWillOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(163, 165, 50, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAtWillAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWillAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAtWillAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(255, 242, 0, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerInnate", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnate.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnate.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(255, 0, 0, 0.3),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerInnateOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnateOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnateOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(231, 23, 23, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerInnateAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnateAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerInnateAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(195, 69, 69, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAlwaysPrepared", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPrepared.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPrepared.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(0, 0, 255, 0.15),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAlwaysPreparedOutline", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPreparedOutline.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPreparedOutline.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(65, 105, 225, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "colorPickerAlwaysPreparedAccent", {
    name: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPreparedAccent.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.ColorPickerAlwaysPreparedAccent.hint")}`,
    scope: "client",
    type: String,
    default: RGBAToHexAFromColor(0, 191, 255, 1),
    config: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hbEnableUpcastFreeSpell", {
    name: `${game.i18n.localize("TIDY5E.Settings.HBEnableUpcastFreeSpell.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.HBEnableUpcastFreeSpell.hint")}`,
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  });
  game.settings.register(CONSTANTS.MODULE_ID, "hbSetFeaturesForUpcastFreeSpell", {
    name: `${game.i18n.localize("TIDY5E.Settings.HBSetFeaturesForUpcastFreeSpell.name")}`,
    hint: `${game.i18n.localize("TIDY5E.Settings.HBSetFeaturesForUpcastFreeSpell.hint")}`,
    scope: "world",
    config: false,
    default: "",
    type: String
  });
  game.settings.register(CONSTANTS.MODULE_ID, "debug", {
    name: `TIDY5E.Settings.Debug.name`,
    hint: `TIDY5E.Settings.Debug.hint`,
    scope: "client",
    config: true,
    default: false,
    type: Boolean
  });
}
__name(settingsList, "settingsList");
class ResetSettingsDialog extends FormApplication {
  static {
    __name(this, "ResetSettingsDialog");
  }
  constructor(...args) {
    super(...args);
    return new Dialog({
      title: game.i18n.localize(`TIDY5E.Settings.Reset.dialogs.title`),
      content: '<p style="margin-bottom:1rem;">' + game.i18n.localize(`TIDY5E.Settings.Reset.dialogs.content`) + "</p>",
      buttons: {
        confirm: {
          icon: '<i class="fas fa-check"></i>',
          label: game.i18n.localize(`TIDY5E.Settings.Reset.dialogs.confirm`),
          callback: async () => {
            for (let setting of game.settings.storage.get("world").filter((setting2) => setting2.key.startsWith(`${CONSTANTS.MODULE_ID}.`))) {
              log(`Reset setting '${setting.key}'`);
              await setting.delete();
            }
          }
        },
        cancel: {
          icon: '<i class="fas fa-times"></i>',
          label: game.i18n.localize(`TIDY5E.Settings.Reset.dialogs.cancel`)
        }
      },
      default: "cancel"
    });
  }
  async _updateObject(event, formData) {
  }
}
class Tidy5eUserSettings extends FormApplication {
  static {
    __name(this, "Tidy5eUserSettings");
  }
  static isInitialized = false;
  static init() {
    if (!Tidy5eUserSettings.isInitialized) {
      settingsList();
      Tidy5eUserSettings.isInitialized = true;
    }
  }
  // settings template
  static get defaultOptions() {
    return {
      ...super.defaultOptions,
      template: "modules/tidy5e-sheet/templates/settings.html",
      height: 500,
      title: game.i18n.localize("TIDY5E.Settings.SheetMenu.title"),
      width: 600,
      classes: ["tidy5e", "settings"],
      tabs: [
        {
          navSelector: ".tabs",
          contentSelector: "form",
          initial: "Players"
        }
      ],
      submitOnClose: true
    };
  }
  constructor(object = {}, options) {
    super(object, options);
  }
  _getHeaderButtons() {
    let btns = super._getHeaderButtons();
    btns[0].label = "Close";
    return btns;
  }
  getSettingsData() {
    const settings = [
      "ammoEquippedOnly",
      "activeEffectsMarker",
      "classListDisabled",
      "contextRollButtons",
      "defaultActionsTab",
      "editGmAlwaysEnabled",
      "editEffectsGmOnlyEnabled",
      "editTotalLockEnabled",
      "exhaustionEffectsEnabled",
      "exhaustionEffectIcon",
      "exhaustionEffectCustom",
      "exhaustionEffectCustomTiers",
      "exhaustionOnHover",
      "exhaustionDisabled",
      "expandedSheetEnabled",
      "hideIfZero",
      "hiddenDeathSavesEnabled",
      "hideSpellSlotMarker",
      "hideStandardEncumbranceBar",
      "enableSpellLevelButtons",
      "hpBarDisabled",
      "hpBarDisabledNpc",
      "hpBarDisabledVehicle",
      "hpOverlayDisabled",
      "hpOverlayDisabledNpc",
      "hpOverlayDisabledVehicle",
      "hpOverlayBorder",
      "hpOverlayBorderNpc",
      "hpOverlayBorderVehicle",
      "inspirationAnimationDisabled",
      "inspirationDisabled",
      "inspirationOnHover",
      "itemCardsAreFloating",
      "itemCardsDelay",
      "itemCardsFixKey",
      "itemCardsForAllItems",
      "journalTabDisabled",
      "journalTabNPCDisabled",
      "linkMarkerNpc",
      "playerNameEnabled",
      "portraitStyle",
      "quantityAlwaysShownEnabled",
      "restingForNpcsEnabled",
      "restingForNpcsChatDisabled",
      "rightClickDisabled",
      "classicControlsEnabled",
      "hideIconsNextToTheItemName",
      "skillsAlwaysShownNpc",
      "hideSpellbookTabNpc",
      "playerSheetWidth",
      "npsSheetWidth",
      "enablePermanentUnlockOnNPCIfYouAreGM",
      "vehicleSheetWidth",
      "enablePermanentUnlockOnVehicleIfYouAreGM",
      "traitLabelsEnabled",
      "traitsAlwaysShownNpc",
      "traitsMovedBelowResource",
      "traitsMovedBelowResourceNpc",
      "traitsTogglePc",
      // REMOVED 2.1.5 do the job now
      // "lazyHpAndExpEnable",
      // "lazyHpForceHpValueLimit1",
      // "lazyHpForceHpValueLimit2",
      "lazyMoneyEnable",
      "lazyMoneyAddConvert",
      "lazyMoneyIgnoreElectrum",
      "lazyMoneyChatLog",
      "enableSortFavoritesItemsAlphabetically",
      "allowCantripToBePreparedOnContext",
      "enableActionListOnFavoritePanel",
      "spellClassFilterSelect",
      "spellClassFilterIconReplace",
      "spellClassFilterAdditionalClasses",
      "allowHpMaxOverride",
      "allowHpConfigOverride",
      "betterAttackDialog",
      "lockMoneyChanges",
      "lockExpChanges",
      "lockHpMaxChanges",
      "lockLevelSelector",
      "lockConfigureSheet",
      "lockItemQuantity",
      "colorPickerEnabled",
      "colorPickerEquipped",
      "colorPickerEquippedOutline",
      "colorPickerEquippedAccent",
      "colorPickerPrepared",
      "colorPickerPreparedOutline",
      "colorPickerPreparedAccent",
      "colorPickerPact",
      "colorPickerPactOutline",
      "colorPickerPactAccent",
      "colorPickerAtWill",
      "colorPickerAtWillOutline",
      "colorPickerAtWillAccent",
      "colorPickerInnate",
      "colorPickerInnateOutline",
      "colorPickerInnateAccent",
      "colorPickerAlwaysPrepared",
      "colorPickerAlwaysPreparedOutline",
      "colorPickerAlwaysPreparedAccent",
      "hbEnableUpcastFreeSpell",
      "hbSetFeaturesForUpcastFreeSpell",
      "debug"
    ];
    let data = {};
    settings.forEach((setting) => {
      data[setting] = { value: game.settings.get(CONSTANTS.MODULE_ID, setting) };
    });
    return data;
  }
  getData() {
    let data = super.getData();
    data.settings = this.getSettingsData();
    return data;
  }
  activateListeners(html) {
    super.activateListeners(html);
    let exhaustionEffectSelect = html.find("select#exhaustionEffectsEnabled");
    let exhaustionSelected = $(exhaustionEffectSelect).val();
    switch (exhaustionSelected) {
      case "default": {
        html.find("input#exhaustionEffectIcon").closest(".setting").hide();
        html.find("input#exhaustionEffectCustom").closest(".setting").hide();
        break;
      }
      case "tidy5e": {
        html.find("input#exhaustionEffectCustom").closest(".setting").hide();
        break;
      }
      case "dfredce": {
        html.find("input#exhaustionEffectIcon").closest(".setting").hide();
        break;
      }
      case "cub": {
        html.find("input#exhaustionEffectIcon").closest(".setting").hide();
        break;
      }
    }
    exhaustionEffectSelect.on("change", function(e) {
      html.find("input#exhaustionEffectIcon").closest(".setting").hide();
      html.find("input#exhaustionEffectCustom").closest(".setting").hide();
      let value = e.target.value;
      if (value == "tidy5e") {
        html.find("input#exhaustionEffectIcon").closest(".setting").show();
      } else if (value == "custom") {
        html.find("input#exhaustionEffectCustom").closest(".setting").show();
      }
    });
    html.find("input#exhaustionEffectIcon").on("change", function(e) {
      if (e.target.value == "" || e.target.value == null) {
        e.target.value = "modules/tidy5e-sheet/images/exhaustion.svg";
      }
    });
  }
  redrawOpenSheets() {
    game.actors.filter((a) => a.sheet.rendered).forEach((a) => a.sheet.render(true));
  }
  _updateObject(ev, formData) {
    const data = expandObject(formData);
    let settingsUpdated = false;
    for (let key in data) {
      let oldSetting = game.settings.get(CONSTANTS.MODULE_ID, key);
      let newSetting = data[key];
      if (oldSetting == newSetting)
        continue;
      game.settings.set(CONSTANTS.MODULE_ID, key, data[key]);
      settingsUpdated = true;
    }
    if (settingsUpdated) {
      this.redrawOpenSheets();
    }
  }
}
function Tidy5eSettingsGmOnlySetup() {
  debug(`settings | Tidy5eSettingsGmOnlySetup | start`);
  if (!game.user.isGM) {
    document.querySelectorAll(".tidy5e.settings .gm-only").forEach(function(el) {
      el.remove();
    });
  }
  debug(`settings | Tidy5eSettingsGmOnlySetup | end`);
}
__name(Tidy5eSettingsGmOnlySetup, "Tidy5eSettingsGmOnlySetup");
async function updateExhaustion(actorEntity) {
  const actorC = game.actors.get(actorEntity._id);
  if (!actorC) {
    warn(`The actor with id '${actorEntity._id}' must exists for apply a Exhaustion`);
    return;
  }
  if (actorC.type !== "character" && actorC.type !== "npc") {
    warn(`The actor with id '${actorEntity._id}' must be a Character or a NPC for apply a Exhaustion`);
    return;
  }
  let exhaustion = 0;
  if (actorC.type === "character") {
    exhaustion = actorEntity.system.attributes.exhaustion ?? 0;
  } else if (actorC.type === "npc") {
    exhaustion = actorEntity.flags[CONSTANTS.MODULE_ID]?.exhaustion ?? 0;
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "tidy5e") {
    let icon = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectIcon");
    let currentExhaustion;
    let exhaustionPresent = null;
    let effectName = `${game.i18n.localize("DND5E.ConExhaustion")} ${game.i18n.localize(
      "DND5E.AbbreviationLevel"
    )} ${exhaustion}`;
    let exhaustionSet = [];
    let movementSet = ["walk", "swim", "fly", "climb", "burrow"];
    if (exhaustion != 0) {
      if (exhaustion > 0) {
        let effect = {
          key: "flags.midi-qol.disadvantage.ability.check.all",
          value: true,
          mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
          priority: 20
        };
        exhaustionSet.push(effect);
      }
      if (exhaustion > 1 && exhaustion < 5) {
        if (actorEntity.system?.attributes?.movement) {
          movementSet = [];
          Object.entries(actorEntity.system.attributes.movement).forEach((speed) => {
            if (speed[0] == "hover" || speed[0] == "units") {
              return;
            }
            if (speed[1] > 0) {
              movementSet.push(speed[0]);
            }
          });
        }
        movementSet.forEach((el) => {
          const changeKey = "system.attributes.movement." + el;
          let effect = {
            key: changeKey,
            value: "0.5",
            mode: CONST.ACTIVE_EFFECT_MODES.MULTIPLY,
            priority: 20
          };
          exhaustionSet.push(effect);
        });
      }
      if (exhaustion > 2) {
        let effect = {
          key: "flags.midi-qol.disadvantage.ability.save.all",
          value: true,
          mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
          priority: 20
        };
        exhaustionSet.push(effect);
        effect = {
          key: "flags.midi-qol.disadvantage.attack.all",
          value: true,
          mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
          priority: 20
        };
        exhaustionSet.push(effect);
      }
      if (exhaustion > 3) {
        let effect = {
          key: "system.attributes.hp.max",
          value: "0.5",
          mode: 1,
          priority: 20
        };
        exhaustionSet.push(effect);
      }
      if (exhaustion > 4) {
        if (actorEntity.system?.attributes?.movement) {
          movementSet = [];
          Object.entries(actorEntity.system.attributes.movement).forEach((speed) => {
            if (speed[0] == "hover" || speed[0] == "units") {
              return;
            }
            if (speed[1] > 0) {
              movementSet.push(speed[0]);
            }
          });
        }
        movementSet.forEach((el) => {
          const changeKey = "system.attributes.movement." + el;
          let effect = {
            key: changeKey,
            value: "0",
            mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
            priority: 20
          };
          exhaustionSet.push(effect);
        });
      }
      if (exhaustion > 5) {
        let effect = {
          key: "system.attributes.hp.value",
          value: "0",
          mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
          priority: 20
        };
        exhaustionSet.push(effect);
      }
    }
    for (const effectEntity of actorEntity.effects) {
      if (typeof effectEntity.getFlag(CONSTANTS.MODULE_ID, "exhaustion") === "number") {
        exhaustionPresent = effectEntity;
        currentExhaustion = effectEntity.getFlag(CONSTANTS.MODULE_ID, "exhaustion");
        debug(`tidy5e-exhaustion | updateExhaustion | currentExhaustion: ${currentExhaustion}`);
        if (currentExhaustion != exhaustion) {
          await exhaustionPresent.delete();
          createExhaustionEffect();
        }
      }
    }
    if (!exhaustionPresent) {
      createExhaustionEffect();
    }
    async function createExhaustionEffect() {
      if (exhaustion > 0) {
        debug(`tidy5e-exhaustion | createExhaustionEffect | create Effect exhaustion lv: ${exhaustion}`);
        let effectChange = {
          disabled: false,
          label: effectName,
          icon,
          changes: exhaustionSet,
          duration: { seconds: 31536e3 },
          flags: {
            [CONSTANTS.MODULE_ID]: {
              exhaustion
            }
          },
          origin: `Actor.${actorEntity._id}`
        };
        await actorEntity.createEmbeddedDocuments("ActiveEffect", [effectChange]);
        await actorEntity.applyActiveEffects();
      }
    }
    __name(createExhaustionEffect, "createExhaustionEffect");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "dfredce") {
    if (game.modules.get("dfreds-convenient-effects")?.active) {
      const levels = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustomTiers");
      const effectName = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustom");
      const id = actorEntity._id;
      const tokens = canvas.tokens.placeables;
      const index = tokens.findIndex((x) => x.actor._id === id);
      const token = tokens[index];
      const actorToCheck = token && token.actor ? token.actor : actorEntity;
      let effectNameCustom = `${effectName} ${exhaustion}`;
      for (let i = 1; i <= levels; i++) {
        let tier = `${effectName} ${i}`;
        if (tier != effectNameCustom) {
          if (game.dfreds.effectInterface.hasEffectApplied(tier, actorToCheck.uuid)) {
            debug(`tidy5e-exhaustion | createExhaustionEffect | tier: ${tier}`);
            const contextEffect = {
              effectName: tier,
              uuid: actorToCheck.uuid,
              origin: void 0
            };
            await game.dfreds.effectInterface.removeEffect(contextEffect);
          }
        }
      }
      if (exhaustion != 0) {
        let effectToCheck = game.dfreds.effectInterface.findEffectByName(effectNameCustom);
        if (!effectToCheck) {
          return;
        }
        if (game.dfreds.effectInterface.hasEffectApplied(effectNameCustom, actorToCheck.uuid)) {
          return;
        }
        const contextEffect = {
          effectName: effectNameCustom,
          uuid: actorToCheck.uuid,
          origin: void 0,
          overlay: false,
          metadata: void 0
        };
        await game.dfreds.effectInterface.addEffect(contextEffect);
      }
    } else {
      warn(
        `${game.i18n.localize(
          "The module 'Dfreds Convenient Effects' is not active, but the module setting 'Auto Exhaustion effects' is enabled"
        )}`,
        true
      );
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "cub") {
    if (game.modules.get("combat-utility-belt")?.active) {
      const levels = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustomTiers");
      const effectName = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustom");
      const id = actorEntity._id;
      const tokens = canvas.tokens.placeables;
      const index = tokens.findIndex((x) => x.actor._id === id);
      const token = tokens[index];
      let effectNameCustom = `${effectName} ${exhaustion}`;
      for (let i = 1; i <= levels; i++) {
        let tier = `${effectName} ${i}`;
        if (tier != effectNameCustom) {
          debug(`tidy5e-exhaustion | createExhaustionEffect | tier: ${tier}`);
          await game.cub.removeCondition(tier, [token], { warn: false });
        }
      }
      if (exhaustion != 0) {
        if (index == -1) {
          ui.notifications.warn(`${game.i18n.localize("TIDY5E.Settings.CustomExhaustionEffect.warning")}`);
          return;
        }
        game.cub.addCondition(effectNameCustom, [token], { warn: false });
      }
    } else {
      warn(
        `${game.i18n.localize(
          "The module 'CUB' is not active, but the module setting 'Auto Exhaustion effects' is enabled"
        )}`,
        true
      );
    }
  }
}
__name(updateExhaustion, "updateExhaustion");
function Tidy5eExhaustionDnd5eRestCompleted(actorEntity, data) {
  debug(`tidy5e-exhaustion | Tidy5eExhaustionDnd5eRestCompleted | start`);
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "default") {
    return;
  }
  let actor2 = game.actors.get(actorEntity._id);
  if (data.longRest) {
    if (actor2.type === "character") {
      let exhaustion = actorEntity.system.attributes.exhaustion;
      if (exhaustion > 0) {
        actor2.update({ "system.attributes.exhaustion": exhaustion - 1 });
      }
    } else if (actor2.type === "npc") {
      let exhaustion = actorEntity.flags[CONSTANTS.MODULE_ID].exhaustion;
      if (exhaustion > 0) {
        actor2.update({ "flags.tidy5e-sheet.exhaustion": exhaustion - 1 });
      }
    } else {
      warn(`Long rest is not supported for actor ype '${actor2.type}'`);
    }
  }
  debug(`tidy5e-exhaustion | Tidy5eExhaustionDnd5eRestCompleted | end`);
}
__name(Tidy5eExhaustionDnd5eRestCompleted, "Tidy5eExhaustionDnd5eRestCompleted");
function Tidy5eExhaustionCreateActiveEffect(effect, data, id) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "dfredce" || game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "cub") {
    let actor2 = game.actors.get(effect.parent._id);
    let effectName = effect.label;
    if (effectName.includes(game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustom"))) {
      debug("tidy5e-exhaustion | createActiveEffect | effectName = " + effectName);
      if (actor2.type === "character") {
        let exhaustion = effectName.slice(-1);
        if (actor2.system.attributes.exhaustion != exhaustion) {
          debug("tidy5e-exhaustion | createActiveEffect | exhaustion = " + exhaustion);
          actor2.update({ "system.attributes.exhaustion": exhaustion });
        }
      } else if (actor2.type === "npc") {
        let exhaustion = effectName.slice(-1);
        if (actor2.flags[CONSTANTS.MODULE_ID].exhaustion != exhaustion) {
          debug("tidy5e-exhaustion | createActiveEffect | exhaustion = " + exhaustion);
          actor2.update({ "flags.tidy5e-sheet.exhaustion": exhaustion });
        }
      } else {
        warn(`createActiveEffect is not supported for actor ype '${actor2.type}'`);
      }
    }
  }
}
__name(Tidy5eExhaustionCreateActiveEffect, "Tidy5eExhaustionCreateActiveEffect");
function Tidy5eExhaustionDeleteActiveEffect(effect, data, id) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "dfredce" || game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") == "cub") {
    debug(`tidy5e-exhaustion | Tidy5eExhaustionDeleteActiveEffect | start`);
    const actor2 = game.actors.get(effect.parent._id);
    const effectName = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustom");
    const levels = game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectCustomTiers");
    const effectLabel = effect.label;
    if (effectLabel.includes(effectName)) {
      const tokens = canvas.tokens.placeables;
      const index = tokens.findIndex((x) => x.actor._id === effect.parent._id);
      const token = tokens[index];
      const actorEffects = (token && token.actor ? token.actor?.effects : actor2?.effects) || [];
      for (let i = 1; i <= levels; i++) {
        let tier = `${effectName} ${i}`;
        let effectIsFound = true;
        for (const effectEntity of actorEffects) {
          const effectNameToCheck = effectEntity.label;
          if (!effectNameToCheck) {
            continue;
          }
          if (effectNameToCheck == tier) {
            effectIsFound = true;
            break;
          }
        }
        if (effectIsFound) {
          return;
        }
      }
      if (actor2.type === "character") {
        if (actor2.system.attributes.exhaustion != 0) {
          actor2.update({ "system.attributes.exhaustion": 0 });
        }
      } else if (actor2.type === "npc") {
        if (actor2.flags.tidy5e - sheet.exhaustion != 0) {
          actor2.update({ "flags.tidy5e-sheet.exhaustion": 0 });
        }
      } else {
        warn(`deleteActiveEffect is not supported for actor ype '${actor2.type}'`);
      }
    }
    debug(`tidy5e-exhaustion | Tidy5eExhaustionDeleteActiveEffect | end`);
  }
}
__name(Tidy5eExhaustionDeleteActiveEffect, "Tidy5eExhaustionDeleteActiveEffect");
function getFeatureItemsFromActor(actor2) {
  return actor2.items.filter((item) => {
    if (["feat"].includes(item.type)) {
      return true;
    } else {
      return true;
    }
  }).sort((a, b) => {
    return a.name.localeCompare(b.name);
  });
}
__name(getFeatureItemsFromActor, "getFeatureItemsFromActor");
function getFeatureNamesFromActor(actor2) {
  const features = getFeatureItemsFromActor(actor2);
  const names = [];
  for (const feature of features) {
    names.push(feature.name.toLowerCase());
  }
  return names;
}
__name(getFeatureNamesFromActor, "getFeatureNamesFromActor");
const tidy5eHBEnableUpcastFreeSpell = /* @__PURE__ */ __name(async function(app, html, options) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "hbEnableUpcastFreeSpell")) {
    if (app?.item?.type != "spell") {
      debug(`tidy5eHBEnableUpcastFreeSpell | Nevermind if this isn't a spell`);
      return;
    }
    if (html.find('[name="consumeSpellSlot"]').length == 0) {
      debug(`tidy5eHBEnableUpcastFreeSpell | Nevermind if this is a cantrip`);
      return;
    }
    let tooltip = game.i18n.localize("TIDY5E.LevelBumpTooltip");
    if (game.settings.get(CONSTANTS.MODULE_ID, "hbSetFeaturesForUpcastFreeSpell") && app.item?.actor) {
      debug(`tidy5eHBEnableUpcastFreeSpell | hbSetFeaturesForUpcastFreeSpell check`);
      const namesFeaturesToCheck = game.settings.get(CONSTANTS.MODULE_ID, "hbSetFeaturesForUpcastFreeSpell").split("|") ?? [];
      const namesFeatures = getFeatureNamesFromActor(app.item?.actor) ?? [];
      const check = namesFeaturesToCheck.some((v) => namesFeatures.includes(v.toLowerCase()));
      if (!check) {
        debug(`tidy5eHBEnableUpcastFreeSpell | hbSetFeaturesForUpcastFreeSpell check is failed`);
        return;
      }
      tooltip = tooltip + ` Ty to one of these features '${namesFeaturesToCheck.join(",")}'`;
    }
    let new_checkbox = $(`
      <div class="form-group spell-lvl-btn" data-tooltip="${tooltip}">
        <label class="checkbox spell-lvl-btn__label"><input type="checkbox" name="freeUpcast" />${game.i18n.localize(
      "TIDY5E.LevelBump"
    )}</label>
      </div>`);
    new_checkbox.insertAfter(html.find(".form-group").last());
    new_checkbox.change((ev) => {
      if (ev.target.checked) {
        Object.values(html.find('[name="consumeSpellLevel"] option')).map((o) => {
          if (o.value) {
            if (o.value === "pact") {
              o.value = String(app.item.actor.system.spells.pact.level + 1);
            } else {
              o.value = String(parseInt(o.value) + 1);
            }
          }
        });
      } else {
        Object.values(html.find('[name="consumeSpellLevel"] option')).map((o) => {
          if (o.value) {
            if (o.text?.includes("Pact")) {
              o.value = "pact";
            } else {
              o.value = String(parseInt(o.value) - 1);
            }
          }
        });
      }
    });
    app.setPosition({ height: "auto" });
  }
}, "tidy5eHBEnableUpcastFreeSpell");
function Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption(item, config, options) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "hbEnableUpcastFreeSpell")) {
    debug(`tidy5e-hb-upcast-free-spells | Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption | start`);
    if (item?.type != "spell") {
      debug(`tidy5eHBEnableUpcastFreeSpell | dnd5e.preItemUsageConsumption | Nevermind if this isn't a spell`);
      return;
    }
    if (config?.freeUpcast) {
      if (item.system.preparation.mode === "pact") {
        config.consumeSpellLevel = "pact";
      } else {
        config.consumeSpellLevel = String(parseInt(config.consumeSpellLevel) - 1);
      }
    }
    debug(`tidy5e-hb-upcast-free-spells | Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption | end`);
  }
}
__name(Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption, "Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption");
function is_real_number(inNumber) {
  return !isNaN(inNumber) && typeof inNumber === "number" && isFinite(inNumber);
}
__name(is_real_number, "is_real_number");
function isEmptyObject(obj) {
  if (obj === null || obj === void 0) {
    return true;
  }
  const result = obj && // null and undefined check
  Object.keys(obj).length === 0;
  return result;
}
__name(isEmptyObject, "isEmptyObject");
const signCase$1 = {
  add: "+",
  subtract: "-",
  equals: "=",
  default: " "
};
function is_lazy_number(inNumber) {
  const isSign = String(inNumber).startsWith(signCase$1.add) || String(inNumber).startsWith(signCase$1.subtract) || String(inNumber).startsWith(signCase$1.equals) || String(inNumber).startsWith(signCase$1.default);
  if (isSign) {
    const withoutFirst = String(inNumber).slice(1);
    return is_real_number(withoutFirst);
  } else {
    return true;
  }
}
__name(is_lazy_number, "is_lazy_number");
function isLessThanOneIsOne(inNumber) {
  return inNumber < 1 ? 1 : inNumber;
}
__name(isLessThanOneIsOne, "isLessThanOneIsOne");
async function d20Roll({
  parts = [],
  data = {},
  event,
  advantage,
  disadvantage,
  critical = 20,
  fumble = 1,
  targetValue,
  elvenAccuracy,
  halflingLucky,
  reliableTalent,
  fastForward,
  chooseModifier = false,
  template,
  title,
  dialogOptions,
  chatMessage = true,
  messageData = {},
  rollMode,
  flavor
} = {}) {
  const formula = ["1d20"].concat(parts).join(" + ");
  const { advantageMode, isFF } = CONFIG.Dice.D20Roll.determineAdvantageMode({
    advantage,
    disadvantage,
    fastForward,
    event
  });
  const defaultRollMode = rollMode || game.settings.get("core", "rollMode");
  if (chooseModifier && !isFF) {
    data.mod = "@mod";
    if ("abilityCheckBonus" in data)
      data.abilityCheckBonus = "@abilityCheckBonus";
  }
  const roll = new CONFIG.Dice.D20Roll(formula, data, {
    flavor: flavor || title,
    advantageMode,
    defaultRollMode,
    rollMode,
    critical,
    fumble,
    targetValue,
    elvenAccuracy,
    halflingLucky,
    reliableTalent
  });
  if (!isFF) {
    const configured = await roll.configureDialog(
      {
        title,
        chooseModifier,
        defaultRollMode,
        defaultAction: advantageMode,
        defaultAbility: data?.item?.ability || data?.defaultAbility,
        template
      },
      dialogOptions
    );
    if (configured === null)
      return null;
  } else
    roll.options.rollMode ??= defaultRollMode;
  await roll.evaluate({ async: true });
  if (roll && chatMessage)
    await roll.toMessage(messageData);
  return roll;
}
__name(d20Roll, "d20Roll");
const preloadTidy5eHandlebarsTemplates = /* @__PURE__ */ __name(async function() {
  const tidy5etemplatePaths = [
    // Actor Sheet Partials
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-traits.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-inventory.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-inventory-grid.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-inventory-header.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-inventory-footer.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-features.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-spellbook.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-spellbook-grid.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-spellbook-header.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-spellbook-footer.html",
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-effects.html",
    // NPC
    "modules/tidy5e-sheet/templates/actors/parts/tidy5e-npc-spellbook.html"
  ];
  return loadTemplates(tidy5etemplatePaths);
}, "preloadTidy5eHandlebarsTemplates");
function applyLocksCharacterSheet(app, html, actorData) {
  if (!app.actor?.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    if (game.settings.get(CONSTANTS.MODULE_ID, "editTotalLockEnabled")) {
      html.find(".skill input").prop("disabled", true);
      html.find(".skill .config-button").remove();
      html.find(".skill .proficiency-toggle").remove();
      html.find(".ability-score").prop("disabled", true);
      html.find(".ac-display input").prop("disabled", true);
      html.find(".initiative input").prop("disabled", true);
      html.find(".hp-max").prop("disabled", true);
      html.find(".resource-name input").prop("disabled", true);
      html.find(".res-max").prop("disabled", true);
      html.find(".res-options").remove();
      html.find(".ability-modifiers .proficiency-toggle").remove();
      html.find(".ability .config-button").remove();
      html.find(".traits .config-button,.traits .trait-selector,.traits .proficiency-selector").remove();
      html.find("[contenteditable]").prop("contenteditable", false);
      html.find(".caster-level input").prop("disabled", true);
      html.find(".spellcasting-attribute select").prop("disabled", true);
    }
  }
  if (game.user.isGM) {
    return;
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockMoneyChanges")) {
    for (const elem of html.find("input[name^='system.currency']")) {
      elem.setAttribute("readonly", true);
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockExpChanges")) {
    for (const elem of html.find("input[name^='system.details.xp.value']")) {
      elem.setAttribute("readonly", true);
    }
    for (const elem of html.find("input[name^='system.details.xp.max']")) {
      elem.setAttribute("readonly", true);
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockHpMaxChanges")) {
    for (const elem of html.find("input[name^='system.attributes.hp.max']")) {
      elem.setAttribute("readonly", true);
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockLevelSelector")) {
    for (const elem of html.find("select[class^='level-selector']")) {
      elem.setAttribute("disabled", true);
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockConfigureSheet")) {
    for (const elem of html.find("a[class$='configure-sheet']")) {
      elem.style.pointerEvents = "none";
      elem.style.cursor = "default";
      elem.style.display = "none";
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockItemQuantity")) {
    for (const elem of html.find("input[name^='system.quantity']")) {
      elem.setAttribute("readonly", true);
    }
  }
}
__name(applyLocksCharacterSheet, "applyLocksCharacterSheet");
function applyLocksNpcSheet(app, html, actorData) {
  if (!app.actor?.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    if (game.settings.get(CONSTANTS.MODULE_ID, "editTotalLockEnabled")) {
      html.find(".skill input").prop("disabled", true);
      html.find(".skill .config-button").remove();
      html.find(".skill .proficiency-toggle").removeClass("proficiency-toggle");
      html.find(".ability-score").prop("disabled", true);
      html.find(".ac-display input").prop("disabled", true);
      html.find(".initiative input").prop("disabled", true);
      html.find(".hp-max").prop("disabled", true);
      html.find(".resource-name input").prop("disabled", true);
      html.find(".res-max").prop("disabled", true);
      html.find(".res-options").remove();
      html.find(".ability-modifiers .proficiency-toggle").remove();
      html.find(".ability .config-button").remove();
      html.find(".traits .config-button,.traits .trait-selector,.traits .proficiency-selector").remove();
      html.find("[contenteditable]").prop("contenteditable", false);
      html.find(".spellbook .slot-max-override").remove();
      html.find(".spellcasting-attribute select").prop("disabled", true);
      const spellbook = html.find(".spellbook .inventory-list .item-list").length;
      if (spellbook == 0)
        html.find(".item[data-tab='spellbook']").remove();
    }
  }
  applyLocksCharacterSheet(app, html);
}
__name(applyLocksNpcSheet, "applyLocksNpcSheet");
function applyLocksVehicleSheet(app, html, actorData) {
  applyLocksCharacterSheet(app, html);
}
__name(applyLocksVehicleSheet, "applyLocksVehicleSheet");
function applyLocksItemSheet(app, html, actorData) {
  if (game.user.isGM) {
    return;
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockItemQuantity")) {
    for (const elem of html.find("input[name^='system.quantity']")) {
      elem.setAttribute("readonly", true);
    }
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "lockConfigureSheet")) {
    for (const elem of html.find("a[class$='configure-sheet']")) {
      elem.style.pointerEvents = "none";
      elem.style.cursor = "default";
      elem.style.display = "none";
    }
  }
}
__name(applyLocksItemSheet, "applyLocksItemSheet");
const tidy5eShowItemArt = /* @__PURE__ */ __name(function(html, item) {
  let image = html.find("img.profile");
  image.attr("title", `${game.i18n.localize("TIDY5E.EditActorImage")} / ${game.i18n.localize("TIDY5E.ShowItemImage")}`);
  let container = `<div class="item-image item-image-show-item-art"></div>`;
  let menu = `<div class="item-menu hidden"><a class="showItemArt">${game.i18n.localize("TIDY5E.ShowItemArt")}</a>`;
  image.wrap(container);
  let imageContainer = html.find(".item-image-show-item-art");
  imageContainer.append(menu);
  let imageMenu = html.find(".item-menu");
  let imageButton = html.find(".showItemArt");
  image.mousedown(async (e) => {
    switch (e.which) {
      case 3:
        imageMenu.toggleClass("hidden");
        break;
    }
  });
  imageButton.click(function(e) {
    e.preventDefault();
    imageMenu.addClass("hidden");
    $(this).attr("id");
    let itemImg = item.img;
    new ImagePopout(itemImg, {
      title: "Item: " + item.name,
      shareable: true,
      uuid: item.uuid
    }).render(true);
  });
}, "tidy5eShowItemArt");
const classesConfiguration = {
  artificer: "TIDY5E.ClassArtificer",
  barbarian: "TIDY5E.ClassBarbarian",
  bard: "TIDY5E.ClassBard",
  cleric: "TIDY5E.ClassCleric",
  druid: "TIDY5E.ClassDruid",
  fighter: "TIDY5E.ClassFighter",
  monk: "TIDY5E.ClassMonk",
  paladin: "TIDY5E.ClassPaladin",
  ranger: "TIDY5E.ClassRanger",
  rogue: "TIDY5E.ClassRogue",
  sorcerer: "TIDY5E.ClassSorcerer",
  warlock: "TIDY5E.ClassWarlock",
  wizard: "TIDY5E.ClassWizard",
  custom: "TIDY5E.ClassCustom"
};
let classesConfigurationTmp = {};
async function applySpellClassFilterItemSheet(app, html, itemData) {
  if (!game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterSelect")) {
    return;
  }
  if (game.modules.get("spell-class-filter-for-5e")?.active) {
    return;
  }
  game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterSelect");
  game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterIconReplace");
  const item = app.object;
  const type = item.type;
  if (type == "spell") {
    classesConfigurationTmp = classesConfiguration;
    const user_setting_addClasses = game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterAdditionalClasses");
    if (user_setting_addClasses && user_setting_addClasses.includes("|")) {
      let classes = [];
      if (user_setting_addClasses.includes(",")) {
        classes = user_setting_addClasses.split(",");
      } else {
        classes = [user_setting_addClasses];
      }
      for (let clazz of classes) {
        const c = clazz.split("|");
        const id = c[0];
        const name = c[1];
        if (id && name) {
          classesConfigurationTmp[id] = name;
        }
      }
    }
    const spellDetailsDiv = html.find(".tab.details");
    const firstChild = spellDetailsDiv.children("h3:first");
    const spellClassForm = await renderTemplate(
      "modules/tidy5e-sheet/templates/items/tidy5e-spell-class-filter-form.html",
      {
        SCF: classesConfigurationTmp,
        item,
        flags: item.flags
      }
    );
    firstChild.after(spellClassForm);
  }
}
__name(applySpellClassFilterItemSheet, "applySpellClassFilterItemSheet");
async function applySpellClassFilterActorSheet(app, html, actorData) {
  if (!game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterSelect")) {
    return;
  }
  if (game.modules.get("spell-class-filter-for-5e")?.active) {
    return;
  }
  const user_setting_filterSelect = game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterSelect");
  const user_setting_iconReplace = game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterIconReplace");
  const actor2 = app.object;
  const type = actor2.type;
  const flags = actor2.flags;
  const actorSCFlags = flags[CONSTANTS.MODULE_ID];
  if (type == "character") {
    const spellbook = html.find(".tab.spellbook");
    const filterList = spellbook.find("ul.filter-list");
    const firstItem = filterList.children("li.filter-item:first");
    const actorItems = actor2.items;
    if (user_setting_filterSelect) {
      classesConfigurationTmp = classesConfiguration;
      const user_setting_addClasses = game.settings.get(CONSTANTS.MODULE_ID, "spellClassFilterAdditionalClasses");
      if (user_setting_addClasses && user_setting_addClasses.includes("|")) {
        let classes2 = [];
        if (user_setting_addClasses.includes(",")) {
          classes2 = user_setting_addClasses.split(",");
        } else {
          classes2 = [user_setting_addClasses];
        }
        for (let clazz of classes2) {
          const c = clazz.split("|");
          const id = c[0];
          const name = c[1];
          if (id && name) {
            classesConfigurationTmp[id] = name;
          }
        }
      }
      const actorClassFilter = await renderTemplate(
        "modules/tidy5e-sheet/templates/actors/parts/tidy5e-spellbook-class-filter.html",
        {
          SCF: classesConfigurationTmp,
          actor: actor2,
          flags,
          scFlags: actor2.flags[CONSTANTS.MODULE_ID]
        }
      );
      firstItem.before(actorClassFilter);
    }
    let classes = {};
    for (let item of actorItems) {
      if (item.type == "class") {
        let className = item.name.toLowerCase();
        let classImg = item.img;
        classes[className] = classImg;
      }
    }
    const spellList = spellbook.find(".inventory-list");
    const items = spellList.find(".item");
    items.each(function() {
      let itemID = $(this).data("item-id");
      let item = actorItems.get(itemID);
      let itemFlags = item.flags;
      let itemSCFlags = itemFlags[CONSTANTS.MODULE_ID];
      if (user_setting_iconReplace) {
        if (itemSCFlags) {
          if (classes.hasOwnProperty(itemSCFlags.parentClass)) {
            let imgdiv = $(this).find(".item-image");
            imgdiv.css("background-image", `url(${classes[itemSCFlags.parentClass]})`);
          }
        }
      }
      if (user_setting_filterSelect) {
        if (hasProperty(actorSCFlags, "classFilter")) {
          if (actorSCFlags.classFilter != "") {
            if (itemSCFlags) {
              if (!(itemSCFlags.parentClass == actorSCFlags.classFilter)) {
                $(this).hide();
              }
            } else {
              $(this).hide();
            }
          }
        }
      }
    });
  }
}
__name(applySpellClassFilterActorSheet, "applySpellClassFilterActorSheet");
class Tidy5eItemSheet extends dnd5e.applications.item.ItemSheet5e {
  static {
    __name(this, "Tidy5eItemSheet");
  }
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["tidy5e", "dnd5ebak", "sheet", "item"]
    });
  }
  activateListeners(html) {
    super.activateListeners(html);
    let item = this.item;
    debug(`tidy5e-item | activateListeners | item: ${item}`);
    tidy5eShowItemArt(html, item);
  }
}
async function addEditorHeadline(app, html, data) {
  html.find(".tab[data-tab=description] .editor").prepend(`<h2 class="details-headline">${game.i18n.localize("TIDY5E.ItemDetailsHeadline")}</h2>`);
}
__name(addEditorHeadline, "addEditorHeadline");
function Tidy5eSheetItemInitialize() {
  Items.registerSheet("dnd5e", Tidy5eItemSheet, { makeDefault: true, label: "TIDY5E.Tidy5eItemSheet" });
}
__name(Tidy5eSheetItemInitialize, "Tidy5eSheetItemInitialize");
Hooks.on("renderTidy5eItemSheet", (app, html, data) => {
  addEditorHeadline(app, html);
  applySpellClassFilterItemSheet(app, html);
  applyLocksItemSheet(app, html);
});
class Tidy5eBaseConfigSheet extends DocumentSheet {
  static {
    __name(this, "Tidy5eBaseConfigSheet");
  }
  /** @inheritdoc */
  activateListeners(html) {
    super.activateListeners(html);
    if (this.isEditable) {
      for (const override of this._getActorOverrides()) {
        html.find(`input[name="${override}"],select[name="${override}"]`).each((i, el) => {
          el.disabled = true;
          el.dataset.tooltip = "DND5E.ActiveEffectOverrideWarning";
        });
      }
    }
  }
  /* -------------------------------------------- */
  /**
   * Retrieve the list of fields that are currently modified by Active Effects on the Actor.
   * @returns {string[]}
   * @protected
   */
  _getActorOverrides() {
    return Object.keys(foundry.utils.flattenObject(this.object.overrides || {}));
  }
}
class Tidy5eActorHitPointsConfig extends Tidy5eBaseConfigSheet {
  static {
    __name(this, "Tidy5eActorHitPointsConfig");
  }
  constructor(...args) {
    super(...args);
    this.clone = this.object.clone();
  }
  /* -------------------------------------------- */
  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["dnd5e", "actor-hit-points-config"],
      template: "systems/dnd5e/templates/apps/hit-points-config.hbs",
      width: 320,
      height: "auto",
      sheetConfig: false
    });
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  get title() {
    return `${game.i18n.localize("DND5E.HitPointsConfig")}: ${this.document.name}`;
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  getData(options) {
    return {
      hp: this.clone.system.attributes.hp,
      source: this.clone.toObject().system.attributes.hp,
      isCharacter: this.document.type === "character"
    };
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  _getActorOverrides() {
    return Object.keys(foundry.utils.flattenObject(this.object.overrides?.system?.attributes || {}));
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  async _updateObject(event, formData) {
    const hp = foundry.utils.expandObject(formData).hp;
    this.clone.updateSource({ "system.attributes.hp": hp });
    this.clone.system.attributes.hp.max - this.document.system.attributes.hp.max;
    hp.value = Math.max(this.document.system.attributes.hp.value, 0);
    return this.document.update({ "system.attributes.hp": hp });
  }
  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */
  /** @inheritDoc */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".roll-hit-points").click(this._onRollHPFormula.bind(this));
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  async _onChangeInput(event) {
    await super._onChangeInput(event);
    const t = event.currentTarget;
    if (t.value === "" || t.value === "0" || t.value === null || t.value === void 0) {
      if (t.name === "hp.max") {
        const rollData = this.object.getRollData();
        this.object.system._source.attributes.hp.max = null;
        this.object._prepareHitPoints(rollData);
        t.value = this.object.system.attributes.hp.max;
      }
    }
    this.clone.updateSource({ [`system.attributes.${t.name}`]: t.value || null });
    if (t.name !== "hp.formula")
      this.render();
  }
  /* -------------------------------------------- */
  /**
   * Handle rolling NPC health values using the provided formula.
   * @param {Event} event  The original click event.
   * @protected
   */
  async _onRollHPFormula(event) {
    event.preventDefault();
    try {
      const roll = await this.clone.rollNPCHitPoints();
      this.clone.updateSource({ "system.attributes.hp.max": roll.total });
      this.render();
    } catch (error2) {
      ui.notifications.error(game.i18n.localize("DND5E.HPFormulaError"));
      throw error2;
    }
  }
}
class Tidy5eActorOriginSummaryConfig extends Tidy5eBaseConfigSheet {
  static {
    __name(this, "Tidy5eActorOriginSummaryConfig");
  }
  constructor(...args) {
    super(...args);
    this.clone = this.object.clone();
  }
  /* -------------------------------------------- */
  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["dnd5e", "actor-origin-summary-config"],
      template: `modules/${CONSTANTS.MODULE_ID}/templates/actors/parts/tidy5e-origin-summary-config.html`,
      width: 320,
      height: "auto",
      sheetConfig: false
    });
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  get title() {
    return `${game.i18n.localize("TIDY5E.OriginSummaryConfig")}: ${this.document.name}`;
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  getData(options) {
    return {
      race: this.clone.system.details.race,
      background: this.clone.system.details.background,
      environment: this.clone.system.details.environment,
      alignment: this.clone.system.details.alignment,
      source: this.clone.system.details.source,
      dimensions: this.clone.system.traits.dimensions,
      isCharacter: this.document.type === "character",
      isNPC: this.document.type === "npc",
      isVehicle: this.document.type === "vehicle"
    };
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  _getActorOverrides() {
    return Object.keys(foundry.utils.flattenObject(this.object.overrides?.system?.details || {}));
  }
  /* -------------------------------------------- */
  /** @inheritdoc */
  async _updateObject(event, formData) {
    const race = foundry.utils.expandObject(formData).race;
    const background = foundry.utils.expandObject(formData).background;
    const environment = foundry.utils.expandObject(formData).environment;
    const alignment = foundry.utils.expandObject(formData).alignment;
    const source = foundry.utils.expandObject(formData).source;
    const dimensions = foundry.utils.expandObject(formData).dimensions;
    const isCharacter = this.document.type === "character";
    const isNPC = this.document.type === "npc";
    const isVehicle = this.document.type === "vehicle";
    if (isCharacter) {
      return this.document.update({
        "system.details.race": race,
        "system.details.background": background,
        "system.details.alignment": alignment
      });
    } else if (isNPC) {
      return this.document.update({
        "system.details.environment": environment,
        "system.details.alignment": alignment,
        "system.details.source": source
      });
    } else if (isVehicle) {
      return this.document.update({
        "system.traits.dimensions": dimensions
      });
    }
  }
  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */
  /** @inheritDoc */
  activateListeners(html) {
    super.activateListeners(html);
  }
  /* -------------------------------------------- */
  // /** @inheritdoc */
  // async _onChangeInput(event) {
  //   await super._onChangeInput(event);
  //   const t = event.currentTarget;
  //   if(t.value === "" || t.value === "0" || t.value === null || t.value === undefined) {
  //       const rollData = this.object.getRollData();
  //       // strange patch ...
  //       this.object.system._source.attributes.hp.max = null;
  //       this.object._prepareHitPoints(rollData);
  //       t.value = this.object.system.attributes.hp.max;
  //   }
  //   // Update clone with new data & re-render
  //   this.clone.updateSource({ [`system.attributes.${t.name}`]: t.value || null });
  // }
  /* -------------------------------------------- */
}
const tidy5eListeners = /* @__PURE__ */ __name(function(html, actor2, app) {
  html.find("[contenteditable]").on("paste", function(e) {
    let $self = $(this);
    let maxlength = 40;
    if ($self[0].dataset.maxlength) {
      maxlength = parseInt($self[0].dataset.maxlength);
    }
    setTimeout(function() {
      let textString = $self.text();
      textString = textString.substring(0, maxlength);
      $self.html(textString);
    }, 0);
  }).on("keypress", function(e) {
    let $self = $(this);
    let maxlength = 40;
    if ($self[0].dataset.maxlength) {
      maxlength = parseInt($self[0].dataset.maxlength);
    }
    let keys = [8, 37, 38, 39, 40, 46];
    if ($(this).text().length === maxlength && keys.indexOf(e.keyCode) < 0) {
      e.preventDefault();
    }
    if (e.keyCode === 13) {
      $(this).blur();
    }
  });
  html.find("[contenteditable]").blur(async (event) => {
    let value = event.target.textContent;
    let target = event.target.dataset.target;
    html.find('input[type="hidden"][data-input="' + target + '"]').val(value).submit();
  });
  html.find(".actor-size-select .size-label").on("click", function() {
    let currentSize = $(this).data("size");
    $(this).closest("ul").toggleClass("active").find('ul li[data-size="' + currentSize + '"]').addClass("current");
  });
  html.find(".actor-size-select .size-list li").on("click", async (event) => {
    let value = event.target.dataset.size;
    actor2.update({ "data.traits.size": value });
    html.find(".actor-size-select").toggleClass("active");
  });
  html.find(".ability-mod.rollable").click(async (event) => {
    event.preventDefault();
    let ability = event.currentTarget.parentElement.parentElement.dataset.ability;
    actor2.rollAbilityTest(ability, { event });
  });
  html.find(".ability-save.rollable").click(async (event) => {
    event.preventDefault();
    let ability = event.currentTarget.parentElement.parentElement.dataset.ability;
    actor2.rollAbilitySave(ability, { event });
  });
  html.find(".toggle-allow-edit span").click(async (event) => {
    event.preventDefault();
    if (actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
      await actor2.unsetFlag(CONSTANTS.MODULE_ID, "allow-edit");
    } else {
      await actor2.setFlag(CONSTANTS.MODULE_ID, "allow-edit", true);
    }
  });
  html.on("click", "[data-action='itemDuplicate']", app._onItemDuplicate.bind(app));
  html.find(".hit-points-tidy").click(() => {
    let app2 = new Tidy5eActorHitPointsConfig(actor2);
    app2?.render(true);
  });
  html.find(".origin-summary-tidy").click(() => {
    let app2 = new Tidy5eActorOriginSummaryConfig(actor2);
    app2?.render(true);
  });
}, "tidy5eListeners");
const tidy5eAmmoSwitch = /* @__PURE__ */ __name(function(html, actor2) {
  html.find(".ammo").each(function() {
    const element = $(this);
    const itemId = element.attr("data-id");
    const token = actor2.token || null;
    if (token)
      actor2 = actor2.getActiveTokens(false, true).find((t) => t._id === token.id).actor;
    const item = actor2.items.get(itemId);
    const equippedOnly = game.settings.get(CONSTANTS.MODULE_ID, "ammoEquippedOnly");
    const ammoItems = actor2.items.filter(
      (x) => x.system.consumableType === "ammo" && (!equippedOnly || x.system.equipped)
    );
    debug(`tidy5e-ammo-switch | tidy5eAmmoSwitch | ammoItems: ${ammoItems}`);
    const target = item.system.consume.target;
    const ammoItemStrings = ['<option value=""></option>'].concat(
      ammoItems.map(
        (x) => `<option value="${x.id}" ${x.id === target ? "selected" : ""}>${x.name} (${x.system.quantity})</option>`
      )
    ).join("");
    const selector = $(`<select class="ammo-switch">${ammoItemStrings}</select>`);
    selector.attr("data-item", item.id);
    selector.attr("data-actor", actor2.id);
    if (token)
      selector.attr("data-token", token.id);
    selector.on("change", function() {
      const element2 = $(this);
      const val = element2.val();
      let actor3 = game.actors.get(selector.attr("data-actor"));
      const token2 = selector.attr("data-token");
      if (token2)
        actor3 = actor3.getActiveTokens(false, true).find((t) => t._id === token2).actor;
      const item2 = actor3.items.get(selector.attr("data-item"));
      const ammo = actor3.items.get(val);
      item2.update({
        system: {
          consume: {
            amount: !ammo ? null : !!item2.system.consume.amount ? item2.system.consume.amount : 1,
            target: !ammo ? "" : val,
            type: !ammo ? "" : ammo.system.consumableType
          }
        }
      });
    });
    element.after(selector);
    element.remove();
  });
}, "tidy5eAmmoSwitch");
const isItemFavorite = /* @__PURE__ */ __name(function(item) {
  if (!item) {
    return false;
  }
  let isFav = game.modules.get("favtab")?.active && item.flags["favtab"]?.isFavorite || game.modules.get("favorite-items")?.active && item.flags["favorite-items"]?.favorite || item.flags[CONSTANTS.MODULE_ID]?.favorite || false;
  const isAlreadyTidyFav = getProperty(item.flags[CONSTANTS.MODULE_ID], `favorite`);
  const isAlreadyFabTab = getProperty(item.flags["favtab"], `isFavorite`);
  if (String(isAlreadyFabTab) === "true" && String(isAlreadyFabTab) === "false") {
    if (String(isAlreadyTidyFav) !== "true" && String(isAlreadyTidyFav) !== "false") {
      isFav = item.flags["favtab"]?.isFavorite;
    }
  }
  return isFav;
}, "isItemFavorite");
const addFavorites = /* @__PURE__ */ __name(async function(app, html, data, position2) {
  let favs = app.actor.items.filter((i) => {
    return isItemFavorite(i);
  });
  if (game.modules.get("favorite-items")?.active) {
    game.settings.get("favorite-items", "favorite-icon");
    game.settings.get("favorite-items", "favorite-color");
  }
  let context = {
    owner: data.owner,
    inventory: favs.filter((i) => ["weapon", "equipment", "consumable", "tool", "backpack", "loot"].includes(i.type)),
    features: favs.filter((i) => ["feat", "background", "class", "subclass"].includes(i.type)),
    spells: app._prepareSpellbook(
      { actor: app.actor },
      favs.filter((i) => i.type === "spell")
    ),
    itemContext: favs.reduce((obj, i) => {
      obj[i.id] ??= { hasUses: i.system.uses && i.system.uses.max > 0 };
      app._prepareItemToggleState(i, obj[i.id]);
      return obj;
    }, {})
  };
  let favItems = [];
  let favFeats = [];
  let favSpellsPrepMode = {
    atwill: {
      isAtWill: true,
      spells: []
    },
    innate: {
      isInnate: true,
      spells: []
    },
    pact: {
      isPact: true,
      spells: [],
      value: data.actor.system.spells.pact.value,
      max: data.actor.system.spells.pact.max
    }
  };
  let favSpells = {};
  for (const level in CONFIG.DND5E.spellLevels) {
    if (level === "0") {
      favSpells[level] = {
        isCantrip: true,
        spells: []
      };
    } else {
      favSpells[level] = {
        spells: [],
        value: data.actor.system.spells[`spell${level}`].value,
        max: data.actor.system.spells[`spell${level}`].max
      };
    }
  }
  let spellCount = 0;
  let spellPrepModeCount = 0;
  let renderFavTab = false;
  for (let item of app.actor.items) {
    item.owner = app.actor.isOwner;
    if (item.type == "class") {
      continue;
    }
    item.notFeat = true;
    if (item.type == "feat") {
      item.notFeat = false;
    }
    let isFav = isItemFavorite(item);
    if (app.options.editable) {
      let favBtn = $(
        `<a class="item-control item-fav ${isFav ? "active" : ""}" title="${isFav ? game.i18n.localize("TIDY5E.RemoveFav") : game.i18n.localize("TIDY5E.AddFav")}" data-fav="${isFav}"><i class="${isFav ? "fas fa-bookmark" : "fas fa-bookmark inactive"}"></i> <span class="control-label">${isFav ? game.i18n.localize("TIDY5E.RemoveFav") : game.i18n.localize("TIDY5E.AddFav")}</span></a>`
      );
      favBtn.click((ev) => {
        const item_id = ev.currentTarget.closest("[data-item-id]").dataset.itemId;
        const item2 = app.actor.items.get(item_id);
        if (!item2) {
          warn(`tidy5e-favorites | addFavorites | Item no founded!`);
          return;
        }
        let isFav2 = isItemFavorite(item2);
        item2.update({
          "flags.tidy5e-sheet.favorite": !isFav2
        });
        if (game.modules.get("favorite-items")?.active) {
          item2.update({
            "flags.favorite-items.favorite": !isFav2
          });
        }
        if (game.modules.get("favtab")?.active) {
          item2.update({
            "flags.favtab.isFavorite": !isFav2
          });
        }
      });
      html.find(`.item[data-item-id="${item._id}"]`).find(".item-controls .item-edit").before(favBtn);
      if (isFav) {
        html.find(`.item[data-item-id="${item._id}"]`).addClass("isFav");
      }
    }
    if (isFav) {
      let translateLabels2 = function(key) {
        let string = String(key);
        return translation[string];
      };
      var translateLabels = translateLabels2;
      __name(translateLabels2, "translateLabels");
      renderFavTab = true;
      let labels = {};
      let translation = {
        none: game.i18n.localize("DND5E.None"),
        action: game.i18n.localize("DND5E.Action"),
        crew: game.i18n.localize("DND5E.VehicleCrewAction"),
        bonus: game.i18n.localize("DND5E.BonusAction"),
        reaction: game.i18n.localize("DND5E.Reaction"),
        legendary: game.i18n.localize("DND5E.LegAct"),
        lair: game.i18n.localize("DND5E.LairAct"),
        special: game.i18n.localize("DND5E.Special"),
        day: game.i18n.localize("DND5E.TimeDay"),
        hour: game.i18n.localize("DND5E.TimeHour"),
        minute: game.i18n.localize("DND5E.TimeMinute"),
        reactiondamage: game.i18n.localize("midi-qol.reactionDamaged"),
        reactionmanual: game.i18n.localize("midi-qol.reactionManual")
      };
      if (item.system.activation && item.system.activation.type) {
        let key = item.system.activation.type;
        labels.activation = `${item.system.activation.cost ? item.system.activation.cost + " " : ""}${translateLabels2(
          key
        )}`;
      }
      item.isOnCooldown = false;
      if (item.system.recharge && item.system.recharge.value && item.system.recharge.charged === false) {
        item.isOnCooldown = true;
        item.labels = {
          recharge: game.i18n.localize("DND5E.FeatureRechargeOn") + " [" + item.system.recharge.value + "+]",
          rechargeValue: "[" + item.system.recharge.value + "+]"
        };
      }
      item.isStack = false;
      if (item.system.quantity && item.system.quantity > 1) {
        item.isStack = true;
      }
      item.canAttune = false;
      if (item.system.attunement) {
        if (item.system.attunement == 1 || item.system.attunement == 2) {
          item.canAttune = true;
        }
      }
      item.isMagic = false;
      if (item.flags.magicitems && item.flags.magicitems.enabled || item.system.properties && item.system.properties.mgc) {
        item.isMagic = true;
      }
      let attr = item.type === "spell" ? "preparation.prepared" : "equipped";
      let isActive = getProperty(item.system, attr);
      item.toggleClass = isActive ? "active" : "";
      if (item.type === "spell") {
        if (item.system.preparation.mode == "always") {
          item.toggleTitle = game.i18n.localize("DND5E.SpellPrepAlways");
        } else {
          item.toggleTitle = game.i18n.localize(isActive ? "DND5E.SpellPrepared" : "DND5E.SpellUnprepared");
        }
      } else {
        item.toggleTitle = game.i18n.localize(isActive ? "DND5E.Equipped" : "DND5E.Unequipped");
      }
      item.spellComps = "";
      if (item.type === "spell" && item.system.components) {
        let comps = item.system.components;
        let v = comps.vocal ? "V" : "";
        let s = comps.somatic ? "S" : "";
        let m = comps.material ? "M" : "";
        let c = comps.concentration ? true : false;
        let r = comps.ritual ? true : false;
        item.spellComps = `${v}${s}${m}`;
        item.spellCon = c;
        item.spellRit = r;
      }
      item.favLabels = labels;
      item.editable = app.options.editable;
      switch (item.type) {
        case "feat": {
          if (!is_real_number(item.flags[CONSTANTS.MODULE_ID].sort)) {
            item.flags[CONSTANTS.MODULE_ID].sort = (favFeats.count + 1) * 1e5;
          }
          item.isFeat = true;
          favFeats.push(item);
          break;
        }
        case "spell": {
          if (!is_real_number(item.flags[CONSTANTS.MODULE_ID].sort)) {
            item.flags[CONSTANTS.MODULE_ID].sort = (favSpellsPrepMode.count + 1) * 1e5;
          }
          if (item.system.preparation.mode && item.system.preparation.mode !== "prepared") {
            if (item.system.preparation.mode == "always") {
              item.canPrep = true;
              item.alwaysPrep = true;
            } else if (item.system.preparation.mode == "atwill") {
              favSpellsPrepMode["atwill"].spells.push(item);
            } else if (item.system.preparation.mode == "innate") {
              favSpellsPrepMode["innate"].spells.push(item);
            } else if (item.system.preparation.mode == "pact") {
              favSpellsPrepMode["pact"].spells.push(item);
            }
            spellPrepModeCount++;
          } else {
            item.canPrep = true;
          }
          if (item.canPrep && item.system.level) {
            favSpells[item.system.level].spells.push(item);
          } else if (item.canPrep) {
            favSpells[0].spells.push(item);
          }
          spellCount++;
          break;
        }
        default: {
          if (!is_real_number(item.flags[CONSTANTS.MODULE_ID].sort)) {
            item.flags[CONSTANTS.MODULE_ID].sort = (favItems.count + 1) * 1e5;
          }
          item.isItem = true;
          favItems.push(item);
          break;
        }
      }
      if (item.canPrep) {
        item.canPrepare = item.system.level >= 1;
      }
    }
  }
  let enableSortFavoritesItemsAlphabetically = game.settings.get(
    CONSTANTS.MODULE_ID,
    "enableSortFavoritesItemsAlphabetically"
  );
  if (enableSortFavoritesItemsAlphabetically) {
    const favItemsArray = Object.keys(favItems);
    for (let key of favItemsArray) {
      favItems.sort(function(a, b) {
        let nameA = a.name.toLowerCase();
        let nameB = b.name.toLowerCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favFeatsArray = Object.keys(favFeats);
    for (let key of favFeatsArray) {
      favFeats.sort(function(a, b) {
        let nameA = a.name.toLowerCase();
        let nameB = b.name.toLowerCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favSpellsArray = Object.keys(favSpells);
    for (let key of favSpellsArray) {
      favSpells[key].spells.sort(function(a, b) {
        let nameA = a.name.toLowerCase();
        let nameB = b.name.toLowerCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favSpellsPrepModeArray = Object.keys(favSpellsPrepMode);
    for (let key of favSpellsPrepModeArray) {
      favSpellsPrepMode[key].spells.sort(function(a, b) {
        let nameA = a.name.toLowerCase();
        let nameB = b.name.toLowerCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
  } else {
    const favItemsArray = Object.keys(favItems);
    for (let key of favItemsArray) {
      favItems.sort(function(a, b) {
        let nameA = a.flags[CONSTANTS.MODULE_ID]?.sort;
        let nameB = b.flags[CONSTANTS.MODULE_ID]?.sort;
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favFeatsArray = Object.keys(favFeats);
    for (let key of favFeatsArray) {
      favFeats.sort(function(a, b) {
        let nameA = a.flags[CONSTANTS.MODULE_ID]?.sort;
        let nameB = b.flags[CONSTANTS.MODULE_ID]?.sort;
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favSpellsArray = Object.keys(favSpells);
    for (let key of favSpellsArray) {
      favSpells[key].spells.sort(function(a, b) {
        let nameA = a.flags[CONSTANTS.MODULE_ID]?.sort;
        let nameB = b.flags[CONSTANTS.MODULE_ID]?.sort;
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
    const favSpellsPrepModeArray = Object.keys(favSpellsPrepMode);
    for (let key of favSpellsPrepModeArray) {
      favSpellsPrepMode[key].spells.sort(function(a, b) {
        let nameA = a.flags[CONSTANTS.MODULE_ID]?.sort;
        let nameB = b.flags[CONSTANTS.MODULE_ID]?.sort;
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    }
  }
  html.find('.item[data-tab="attributes"]');
  let favContainer = html.find(".favorites-wrap");
  let favContent = html.find(".favorites-target");
  html.find(".tab.attributes");
  if (renderFavTab) {
    context.favItems = favItems.length > 0 ? favItems : (
      //? enableSortFavoritesItemsAlphabetically ? favItems : favItems?.sort((a, b) => a.flags[CONSTANTS.MODULE_ID].sort - b.flags[CONSTANTS.MODULE_ID].sort)
      false
    );
    context.favFeats = favFeats.length > 0 ? favFeats : (
      //? enableSortFavoritesItemsAlphabetically ? favFeats : favFeats?.sort((a, b) => a.flags[CONSTANTS.MODULE_ID].sort - b.flags[CONSTANTS.MODULE_ID].sort)
      false
    );
    context.favSpellsPrepMode = spellPrepModeCount > 0 ? favSpellsPrepMode : false;
    context.favSpells = spellCount > 0 ? favSpells : false;
    context.editable = app.options.editable;
    context.allowCantripToBePreparedOnContext = game.settings.get(
      CONSTANTS.MODULE_ID,
      "allowCantripToBePreparedOnContext"
    );
    await loadTemplates(["modules/tidy5e-sheet/templates/favorites/tidy5e-favorite-item.html"]);
    let favHtml = $(
      await renderTemplate("modules/tidy5e-sheet/templates/favorites/tidy5e-favorite-template.html", context)
    );
    tidy5eContextMenu(favHtml, app);
    favHtml.find(".item-name h4").click((event) => app._onItemSummary(event));
    if (app.options.editable) {
      favHtml.find(".item-image").click((ev) => app._onItemUse(ev));
      let handler = /* @__PURE__ */ __name(async (ev) => app._onDragStart(ev), "handler");
      favHtml.find(".item").each((i, li) => {
        if (li.classList.contains("items-header"))
          return;
        li.setAttribute("draggable", true);
        li.addEventListener("dragstart", handler, false);
      });
      favHtml.find(".item-control.item-edit").click((ev) => {
        let itemId = $(ev.target).parents(".item")[0].dataset.itemId;
        app.actor.items.get(itemId).sheet.render(true);
      });
      favHtml.find(".item-control.item-toggle").click((ev) => {
        ev.preventDefault();
        let itemId = ev.currentTarget.closest(".item").dataset.itemId;
        let item = app.actor.items.get(itemId);
        let attr = item.type === "spell" ? "system.preparation.prepared" : "system.equipped";
        return item.update({ [attr]: !getProperty(item, attr) });
      });
      favHtml.find(".item-control.item-attunement").click(async (ev) => {
        ev.preventDefault();
        let itemId = ev.currentTarget.closest(".item").dataset.itemId;
        let item = app.actor.items.get(itemId);
        if (item.system.attunement == 2) {
          app.actor.items.get(itemId).update({ "system.attunement": 1 });
        } else {
          if (app.actor.system.details.attunedItemsCount >= app.actor.system.details.attunedItemsMax) {
            let count = actor.system.details.attunedItemsCount;
            ui.notifications.warn(
              `${game.i18n.format("TIDY5E.AttunementWarning", {
                number: count
              })}`
            );
          } else {
            app.actor.items.get(itemId).update({ "system.attunement": 2 });
          }
        }
      });
      favHtml.find(".item-fav").click((ev) => {
        const item_id = ev.currentTarget.closest("[data-item-id]").dataset.itemId;
        const item = app.actor.items.get(item_id);
        if (!item) {
          warn(`tidy5e-favorites | addFavorites | Item no founded!`);
          return;
        }
        let isFav = isItemFavorite(item);
        item.update({
          "flags.tidy5e-sheet.favorite": !isFav
        });
        if (game.modules.get("favorite-items")?.active) {
          item.update({
            "flags.favorite-items.favorite": !isFav
          });
        }
        if (game.modules.get("favtab")?.active) {
          item.update({
            "flags.favtab.isFavorite": !isFav
          });
        }
      });
      favHtml.find(".spell-slots input").change((ev) => {
        let path = ev.target.dataset.target;
        let data2 = Number(ev.target.value ?? 0);
        app.actor.update({ [path]: data2 });
      });
      favHtml.find(".addCharges").click((ev) => {
        let itemId = $(ev.target).parents(".item")[0].dataset.itemId;
        let item = app.actor.items.get(itemId);
        item.system.uses = { value: 1, max: 1 };
        let data2 = {};
        data2["system.uses.value"] = 1;
        data2["system.uses.max"] = 1;
        app.actor.items.get(itemId).update(data2);
      });
      favHtml.find(".item-recharge").click((ev) => {
        ev.preventDefault();
        let itemId = $(ev.target).parents(".item")[0].dataset.itemId;
        let item = app.actor.items.get(itemId);
        return item.rollRecharge();
      });
      favHtml.find(".item").on("drop", (ev) => {
        ev.preventDefault();
        let dropData = JSON.parse(ev.originalEvent.dataTransfer.getData("text/plain"));
        let item = fromUuidSync(dropData.uuid);
        if (!item || item.actor?.id !== app.actor.id) {
          return;
        }
        let itemId = item.id;
        let list = null;
        if (item.type === "feat") {
          list = favFeats;
        } else if (item.type === "spell" && is_real_number(item.system.level)) {
          list = favSpells[item.system.level].spells;
        } else {
          list = favItems;
        }
        let dragSource = list.find((i) => i._id === itemId);
        let siblings = list.filter((i) => i._id !== itemId);
        let targetId = ev.target.closest(".item").dataset.itemId;
        let dragTarget = siblings.find((s) => s._id === targetId);
        debug(
          `tidy5e-favorites | addFavorite | dragSource: ${dragSource} // siblings: ${siblings} // targetID: ${targetId} // dragTarget: ${dragTarget}`
        );
        if (dragTarget === void 0) {
          debug(
            `tidy5e-favorites | addFavorite | catch trying to drag from one list to the other, which is not supported, folder not supported`
          );
          return;
        }
        const sortUpdates = SortingHelpers.performIntegerSort(dragSource, {
          target: dragTarget,
          siblings,
          sortKey: "flags.tidy5e-sheet.sort"
        });
        const updateData = sortUpdates.map((u) => {
          const update = u.update;
          update._id = u.target._id;
          return update;
        });
        app.actor.updateEmbeddedDocuments("Item", updateData);
      });
      favHtml.find(".item-detail input.uses-max").off("change");
      favHtml.find(".item-detail input.uses-max").click((ev) => ev.target.select()).change(async (event) => {
        event.preventDefault();
        const itemId = event.currentTarget.closest(".item").dataset.itemId;
        const item = app.actor.items.get(itemId);
        const uses = parseInt(event.target.value ?? item.system.uses.max ?? 0);
        return item.update({ "system.uses.max": uses });
      });
      favHtml.find(".item-detail input.uses-value").off("change");
      favHtml.find(".item-detail input.uses-value").click((ev) => ev.target.select()).change(async (event) => {
        event.preventDefault();
        const itemId = event.currentTarget.closest(".item").dataset.itemId;
        const item = app.actor.items.get(itemId);
        const uses = Math.clamped(0, parseInt(event.target.value), item.system.uses.max);
        event.target.value = uses;
        return item.update({ "system.uses.value": uses });
      });
      favHtml.find(".item-quantity input.item-count").off("change");
      favHtml.find(".item-quantity input.item-count").click((ev) => ev.target.select()).change(async (event) => {
        event.preventDefault();
        const itemId = event.currentTarget.closest(".item").dataset.itemId;
        const item = app.actor.items.get(itemId);
        const uses = parseInt(event.target.value ?? item.system.quantity);
        event.target.value = uses;
        return item.update({ "system.quantity": uses });
      });
    }
    favContainer.addClass("hasFavs");
    favContent.append(favHtml);
    if (position2) {
      html.find(".tab.attributes")?.scrollTop(position2.top);
    }
    if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
      favContent.find(".items-list").addClass("alt-context");
    }
    tidy5eAmmoSwitch(favHtml, app.actor);
    applyColorPickerCustomization(favHtml);
  }
}, "addFavorites");
const tidy5eContextMenu = /* @__PURE__ */ __name(function(html, sheet2) {
  const actor2 = sheet2.actor ? sheet2.actor : sheet2.parent;
  html.find(".item-list .item .item-name").mousedown(async (event) => {
    if (event.which === 2) {
      debug(`tidy5eContextMenu | middle click`);
      event.preventDefault();
      let li = $(event.target).parents(".item");
      if (li && li[0]) {
        const itemId = li[0].dataset.itemId;
        const effectId = li[0].dataset.effectId;
        if (!itemId && !effectId || !actor2) {
          return;
        }
        if (itemId) {
          let item = actor2.items.get(itemId);
          if (!item) {
            return;
          }
          item.sheet.render(true);
        }
        if (effectId) {
          let effect = actor2.effects.get(effectId);
          if (!effect) {
            return;
          }
          effect.sheet.render(true);
        }
      }
    }
  });
  if (!sheet2.getActiveEffectContextOptionsId) {
    sheet2.getActiveEffectContextOptionsId = Hooks.on(
      "dnd5e.getActiveEffectContextOptions",
      (effect, contextOptions) => {
        const actor3 = effect.actor ? effect.actor : effect.parent;
        if (actor3?.isOwner) {
          contextOptions = contextOptions.filter((obj) => {
            return ![
              "DND5E.ContextMenuActionEdit",
              "DND5E.ContextMenuActionDuplicate",
              "DND5E.ContextMenuActionDelete",
              "DND5E.ContextMenuActionEnable",
              "DND5E.ContextMenuActionDisable",
              "DND5E.ContextMenuActionUnattune",
              "DND5E.ContextMenuActionAttune",
              "DND5E.ContextMenuActionUnequip",
              "DND5E.ContextMenuActionEquip",
              "DND5E.ContextMenuActionUnprepare",
              "DND5E.ContextMenuActionPrepare"
            ].includes(obj?.name);
          });
          if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
            contextOptions = [];
          } else {
            let tidy5eContextOptions = _getActiveEffectContextOptions(effect);
            contextOptions = tidy5eContextOptions.concat(contextOptions);
          }
          ui.context.menuItems = contextOptions;
        }
      }
    );
  }
  if (!sheet2.getItemContextOptionsId) {
    sheet2.getItemContextOptionsId = Hooks.on("dnd5e.getItemContextOptions", (item, contextOptions) => {
      const actor3 = item.actor ? item.actor : item.parent;
      if (actor3?.isOwner) {
        contextOptions = contextOptions.filter((obj) => {
          return ![
            "DND5E.ContextMenuActionEdit",
            "DND5E.ContextMenuActionDuplicate",
            "DND5E.ContextMenuActionDelete",
            "DND5E.ContextMenuActionEnable",
            "DND5E.ContextMenuActionDisable",
            "DND5E.ContextMenuActionUnattune",
            "DND5E.ContextMenuActionAttune",
            "DND5E.ContextMenuActionUnequip",
            "DND5E.ContextMenuActionEquip",
            "DND5E.ContextMenuActionUnprepare",
            "DND5E.ContextMenuActionPrepare"
          ].includes(obj?.name);
        });
        if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
          if (item.type === "spell" && !item.actor.getFlag(CONSTANTS.MODULE_ID, "tidy5e-sheet.spellbook-grid")) {
            contextOptions = [];
          } else if (item.type !== "spell" && !item.actor.getFlag(CONSTANTS.MODULE_ID, "inventory-grid")) {
            contextOptions = [];
          } else {
            let tidy5eContextOptions = _getItemContextOptions(item);
            contextOptions = tidy5eContextOptions.concat(contextOptions);
          }
        } else {
          let tidy5eContextOptions = _getItemContextOptions(item);
          contextOptions = tidy5eContextOptions.concat(contextOptions);
        }
        ui.context.menuItems = contextOptions;
      }
    });
  }
  if (!sheet2.getItemAdvancementContextId) {
    sheet2.getItemAdvancementContextId = Hooks.on("dnd5e.getItemAdvancementContext", (html2, contextOptions) => {
    });
  }
}, "tidy5eContextMenu");
const _getActiveEffectContextOptions = /* @__PURE__ */ __name(function(effect) {
  const actor2 = effect.actor ? effect.actor : effect.parent;
  let options = [];
  options.push({
    name: effect.disabled ? "DND5E.ContextMenuActionEnable" : "DND5E.ContextMenuActionDisable",
    icon: effect.disabled ? "<i class='fas fa-check fa-fw'></i>" : "<i class='fas fa-times fa-fw'></i>",
    callback: () => effect.update({ disabled: !effect.disabled })
  });
  options.push({
    name: "DND5E.ContextMenuActionEdit",
    icon: "<i class='fas fas fa-pencil-alt fa-fw'></i>",
    callback: () => effect.sheet.render(true)
  });
  if (actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    options.push({
      name: "DND5E.ContextMenuActionDuplicate",
      icon: "<i class='fas fa-copy fa-fw'></i>",
      callback: () => effect.clone({ label: game.i18n.format("DOCUMENT.CopyOf", { name: effect.label }) }, { save: true })
    });
    options.push({
      name: "DND5E.ContextMenuActionDelete",
      icon: "<i class='fas fa-trash fa-fw' style='color: rgba(255, 30, 0, 0.65);'></i>",
      callback: () => effect.deleteDialog()
    });
  }
  return options;
}, "_getActiveEffectContextOptions");
const _getItemContextOptions = /* @__PURE__ */ __name(function(item) {
  const actor2 = item.actor ? item.actor : item.parent;
  if (!actor2) {
    return;
  }
  let options = [];
  const isCharacter = actor2.type === "character";
  actor2.type === "npc";
  actor2.type === "vehicle";
  const allowCantripToBePreparedOnContext = game.settings.get(CONSTANTS.MODULE_ID, "allowCantripToBePreparedOnContext");
  let isActive = false;
  let canPrepare = false;
  if (item.type === "spell") {
    const prep = item.system.preparation || {};
    const isAlways = prep.mode === "always";
    const isPrepared = !!prep.prepared;
    isActive = isPrepared;
    if (isAlways)
      CONFIG.DND5E.spellPreparationModes.always;
    else if (isPrepared)
      CONFIG.DND5E.spellPreparationModes.prepared;
    else
      game.i18n.localize("DND5E.SpellUnprepared");
    canPrepare = item.system.level >= 1;
  } else {
    isActive = !!item.system.equipped;
    game.i18n.localize(isActive ? "DND5E.Equipped" : "DND5E.Unequipped");
    "equipped" in item.system;
    canPrepare = item.system.level >= 1;
  }
  if ("attunement" in item.system && item.system.attunement !== CONFIG.DND5E.attunementTypes.NONE) {
    const isAttuned = item.system.attunement === CONFIG.DND5E.attunementTypes.ATTUNED;
    options.push({
      name: isAttuned ? "TIDY5E.Deattune" : "TIDY5E.Attune",
      icon: isAttuned ? "<i class='fas fa-sun fa-fw' style='color: rgba(255, 30, 0, 0.65);'></i>" : "<i class='fas fa-sun fa-fw'></i>",
      callback: () => item.update({
        "system.attunement": CONFIG.DND5E.attunementTypes[isAttuned ? "REQUIRED" : "ATTUNED"]
      })
    });
  }
  if ("equipped" in item.system) {
    const isEquipped = item.system.equipped;
    options.push({
      name: isEquipped ? "TIDY5E.Unequip" : "TIDY5E.Equip",
      icon: isEquipped ? "<i class='fas fa-user-alt fa-fw' style='color: rgba(255, 30, 0, 0.65);'></i> " : "<i class='fas fa-user-alt fa-fw'></i> ",
      callback: () => item.update({ "system.equipped": !isEquipped })
    });
  }
  if ("preparation" in item.system) {
    const isPrepared = item.system?.preparation?.prepared;
    if (allowCantripToBePreparedOnContext) {
      if (item.system.preparation.mode != "always") {
        options.push({
          name: isActive ? "TIDY5E.Unprepare" : "TIDY5E.Prepare",
          icon: isActive ? "<i class='fas fa-book fa-fw'></i>" : "<i class='fas fa-book fa-fw'></i>",
          callback: () => item.update({ "system.preparation.prepared": !isPrepared })
        });
      }
    } else {
      if (canPrepare && item.system.preparation.mode != "always") {
        options.push({
          name: isActive ? "TIDY5E.Unprepare" : "TIDY5E.Prepare",
          icon: isActive ? "<i class='fas fa-book fa-fw'></i>" : "<i class='fas fa-book fa-fw'></i>",
          callback: () => item.update({ "system.preparation.prepared": !isPrepared })
        });
      }
    }
  }
  if (isCharacter) {
    let isFav = isItemFavorite(item);
    let favoriteIcon = "fa-bookmark";
    if (game.modules.get("favorite-items")?.active) {
      favoriteIcon = game.settings.get("favorite-items", "favorite-icon");
      game.settings.get("favorite-items", "favorite-color");
    }
    options.push({
      name: isFav ? "TIDY5E.RemoveFav" : "TIDY5E.AddFav",
      icon: isFav ? `<i class='fas ${favoriteIcon} fa-fw'></i>` : `<i class='fas ${favoriteIcon} fa-fw inactive'></i>`,
      callback: () => {
        if (!item) {
          warn(`tidy5e-context-menu | _getItemContextOptions | Item no founded!`);
          return;
        }
        let isFav2 = isItemFavorite(item);
        item.update({
          "flags.tidy5e-sheet.favorite": !isFav2
        });
        if (game.modules.get("favorite-items")?.active) {
          item.update({
            "flags.favorite-items.favorite": !isFav2
          });
        }
        if (game.modules.get("favtab")?.active) {
          item.update({
            "flags.favtab.isFavorite": !isFav2
          });
        }
      }
    });
  }
  if (item.type === "spell") {
    options.push({
      name: "TIDY5E.EditSpell",
      icon: "<i class='fas fa-pencil-alt fa-fw'></i>",
      callback: () => item.sheet.render(true)
    });
    if (actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
      options.push({
        name: "DND5E.ContextMenuActionDuplicate",
        icon: "<i class='fas fa-copy fa-fw'></i>",
        condition: () => !["race", "background", "class", "subclass"].includes(item.type),
        callback: () => item.clone({ name: game.i18n.format("DOCUMENT.CopyOf", { name: item.name }) }, { save: true })
      });
      options.push({
        name: "TIDY5E.DeleteSpell",
        icon: "<i class='fas fa-trash fa-fw' style='color: rgba(255, 30, 0, 0.65);'></i>",
        callback: () => item.deleteDialog()
      });
    }
  } else {
    options.push({
      name: "DND5E.ContextMenuActionEdit",
      icon: "<i class='fas fa-pencil-alt fa-fw'></i>",
      callback: () => item.sheet.render(true)
    });
    if (actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
      options.push({
        name: "DND5E.ContextMenuActionDuplicate",
        icon: "<i class='fas fa-copy fa-fw'></i>",
        condition: () => !["race", "background", "class", "subclass"].includes(item.type),
        callback: () => item.clone({ name: game.i18n.format("DOCUMENT.CopyOf", { name: item.name }) }, { save: true })
      });
      options.push({
        name: "DND5E.ContextMenuActionDelete",
        icon: "<i class='fas fa-trash fa-fw' style='color: rgba(255, 30, 0, 0.65);'></i>",
        callback: () => item.deleteDialog()
      });
    }
  }
  return options;
}, "_getItemContextOptions");
const tidy5eShowActorArt = /* @__PURE__ */ __name(function(html, actor2) {
  let portrait = html.find(".portrait"), portraitMenu = html.find(".portrait-menu"), portraitButton = html.find(".showActorArt");
  portrait.mousedown(async (e) => {
    switch (e.which) {
      case 3:
        portraitMenu.toggleClass("hidden");
        break;
    }
  });
  portraitButton.click(function(e) {
    e.preventDefault();
    portraitMenu.addClass("hidden");
    let id = $(this).attr("id"), portraitImg = actor2.img, tokenImg = actor2.prototypeToken.texture.src;
    if (id == "showPortrait") {
      new ImagePopout(portraitImg, {
        title: "Portrait: " + actor2.name,
        shareable: true,
        uuid: actor2.uuid
      }).render(true);
    } else {
      new ImagePopout(tokenImg, {
        title: "Token: " + actor2.name,
        shareable: true,
        uuid: actor2.uuid
      }).render(true);
    }
  });
}, "tidy5eShowActorArt");
const tidy5eItemCard = /* @__PURE__ */ __name(function(html, actor2) {
  let itemCardsForAllItems = game.settings.get(CONSTANTS.MODULE_ID, "itemCardsForAllItems");
  let containerTrigger = itemCardsForAllItems ? html.find(".inventory-list:not(.character-actions-dnd5e)") : html.find(".grid-layout .inventory-list");
  let cardTrigger = itemCardsForAllItems ? html.find(".inventory-list:not(.character-actions-dnd5e) .item-list .item") : html.find(".grid-layout .item-list .item");
  let infoContainer = html.find("#item-info-container"), infoContainerContent = html.find("#item-info-container-content");
  let timer;
  let itemCardDelay = game.settings.get(CONSTANTS.MODULE_ID, "itemCardsDelay");
  if (!itemCardDelay || itemCardDelay == 0)
    itemCardDelay = false;
  let mouseOverItem = false;
  let itemCardIsFixed = false;
  let itemCardFixKey = game.settings.get(CONSTANTS.MODULE_ID, "itemCardsFixKey") || "x";
  let itemCardsAreFloating = game.settings.get(CONSTANTS.MODULE_ID, "itemCardsAreFloating");
  let sheet2, sheetWidth, sheetHeight, sheetBorderRight, sheetBorderBottom;
  if (itemCardsAreFloating) {
    infoContainer.addClass("floating");
    setTimeout(function() {
      getBounds();
    }, 500);
    containerTrigger.each(function(i, el) {
      el.addEventListener("mousemove", setCardPosition);
    });
  }
  function getBounds() {
    sheet2 = $(".tidy5e.sheet.actor");
    if (sheet2.length < 1) {
      sheet2 = $(html);
      sheetWidth = $(sheet2[0]).width();
      sheetHeight = $(sheet2[0]).height();
      sheetBorderRight = sheetWidth;
      sheetBorderBottom = sheetHeight;
    } else {
      sheetWidth = sheet2.width();
      sheetHeight = sheet2.height();
      sheetBorderRight = sheet2.offset().left + sheetWidth;
      sheetBorderBottom = sheet2.offset().top + sheetHeight;
    }
  }
  __name(getBounds, "getBounds");
  function setCardPosition(ev) {
    if (!itemCardIsFixed && mouseOverItem) {
      let card = html.find("#item-info-container.floating");
      if (card.length == 0)
        return;
      let mousePos = { x: ev.clientX, y: ev.clientY };
      let topPos = `${mousePos.y - 230}px`;
      let leftPos = `${mousePos.x + 24}px`;
      if (mousePos.x + 304 > sheetBorderRight) {
        leftPos = `${mousePos.x - 304}px`;
      }
      if (mousePos.y + 230 > sheetBorderBottom) {
        let diff = sheetBorderBottom - (mousePos.y + 230);
        topPos = `${mousePos.y - 230 + diff}px`;
      }
      card.css({
        top: topPos,
        left: leftPos
      });
    }
  }
  __name(setCardPosition, "setCardPosition");
  $(document).on("keydown", function(e) {
    if (e.key === itemCardFixKey) {
      itemCardIsFixed = true;
    }
  });
  $(document).on("keyup", function(e) {
    if (e.key === itemCardFixKey) {
      itemCardIsFixed = false;
      if (!itemCardDelay)
        removeCard();
      infoContainer.removeClass("open");
    }
  });
  let itemCardDelayCard = /* @__PURE__ */ __name(async (event) => {
    debug(`tidy5e-itemcard | itemCardDelayCard | itemCardDelaying card: ${itemCardDelay} ms`);
    timer = setTimeout(async function() {
      if (!itemCardIsFixed) {
        removeCard();
        await showCard(event);
        infoContainer.addClass("open");
      }
    }, itemCardDelay);
  }, "itemCardDelayCard");
  let resetDelay = /* @__PURE__ */ __name(() => {
    clearTimeout(timer);
    if (!itemCardIsFixed)
      infoContainer.removeClass("open");
  }, "resetDelay");
  cardTrigger.mouseenter(function(event) {
    if (!itemCardIsFixed) {
      if (!itemCardDelay)
        infoContainer.addClass("open");
    }
  });
  cardTrigger.mouseleave(function(event) {
    if (!itemCardIsFixed) {
      if (!itemCardDelay)
        hideContainer();
    }
  });
  cardTrigger.mouseenter(async (event) => {
    mouseOverItem = true;
    if (!itemCardIsFixed) {
      if (itemCardDelay)
        itemCardDelayCard(event);
      else
        showCard(event);
    }
  });
  cardTrigger.mouseleave(function(event) {
    mouseOverItem = false;
    if (!itemCardIsFixed) {
      if (!itemCardDelay)
        removeCard();
      else
        resetDelay();
    }
  });
  let item = html.find(".item");
  item.each(function() {
    this.addEventListener("mousedown", function(event) {
      switch (event.which) {
        case 3:
          event.preventDefault();
          mouseOverItem = false;
          hideContainer();
          break;
      }
    });
    this.addEventListener("dragstart", function() {
      mouseOverItem = false;
      hideContainer();
    });
  });
  async function showCard(event) {
    getBounds();
    event.preventDefault();
    let li = $(event.currentTarget).closest(".item");
    if (!actor2.items || actor2.items?.length <= 0 || !li.data("item-id")) {
      return;
    }
    let item2 = actor2.items.get(li.data("item-id"));
    if (!item2) {
      warn(`tidy5e-context-menu | showCard | no item found on actor '${actor2.name}' with id '${li.data("item-id")}'`);
      return;
    }
    let chatData = await item2.getChatData({ secrets: actor2.isOwner });
    let itemDescription = chatData.description.value;
    let infoCard = li.find(".info-card");
    infoCard.clone().appendTo(infoContainerContent);
    let infoBackground = infoContainer.find(".item-info-container-background");
    let infoDescription = infoContainerContent.find(".info-card-description");
    let props = $(`<div class="item-properties"></div>`);
    infoDescription.html(itemDescription);
    chatData.properties.forEach((p) => props.append(`<span class="tag">${p}</span>`));
    infoContainerContent.find(".info-card .description-wrap").after(props);
    infoBackground.hide();
    let innerScrollHeight = infoDescription[0].scrollHeight;
    if (innerScrollHeight > infoDescription.height()) {
      infoDescription.addClass("overflowing");
    }
  }
  __name(showCard, "showCard");
  function removeCard() {
    html.find(".item-info-container-background").show();
    infoContainerContent.find(".info-card").remove();
  }
  __name(removeCard, "removeCard");
  function hideContainer() {
    infoContainer.removeClass("open");
  }
  __name(hideContainer, "hideContainer");
  $("#item-info-container").on("click", ".button", function(e) {
    e.preventDefault();
    let itemId = $(this).closest(".info-card").attr("data-item-id");
    let action = $(this).attr("data-action");
    $(`.tidy5e-sheet .item[data-item-id='${itemId}'] .item-buttons .button[data-action='${action}']`).trigger(e);
  });
}, "tidy5eItemCard");
const signCase = {
  add: "+",
  subtract: "-",
  equals: "=",
  default: " "
};
function patchCurrency(currency) {
  if (hasProperty(currency, "pp")) {
    let ppValue = getProperty(currency, "pp") || 0;
    if (!is_lazy_number(ppValue))
      ;
    else if (String(ppValue).startsWith("0") && String(ppValue) !== "0") {
      while (String(ppValue).startsWith("0")) {
        if (String(ppValue) === "0") {
          break;
        }
        ppValue = String(ppValue).slice(1);
      }
    }
    if (!is_real_number(ppValue)) {
      ppValue = 0;
    }
    if (getProperty(currency, "pp") !== ppValue) {
      setProperty(currency, "pp", Number(ppValue ?? 0));
      info(`tidy5e-lazymoney | patchCurrency | update pp from '${getProperty(currency, "pp")}' to '${ppValue}'`);
    }
  }
  if (hasProperty(currency, "gp")) {
    let gpValue = getProperty(currency, "gp") || 0;
    if (!is_lazy_number(gpValue))
      ;
    else if (String(gpValue).startsWith("0") && String(gpValue) !== "0") {
      while (String(gpValue).startsWith("0")) {
        if (String(gpValue) === "0") {
          break;
        }
        gpValue = String(gpValue).slice(1);
      }
    }
    if (!is_real_number(gpValue)) {
      gpValue = 0;
    }
    if (getProperty(currency, "gp") !== gpValue) {
      setProperty(currency, "gp", Number(gpValue ?? 0));
      info(`tidy5e-lazymoney | patchCurrency | update gp from '${getProperty(currency, "gp")}' to '${gpValue}'`);
    }
  }
  if (hasProperty(currency, "ep")) {
    let epValue = getProperty(currency, "ep") || 0;
    if (!is_lazy_number(epValue))
      ;
    else if (String(epValue).startsWith("0") && String(epValue) !== "0") {
      while (String(epValue).startsWith("0")) {
        if (String(epValue) === "0") {
          break;
        }
        epValue = String(epValue).slice(1);
      }
    }
    if (!is_real_number(epValue)) {
      epValue = 0;
    }
    if (getProperty(currency, "ep") !== epValue) {
      setProperty(currency, "ep", Number(epValue ?? 0));
      info(`tidy5e-lazymoney | patchCurrency | update ep from '${getProperty(currency, "ep")}' to '${epValue}'`);
    }
  }
  if (hasProperty(currency, "sp")) {
    let spValue = getProperty(currency, "sp") || 0;
    if (!is_lazy_number(spValue))
      ;
    else if (String(spValue).startsWith("0") && String(spValue) !== "0") {
      while (String(spValue).startsWith("0")) {
        if (String(spValue) === "0") {
          break;
        }
        spValue = String(spValue).slice(1);
      }
    }
    if (!is_real_number(spValue)) {
      spValue = 0;
    }
    if (getProperty(currency, "sp") !== spValue) {
      setProperty(currency, "sp", Number(spValue ?? 0));
      info(`tidy5e-lazymoney | patchCurrency | update sp from '${getProperty(currency, "sp")}' to '${spValue}'`);
    }
  }
  if (hasProperty(currency, "cp")) {
    let cpValue = getProperty(currency, "cp") || 0;
    if (!is_lazy_number(cpValue))
      ;
    else if (String(cpValue).startsWith("0") && String(cpValue) !== "0") {
      while (String(cpValue).startsWith("0")) {
        if (String(cpValue) === "0") {
          break;
        }
        cpValue = String(cpValue).slice(1);
      }
    }
    if (!is_real_number(cpValue)) {
      cpValue = 0;
    }
    if (getProperty(currency, "cp") !== cpValue) {
      setProperty(currency, "cp", Number(cpValue ?? 0));
      info(`tidy5e-lazymoney | patchCurrency | update cp from '${getProperty(currency, "cp")}' to '${cpValue}'`);
    }
  }
  return currency;
}
__name(patchCurrency, "patchCurrency");
function _onChangeCurrency(ev) {
  const input = ev.target;
  const actor2 = ev.data.app.actor;
  const sheet2 = ev.data.app.options;
  let money = ev.data.app.actor.system.currency;
  money = patchCurrency(money);
  const denom = input.name.split(".")[2];
  const value = input.value;
  let sign = signCase.default;
  Object.values(signCase).forEach((val) => {
    if (value.includes(val)) {
      sign = val;
    }
  });
  const splitVal = value.split(sign);
  let delta;
  if (splitVal.length > 1) {
    delta = Number(splitVal[1]);
  } else {
    delta = Number(splitVal[0]);
    chatLog(actor2, `${game.user?.name} on ${actor2.name} has replaced ${money[denom]} ${denom} with ${delta} ${denom}.`);
    return;
  }
  let newAmount = {};
  if (!(denom === "ep" && game.settings.get(CONSTANTS.MODULE_ID, "lazyMoneyIgnoreElectrum"))) {
    switch (sign) {
      case signCase.add: {
        newAmount = addMoney(money, delta, denom);
        chatLog(actor2, `${game.user?.name} on ${actor2.name} has added ${delta} ${denom}.`);
        break;
      }
      case signCase.subtract: {
        newAmount = removeMoney(money, delta, denom);
        chatLog(actor2, `${game.user?.name} on ${actor2.name} has removed ${delta} ${denom}.`);
        if (!newAmount) {
          flash(input);
          newAmount = money;
        }
        break;
      }
      case signCase.equals: {
        newAmount = updateMoney(money, delta, denom);
        chatLog(
          actor2,
          `${game.user?.name} on ${actor2.name} has replaced ${money[denom]} ${denom} with ${delta} ${denom}.`
        );
        break;
      }
      default: {
        newAmount = updateMoney(money, delta, denom);
        chatLog(
          actor2,
          `${game.user?.name} on ${actor2.name} has replaced ${money[denom]} ${denom} with ${delta} ${denom}.`
        );
        break;
      }
    }
  } else {
    switch (sign) {
      case signCase.add: {
        newAmount[denom] = money[denom] + delta;
        chatLog(actor2, `${game.user?.name} on ${actor2.name} has added ${delta} ${denom}.`);
        break;
      }
      case signCase.subtract: {
        newAmount[denom] = money[denom] - delta;
        chatLog(actor2, `${game.user?.name} on ${actor2.name} has removed ${delta} ${denom}.`);
        break;
      }
      case signCase.equals: {
        newAmount[denom] = money[denom];
        chatLog(
          actor2,
          `${game.user?.name} on ${actor2.name} has replaced ${money[denom]} ${denom} with ${delta} ${denom}.`
        );
        break;
      }
      default: {
        newAmount[denom] = money[denom];
        chatLog(
          actor2,
          `${game.user?.name} on ${actor2.name} has replaced ${money[denom]} ${denom} with ${delta} ${denom}.`
        );
        break;
      }
    }
  }
  if (Object.keys(newAmount).length > 0) {
    sheet2.submitOnChange = false;
    actor2.update({ "system.currency": newAmount }).then(() => {
      input.value = Number(getProperty(actor2, input.name) ?? 0);
      sheet2.submitOnChange = true;
    }).catch(console.log.bind(console));
  }
}
__name(_onChangeCurrency, "_onChangeCurrency");
function chatLog(actor2, money) {
  debug(`tidy5e-lazymoney | chatlog | money: ${money}`);
  if (game.settings.get(CONSTANTS.MODULE_ID, "lazyMoneyChatLog")) {
    const msgData = {
      content: money,
      speaker: ChatMessage.getSpeaker({ actor: actor2 }),
      whisper: ChatMessage.getWhisperRecipients("GM")
    };
    return ChatMessage.create(msgData);
  } else {
    return void 0;
  }
}
__name(chatLog, "chatLog");
function getCpValue() {
  let cpValue = {};
  if (game.modules.get("world-currency-5e")?.active) {
    const ignorePP = game.settings.get("world-currency-5e", "ppAltRemove");
    const ignoreGP = game.settings.get("world-currency-5e", "gpAltRemove");
    const ignoreEP = game.settings.get("world-currency-5e", "epAltRemove");
    const ignoreSP = game.settings.get("world-currency-5e", "spAltRemove");
    const ignoreCP = game.settings.get("world-currency-5e", "cpAltRemove");
    let gpConvertb = game.settings.get("world-currency-5e", "gpConvert");
    if (!is_real_number(gpConvertb)) {
      gpConvertb = 1;
    } else {
      gpConvertb = gpConvertb;
    }
    let ppConvertb = game.settings.get("world-currency-5e", "ppConvert");
    if (!is_real_number(ppConvertb)) {
      ppConvertb = 0.1;
    } else {
      if (ppConvertb >= 1) {
        ppConvertb = gpConvertb / ppConvertb;
      } else {
        ppConvertb = gpConvertb * ppConvertb;
      }
    }
    let epConvertb = game.settings.get("world-currency-5e", "epConvert");
    if (!is_real_number(epConvertb)) {
      epConvertb = 5;
    } else {
      if (epConvertb >= 1) {
        epConvertb = gpConvertb * epConvertb;
      } else {
        epConvertb = gpConvertb / epConvertb;
      }
    }
    let spConvertb = game.settings.get("world-currency-5e", "spConvert");
    if (!is_real_number(spConvertb)) {
      spConvertb = 10;
    } else {
      if (spConvertb >= 1) {
        spConvertb = gpConvertb * spConvertb;
      } else {
        spConvertb = gpConvertb / spConvertb;
      }
    }
    let cpConvertb = game.settings.get("world-currency-5e", "cpConvert");
    if (!is_real_number(cpConvertb)) {
      cpConvertb = 100;
    } else {
      if (cpConvertb >= 1) {
        cpConvertb = gpConvertb * cpConvertb;
      } else {
        cpConvertb = gpConvertb / cpConvertb;
      }
    }
    const ppConvert = gpConvertb / ppConvertb * cpConvertb;
    const gpConvert = gpConvertb * cpConvertb;
    const epConvert = gpConvertb / epConvertb * cpConvertb;
    const spConvert = gpConvertb / spConvertb * cpConvertb;
    const cpConvert = 1;
    if (ignorePP && ignoreGP && ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {};
    }
    if (ignorePP && ignoreGP && ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        cp: { value: cpConvert, up: "", down: "" }
      };
    }
    if (ignorePP && ignoreGP && ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        sp: { value: cpConvert, up: "", down: "" }
      };
    }
    if (ignorePP && ignoreGP && ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        sp: { value: spConvert, up: "", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (ignorePP && ignoreGP && !ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        ep: { value: cpConvert, up: "", down: "" }
      };
    }
    if (ignorePP && ignoreGP && !ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        ep: { value: epConvert, up: "", down: "sp" },
        cp: { value: cpConvert, up: "ep", down: "" }
      };
    }
    if (ignorePP && ignoreGP && !ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        ep: { value: epConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "" }
      };
    }
    if (ignorePP && ignoreGP && !ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        ep: { value: epConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "gp", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "cp" },
        cp: { value: cpConvert, up: "gp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "gp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "gp", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && !ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && !ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "cp" },
        cp: { value: cpConvert, up: "ep", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && !ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "" }
      };
    }
    if (ignorePP && !ignoreGP && !ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        gp: { value: gpConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: cpConvert, up: "", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "cp" },
        cp: { value: cpConvert, up: "pp", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "pp", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "sp" },
        sp: { value: spConvert, up: "pp", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && !ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "pp", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && !ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "pp", down: "cp" },
        cp: { value: cpConvert, up: "ep", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && !ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "pp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "" }
      };
    }
    if (!ignorePP && ignoreGP && !ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "ep" },
        ep: { value: epConvert, up: "pp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "cp" },
        cp: { value: cpConvert, up: "gp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "sp" },
        sp: { value: spConvert, up: "gp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "sp" },
        sp: { value: spConvert, up: "gp", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && !ignoreEP && ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && !ignoreEP && ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "cp" },
        cp: { value: cpConvert, up: "ep", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && !ignoreEP && !ignoreSP && ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "" }
      };
    }
    if (!ignorePP && !ignoreGP && !ignoreEP && !ignoreSP && !ignoreCP) {
      cpValue = {
        pp: { value: ppConvert, up: "", down: "gp" },
        gp: { value: gpConvert, up: "pp", down: "ep" },
        ep: { value: epConvert, up: "gp", down: "sp" },
        sp: { value: spConvert, up: "ep", down: "cp" },
        cp: { value: cpConvert, up: "sp", down: "" }
      };
    }
  } else {
    if (game.settings.get(CONSTANTS.MODULE_ID, "lazyMoneyIgnoreElectrum")) {
      cpValue = {
        pp: { value: 1e3, up: "", down: "gp" },
        gp: { value: 100, up: "pp", down: "sp" },
        sp: { value: 10, up: "gp", down: "cp" },
        cp: { value: 1, up: "sp", down: "" }
      };
    } else {
      cpValue = {
        pp: { value: 1e3, up: "", down: "gp" },
        gp: { value: 100, up: "pp", down: "ep" },
        ep: { value: 50, up: "gp", down: "sp" },
        sp: { value: 10, up: "ep", down: "cp" },
        cp: { value: 1, up: "sp", down: "" }
      };
    }
  }
  let total = 1;
  const convert = CONFIG.DND5E.currencies;
  Object.values(convert).reverse().forEach((v) => {
    if (v.conversion !== void 0) {
      total *= v.conversion.each;
      if (cpValue[v.conversion.into]) {
        cpValue[v.conversion.into].value = total;
      }
    }
  });
  return cpValue;
}
__name(getCpValue, "getCpValue");
function getDelta(delta, denom) {
  const cpValue = getCpValue();
  let newDelta = {};
  delta *= cpValue[denom].value;
  for (let key in cpValue) {
    const myValue = cpValue[key].value;
    let intDiv = Number(~~(delta / myValue));
    if (intDiv > 0) {
      newDelta[key] = intDiv;
      delta %= myValue;
    }
  }
  return newDelta;
}
__name(getDelta, "getDelta");
function scaleDown(oldAmount, denom) {
  const cpValue = getCpValue();
  const up = cpValue[denom].up;
  let newAmount = oldAmount;
  if (newAmount[up] > 0) {
    newAmount[up] -= 1;
    newAmount[denom] += ~~(cpValue[up].value / cpValue[denom].value);
    return newAmount;
  } else if (newAmount[up] === 0) {
    newAmount = scaleDown(newAmount, up);
    scaleDown(newAmount, denom);
    return newAmount;
  } else {
    return false;
  }
}
__name(scaleDown, "scaleDown");
function addMoney(oldAmount, delta, denom) {
  const cpValue = getCpValue();
  let newAmount = {};
  if (game.settings.get(CONSTANTS.MODULE_ID, "lazyMoneyAddConvert")) {
    let cpDelta = delta * cpValue[denom].value;
    for (let key in cpValue) {
      const myValue = cpValue[key].value;
      newAmount[key] = oldAmount[key] + ~~(cpDelta / myValue);
      cpDelta %= myValue;
    }
  } else {
    newAmount[denom] = oldAmount[denom] + delta;
  }
  return newAmount;
}
__name(addMoney, "addMoney");
function removeMoney(oldAmount, delta, denom) {
  const cpValue = getCpValue();
  let newAmount = oldAmount;
  let newDelta = {};
  let down;
  if (oldAmount[denom] >= delta) {
    newAmount[denom] = oldAmount[denom] - delta;
    return newAmount;
  } else {
    newDelta = getDelta(delta, denom);
    const myValue = cpValue[denom].value;
    delta = delta * myValue;
  }
  if (totalMoney(oldAmount) >= delta) {
    for (let [key, value] of Object.entries(newDelta)) {
      if (newAmount[key] >= value) {
        newAmount[key] -= value;
      } else if (scaleDown(newAmount, key)) {
        newAmount[key] -= value;
      } else {
        newAmount = oldAmount;
        while (newAmount[key] <= value && totalMoney(newAmount) > 0 && key !== "cp") {
          down = cpValue[key].down;
          value -= newAmount[key];
          newAmount[key] = 0;
          const myValue = cpValue[key].value;
          const myDown = cpValue[down].value;
          value *= ~~(myValue / myDown);
          key = down;
        }
        newAmount[key] -= value;
      }
    }
    return newAmount;
  } else {
    return false;
  }
}
__name(removeMoney, "removeMoney");
function updateMoney(oldAmount, delta, denom) {
  let newAmount = {};
  newAmount[denom] = delta;
  return newAmount;
}
__name(updateMoney, "updateMoney");
function totalMoney(money) {
  const cpValue = getCpValue();
  let total = 0;
  for (let key in cpValue) {
    const myValue = cpValue[key].value;
    total += money[key] * myValue;
  }
  return total;
}
__name(totalMoney, "totalMoney");
function flash(input) {
  input.style.backgroundColor = "rgba(255, 0, 0, 0.5)";
  setTimeout(() => {
    input.style.backgroundColor = "";
  }, 150);
}
__name(flash, "flash");
function applyLazyMoney(app, html, actorData) {
  if (!game.settings.get(CONSTANTS.MODULE_ID, "lazyMoneyEnable")) {
    return;
  }
  if (game.modules.get("lazymoney")?.active) {
    return;
  }
  for (const elem of html.find("input[name^='system.currency']")) {
    elem.type = "text";
    elem.classList.add("lazymoney");
  }
  html.find("input[name^='system.currency']").off("change");
  html.find("input[name^='system.currency']").change(
    {
      app,
      data: actorData
    },
    _onChangeCurrency
  );
}
__name(applyLazyMoney, "applyLazyMoney");
class LongRestDialog extends Dialog {
  static {
    __name(this, "LongRestDialog");
  }
  constructor(actor2, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor2;
  }
  /* -------------------------------------------- */
  /** @inheritDoc */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dnd5e/templates/apps/long-rest.hbs",
      classes: ["dnd5e", "dialog"]
    });
  }
  /* -------------------------------------------- */
  /** @inheritDoc */
  getData() {
    const data = super.getData();
    const variant = game.settings.get("dnd5e", "restVariant");
    data.promptNewDay = variant !== "gritty";
    data.newDay = variant === "normal";
    return data;
  }
  /* -------------------------------------------- */
  /**
   * A helper constructor function which displays the Long Rest confirmation dialog and returns a Promise once it's
   * workflow has been resolved.
   * @param {object} [options={}]
   * @param {Actor5e} [options.actor]  Actor that is taking the long rest.
   * @returns {Promise}                Promise that resolves when the rest is completed or rejects when canceled.
   */
  static async longRestDialog({ actor: actor2 } = {}) {
    return new Promise((resolve, reject) => {
      const dlg = new this(actor2, {
        title: `${game.i18n.localize("DND5E.LongRest")}: ${actor2.name}`,
        buttons: {
          rest: {
            icon: '<i class="fas fa-bed"></i>',
            label: game.i18n.localize("DND5E.Rest"),
            callback: (html) => {
              let newDay = true;
              if (game.settings.get("dnd5e", "restVariant") !== "gritty") {
                newDay = html.find('input[name="newDay"]')[0].checked;
              }
              resolve(newDay);
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: game.i18n.localize("Cancel"),
            callback: reject
          }
        },
        default: "rest",
        close: reject
      });
      dlg.render(true);
    });
  }
}
class ShortRestDialog extends Dialog {
  static {
    __name(this, "ShortRestDialog");
  }
  constructor(actor2, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor2;
    this._denom = null;
  }
  /* -------------------------------------------- */
  /** @inheritDoc */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dnd5e/templates/apps/short-rest.hbs",
      classes: ["dnd5e", "dialog"]
    });
  }
  /* -------------------------------------------- */
  /** @inheritDoc */
  getData() {
    const data = super.getData();
    const hd = {};
    const hitDice = isLessThanOneIsOne(this.actor.system.details.cr) + "d6";
    const denom = hitDice ?? "d6";
    const available = 1;
    hd[denom] = denom in hd ? hd[denom] + available : available;
    data.availableHD = hd;
    data.canRoll = true;
    data.denomination = this._denom;
    const variant = game.settings.get("dnd5e", "restVariant");
    data.promptNewDay = variant !== "epic";
    data.newDay = false;
    return data;
  }
  /* -------------------------------------------- */
  /** @inheritDoc */
  activateListeners(html) {
    super.activateListeners(html);
    let btn = html.find("#roll-hd");
    btn.click(this._onRollHitDie.bind(this));
    btn.hide();
  }
  /* -------------------------------------------- */
  /**
   * Handle rolling a Hit Die as part of a Short Rest action
   * @param {Event} event     The triggering click event
   * @protected
   */
  async _onRollHitDie(event) {
    event.preventDefault();
    const btn = event.currentTarget;
    this._denom = btn.form.hd.value;
    await this.rollHitDieNPC(this._denom);
    this.render();
  }
  /* -------------------------------------------- */
  /**
   * A helper constructor function which displays the Short Rest dialog and returns a Promise once it's workflow has
   * been resolved.
   * @param {object} [options={}]
   * @param {Actor5e} [options.actor]  Actor that is taking the short rest.
   * @returns {Promise}                Promise that resolves when the rest is completed or rejects when canceled.
   */
  static async shortRestDialog({ actor: actor2 } = {}) {
    return new Promise((resolve, reject) => {
      const dlg = new this(actor2, {
        title: `${game.i18n.localize("DND5E.ShortRest")}: ${actor2.name}`,
        buttons: {
          rest: {
            icon: '<i class="fas fa-bed"></i>',
            label: game.i18n.localize("DND5E.Rest"),
            callback: (html) => {
              let newDay = false;
              if (game.settings.get("dnd5e", "restVariant") !== "epic") {
                newDay = html.find('input[name="newDay"]')[0].checked;
              }
              resolve(newDay);
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: game.i18n.localize("Cancel"),
            callback: reject
          }
        },
        close: reject
      });
      dlg.render(true);
    });
  }
  /* -------------------------------------------- */
  /**
   * Roll a hit die of the appropriate type, gaining hit points equal to the die roll plus your CON modifier.
   * @param {string} [denomination]  The hit denomination of hit die to roll. Example "d8".
   *                                 If no denomination is provided, the first available HD will be used
   * @param {object} options         Additional options which modify the roll.
   * @returns {Promise<Roll|null>}   The created Roll instance, or null if no hit die was rolled
   */
  async rollHitDieNPC(denomination, options = {}) {
    const flavor = game.i18n.localize("DND5E.HitDiceRoll");
    const rollConfig = foundry.utils.mergeObject(
      {
        formula: `max(0, 1${denomination} + @abilities.con.mod)`,
        data: this.actor.getRollData(),
        chatMessage: true,
        messageData: {
          speaker: ChatMessage.getSpeaker({ actor: this.actor }),
          flavor,
          title: `${flavor}: ${this.actor.name}`,
          rollMode: game.settings.get("core", "rollMode"),
          "flags.dnd5e.roll": { type: "hitDie" }
        }
      },
      options
    );
    if (Hooks.call("dnd5e.preRollHitDie", this.actor, rollConfig, denomination) === false)
      return;
    const roll = await new Roll(rollConfig.formula, rollConfig.data).roll({ async: true });
    if (rollConfig.chatMessage)
      roll.toMessage(rollConfig.messageData);
    const hp = this.actor.system.attributes.hp;
    const dhp = Math.min(hp.max + (hp.tempmax ?? 0) - hp.value, roll.total);
    const updates = {
      actor: { "system.attributes.hp.value": hp.value + dhp }
      //   class: {"system.hitDiceUsed": cls.system.hitDiceUsed + 1}
    };
    if (Hooks.call("dnd5e.rollHitDie", this.actor, roll, updates) === false)
      return roll;
    const updateOptions = { dhp: (updates.actor?.["system.attributes.hp.value"] ?? hp.value) - hp.value };
    if (!foundry.utils.isEmpty(updates.actor))
      await this.actor.update(updates.actor, updateOptions);
    return roll;
  }
}
let npcScrollPos = 0;
Handlebars.registerHelper("check", function(value, comparator) {
  return value === comparator ? "No content" : value;
});
class Tidy5eNPC extends dnd5e.applications.actor.ActorSheet5eNPC {
  static {
    __name(this, "Tidy5eNPC");
  }
  /**
   * Define default rendering options for the NPC sheet
   * @return {Object}
   */
  static get defaultOptions() {
    let defaultTab = game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") != "default" ? game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") : "attributes";
    if (!game.modules.get("character-actions-list-5e")?.active && game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") == "actions") {
      defaultTab = "attributes";
    }
    return mergeObject(super.defaultOptions, {
      classes: ["tidy5e", "sheet", "actor", "npc"],
      width: game.settings.get(CONSTANTS.MODULE_ID, "npsSheetWidth") ?? 740,
      height: 720,
      tabs: [
        {
          navSelector: ".tabs",
          contentSelector: ".sheet-body",
          initial: defaultTab
        }
      ]
    });
  }
  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */
  /**
   * Get the correct HTML template path to use for rendering this particular sheet
   * @type {String}
   */
  get template() {
    if (!game.user.isGM && this.actor.limited)
      return "modules/tidy5e-sheet/templates/actors/tidy5e-npc-ltd.html";
    return "modules/tidy5e-sheet/templates/actors/tidy5e-npc.html";
  }
  /* -------------------------------------------- */
  /**
   * Organize Owned Items for rendering the NPC sheet
   * @override
   * @private
   */
  _prepareItems(context) {
    const features = {
      weapons: {
        label: game.i18n.localize("DND5E.AttackPl"),
        items: [],
        hasActions: true,
        dataset: { type: "weapon", "weapon-type": "natural" }
      },
      actions: {
        label: game.i18n.localize("DND5E.ActionPl"),
        items: [],
        hasActions: true,
        dataset: { type: "feat", "activation.type": "action" }
      },
      passive: { label: game.i18n.localize("DND5E.Features"), items: [], dataset: { type: "feat" } },
      equipment: { label: game.i18n.localize("DND5E.Inventory"), items: [], dataset: { type: "loot" } }
    };
    let [spells, other] = context.items.reduce(
      (arr, item) => {
        const { quantity, uses, recharge, target } = item.system;
        const ctx = context.itemContext[item.id] ??= {};
        ctx.isStack = Number.isNumeric(quantity) && quantity !== 1;
        ctx.hasUses = uses && uses.max > 0;
        ctx.isOnCooldown = recharge && !!recharge.value && recharge.charged === false;
        ctx.isDepleted = item.isOnCooldown && uses.per && uses.value > 0;
        ctx.hasTarget = !!target && !["none", ""].includes(target.type);
        ctx.canToggle = false;
        if (item.type === "spell")
          arr[0].push(item);
        else
          arr[1].push(item);
        return arr;
      },
      [[], []]
    );
    spells = this._filterItems(spells, this._filters.spellbook);
    other = this._filterItems(other, this._filters.features);
    const spellbook = this._prepareSpellbook(context, spells);
    for (let item of other) {
      if (item.type === "weapon")
        features.weapons.items.push(item);
      else if (item.type === "feat") {
        if (item.system.activation.type)
          features.actions.items.push(item);
        else
          features.passive.items.push(item);
      } else
        features.equipment.items.push(item);
    }
    context.inventoryFilters = true;
    context.spellbook = spellbook;
    const sortingOrder = {
      equipment: 1,
      consumable: 2
    };
    features.equipment.items.sort((a, b) => {
      if (!a.hasOwnProperty("type") || !b.hasOwnProperty("type")) {
        return 0;
      }
      const first = a["type"].toLowerCase() in sortingOrder ? sortingOrder[a["type"]] : Number.MAX_SAFE_INTEGER;
      const second = b["type"].toLowerCase() in sortingOrder ? sortingOrder[b["type"]] : Number.MAX_SAFE_INTEGER;
      let result = 0;
      if (first < second) {
        result = -1;
      } else if (first > second) {
        result = 1;
      }
      return result;
    });
    context.features = Object.values(features);
  }
  /* -------------------------------------------- */
  /**
   * A helper method to establish the displayed preparation state for an item
   * @param {Item} item
   * @private
   */
  // TODO to remove with system 2.1.X
  _prepareItemToggleState(item) {
    if (item.type === "spell") {
      const isAlways = getProperty(item.system, "preparation.mode") === "always";
      const isPrepared = getProperty(item.system, "preparation.prepared");
      item.toggleClass = isPrepared ? "active" : "";
      if (isAlways)
        item.toggleClass = "fixed";
      if (isAlways)
        item.toggleTitle = CONFIG.DND5E.spellPreparationModes.always;
      else if (isPrepared)
        item.toggleTitle = CONFIG.DND5E.spellPreparationModes.prepared;
      else
        item.toggleTitle = game.i18n.localize("DND5E.SpellUnprepared");
    } else {
      const isActive = getProperty(item.system, "equipped");
      item.toggleClass = isActive ? "active" : "";
      item.toggleTitle = game.i18n.localize(isActive ? "DND5E.Equipped" : "DND5E.Unequipped");
    }
  }
  /* -------------------------------------------- */
  /**
   * Add some extra data when rendering the sheet to reduce the amount of logic required within the template.
   */
  async getData(options) {
    const context = await super.getData(options);
    Object.keys(context.abilities).forEach((id) => {
      context.abilities[id].abbr = CONFIG.DND5E.abilities[id].abbreviation;
    });
    context.journalNotes1HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes1?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes2HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes2?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes3HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes3?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes4HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes4?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalHTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.appId = this.appId;
    context.allowCantripToBePreparedOnContext = game.settings.get(
      CONSTANTS.MODULE_ID,
      "allowCantripToBePreparedOnContext"
    );
    context.hideSpellbookTabNpc = game.settings.get(CONSTANTS.MODULE_ID, "hideSpellbookTabNpc");
    context.isGM = game.user.isGM;
    context.allowHpMaxOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpMaxOverride");
    context.allowHpConfigOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpConfigOverride");
    context.rightClickDisabled = game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled");
    context.classicControlsEnabled = game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.classicControlsDisabled = !game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.notHideIconsNextToTheItemName = !game.settings.get(CONSTANTS.MODULE_ID, "hideIconsNextToTheItemName");
    context.hpOverlayCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpOverlayCalculationCurrent = context.hpOverlayCalculationCurrent + "%";
    context.hpBarCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpBarCalculationCurrent = context.hpBarCalculationCurrent + "%";
    if (!is_real_number(this.actor.flags[CONSTANTS.MODULE_ID]?.exhaustion)) {
      setProperty(this.actor, `flags.tidy5e-sheet.exhaustion`, 0);
    }
    const exhaustionTooltipPrefix = `${game.i18n.localize("DND5E.Exhaustion")} ${game.i18n.localize(
      "DND5E.AbbreviationLevel"
    )} ${this.actor.flags[CONSTANTS.MODULE_ID].exhaustion}`;
    if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 0) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion0")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 1) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion1")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 2) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion2")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 3) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion3")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 4) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion4")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 5) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion5")}`;
    } else if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion === 6) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion6")}`;
    } else {
      context.exhaustionTooltip = exhaustionTooltipPrefix;
    }
    if (!is_real_number(this.actor.flags[CONSTANTS.MODULE_ID]?.death?.success)) {
      setProperty(this.actor, `flags.tidy5e-sheet.death.success`, 0);
    }
    if (!is_real_number(this.actor.flags[CONSTANTS.MODULE_ID]?.death?.failure)) {
      setProperty(this.actor, `flags.tidy5e-sheet.death.failure`, 0);
    }
    return context;
  }
  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */
  /**
   * Activate event listeners using the prepared sheet HTML
   * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
   */
  activateListeners(html) {
    super.activateListeners(html);
    let actor2 = this.actor;
    tidy5eListeners(html, actor2, this);
    tidy5eContextMenu(html, this);
    tidy5eShowActorArt(html, actor2);
    if (game.settings.get(CONSTANTS.MODULE_ID, "itemCardsForNpcs")) {
      tidy5eItemCard(html, actor2);
    }
    tidy5eAmmoSwitch(html, actor2);
    html.find(".portrait-hp-formula span.rollable").mousedown(async (event) => {
      switch (event.which) {
        case 3: {
          let formula = actor2.system.attributes.hp.formula;
          debug(`tidy5e-npc | activateListeners | formula: ${formula}`);
          let r = new Roll(formula);
          let term = r.terms;
          debug(`tidy5e-npc | activateListeners | term: ${term}`);
          let averageString = "";
          for (let i = 0; i < term.length; i++) {
            let type = term[i].constructor.name;
            switch (type) {
              case "Die": {
                averageString += Math.floor((term[i].faces * term[i].number + term[i].number) / 2);
                break;
              }
              case "OperatorTerm": {
                averageString += term[i].operator;
                break;
              }
              case "NumericTerm": {
                averageString += term[i].number;
                break;
              }
            }
          }
          debug(`tidy5e-npc | activateListeners | averageString: ${averageString}`);
          let average = 0;
          averageString = averageString.replace(/\s/g, "").match(/[+\-]?([0-9\.\s]+)/g) || [];
          while (averageString.length) {
            average += parseFloat(averageString.shift());
          }
          debug(`tidy5e-npc | activateListeners | average: ${average}`);
          let data = {};
          data["system.attributes.hp.value"] = average;
          data["system.attributes.hp.max"] = average;
          actor2.update(data);
          break;
        }
      }
    });
    html.find(".toggle-personality-info").click(async (event) => {
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "showNpcPersonalityInfo")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "showNpcPersonalityInfo");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "showNpcPersonalityInfo", true);
      }
    });
    html.find(".rollable[data-action=rollInitiative]").click(function() {
      return actor2.rollInitiative({ createCombatants: true });
    });
    let attributesTab = html.find(".tab.attributes");
    attributesTab.scroll(function() {
      npcScrollPos = $(this).scrollTop();
    });
    let tabNav = html.find('a.item:not([data-tab="attributes"])');
    tabNav.click(function() {
      npcScrollPos = 0;
      attributesTab.scrollTop(npcScrollPos);
    });
    html.find(".health .rollable").click(this._onRollHealthFormula.bind(this));
    html.find(".skills-list .toggle-proficient").click(async (event) => {
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "npcSkillsExpanded")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "npcSkillsExpanded");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "npcSkillsExpanded", true);
      }
    });
    html.find(".traits .toggle-traits").click(async (event) => {
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "traitsExpanded")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "traitsExpanded");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "traitsExpanded", true);
      }
    });
    html.find(".exhaust-level li").click(async (event) => {
      event.preventDefault();
      let target = event.currentTarget;
      let value = Number(target.dataset.elvl);
      await actor2.update({ "flags.tidy5e-sheet.exhaustion": value });
      setProperty(actor2, "flags.tidy5e-sheet.exhaustion", value);
      if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") != "default") {
        if (actor2.constructor.name != "Actor5e")
          ;
        else {
          updateExhaustion(actor2);
        }
      }
    });
    html.find(".item:not(.items-header) input").change((event) => {
      event.target.value;
      let itemId = $(event.target).parents(".item")[0].dataset.itemId;
      let path = event.target.dataset.path;
      let data = {};
      data[path] = Number(event.target.value);
      actor2.items.get(itemId).update(data);
    });
    html.find(".inventory-list .item .addCharges").click((event) => {
      let itemId = $(event.target).parents(".item")[0].dataset.itemId;
      let item = actor2.items.get(itemId);
      item.system.uses = { value: 1, max: 1 };
      let data = {};
      data["system.uses.value"] = 1;
      data["system.uses.max"] = 1;
      actor2.items.get(itemId).update(data);
    });
    html.find(".item-detail input.uses-max").off("change");
    html.find(".item-detail input.uses-max").click((ev) => ev.target.select()).change(_onUsesMaxChange$1.bind(this));
    html.find(".item-detail input.uses-value").off("change");
    html.find(".item-detail input.uses-value").click((ev) => ev.target.select()).change(_onUsesChange$1.bind(this));
    html.find(".item-quantity input.item-count").off("change");
    html.find(".item-quantity input.item-count").click((ev) => ev.target.select()).change(_onQuantityChange$1.bind(this));
    html.find(".short-rest").click(this._onShortRest.bind(this));
    html.find(".long-rest").click(this._onLongRest.bind(this));
    html.find(".death-save-tidy").click(this._rollDeathSave.bind(this));
  }
  /* -------------------------------------------- */
  /**
   * Handle duplicate an existing Item entry from the Advancement.
   * @param {Event} event        The originating click event.
   * @returns {Promise<Item5e>}  The updated parent Item after the application re-renders.
   * @protected
   */
  async _onItemDuplicate(event) {
    event.preventDefault();
    const uuidToDuplicate = event.currentTarget.closest("[data-item-id]")?.dataset.itemId;
    if (!uuidToDuplicate)
      return;
    const item = this.actor.items.get(uuidToDuplicate);
    item.clone({ name: game.i18n.format("DOCUMENT.CopyOf", { name: item.name }) }, { save: true });
  }
  /* -------------------------------------------- */
  /**
   * Handle rolling NPC health values using the provided formula
   * @param {Event} event     The original click event
   * @private
   */
  async _onRollHealthFormula(event) {
    event.preventDefault();
    const formula = this.actor.system.attributes.hp.formula;
    if (!formula)
      return;
    const roll_hp = await new Roll(formula).roll();
    const hp = roll_hp.total;
    AudioHelper.play({ src: CONFIG.sounds.dice });
    this.actor.update({
      "system.attributes.hp.value": hp,
      "system.attributes.hp.max": hp
    });
  }
  /* -------------------------------------------- */
  /**
   * Take a short rest, calling the relevant function on the Actor instance
   * @param {Event} event   The triggering click event
   * @private
   */
  async _onShortRest(event) {
    event.preventDefault();
    await this._onSubmit(event);
    if (game.settings.get(CONSTANTS.MODULE_ID, "restingForNpcsChatDisabled")) {
      let obj = {
        dialog: true,
        chat: false
      };
      return this.shortRest(obj);
    }
    return this.shortRest();
  }
  /* -------------------------------------------- */
  /**
   * Take a long rest, calling the relevant function on the Actor instance
   * @param {Event} event   The triggering click event
   * @private
   */
  async _onLongRest(event) {
    event.preventDefault();
    await this._onSubmit(event);
    if (game.settings.get(CONSTANTS.MODULE_ID, "restingForNpcsChatDisabled")) {
      let obj = {
        dialog: true,
        chat: false
      };
      return this.longRest(obj);
    }
    return this.longRest();
  }
  /* -------------------------------------------- */
  /**
   * Take a short rest, possibly spending hit dice and recovering resources, item uses, and pact slots.
   * @param {RestConfiguration} [config]  Configuration options for a short rest.
   * @returns {Promise<RestResult>}       A Promise which resolves once the short rest workflow has completed.
   */
  async shortRest(config = {}) {
    config = foundry.utils.mergeObject(
      {
        dialog: true,
        chat: true,
        newDay: false,
        autoHD: false,
        autoHDThreshold: 3
      },
      config
    );
    if (Hooks.call("dnd5e.preShortRest", this.actor, config) === false)
      return;
    const hd0 = isLessThanOneIsOne(this.actor.system.details.cr);
    const hp0 = this.actor.system.attributes.hp.value;
    if (config.dialog) {
      try {
        config.newDay = await ShortRestDialog.shortRestDialog({ actor: this.actor, canRoll: hd0 > 0 });
      } catch (err) {
        return;
      }
    } else if (config.autoHD)
      await this.autoSpendHitDice({ threshold: config.autoHDThreshold });
    const dhd = hd0;
    const dhp = this.actor.system.attributes.hp.value - hp0;
    return this._rest(config.chat, config.newDay, false, dhd, dhp);
  }
  /* -------------------------------------------- */
  /**
   * Take a long rest, recovering hit points, hit dice, resources, item uses, and spell slots.
   * @param {RestConfiguration} [config]  Configuration options for a long rest.
   * @returns {Promise<RestResult>}       A Promise which resolves once the long rest workflow has completed.
   */
  async longRest(config = {}) {
    config = foundry.utils.mergeObject(
      {
        dialog: true,
        chat: true,
        newDay: true
      },
      config
    );
    if (Hooks.call("dnd5e.preLongRest", this.actor, config) === false)
      return;
    if (config.dialog) {
      try {
        config.newDay = await LongRestDialog.longRestDialog({ actor: this.actor });
      } catch (err) {
        return;
      }
    }
    return this._rest(config.chat, config.newDay, true);
  }
  /* -------------------------------------------- */
  /**
   * Perform all of the changes needed for a short or long rest.
   *
   * @param {boolean} chat           Summarize the results of the rest workflow as a chat message.
   * @param {boolean} newDay         Has a new day occurred during this rest?
   * @param {boolean} longRest       Is this a long rest?
   * @param {number} [dhd=0]         Number of hit dice spent during so far during the rest.
   * @param {number} [dhp=0]         Number of hit points recovered so far during the rest.
   * @returns {Promise<RestResult>}  Consolidated results of the rest workflow.
   * @private
   */
  async _rest(chat, newDay, longRest, dhd = 0, dhp = 0) {
    if (longRest || newDay) {
      this.actor.update({ "system.attributes.hp.value": Number(this.actor.system.attributes.hp.max ?? 0) });
      if (this.actor.flags[CONSTANTS.MODULE_ID].exhaustion > 0) {
        const exhaustion = this.actor.flags[CONSTANTS.MODULE_ID].exhaustion;
        debug("tidy5e-npc | _rest | exhaustion = " + exhaustion);
        await this.actor.update({ "flags.tidy5e-sheet.exhaustion": exhaustion - 1 });
        await updateExhaustion(this.actor);
      }
    } else {
      const rollData = this.actor.getRollData();
      const roll_value = await new Roll(isLessThanOneIsOne(dhd) + "d6", rollData).roll();
      const value = roll_value.total;
      let newHpValue = this.actor.system.attributes.hp.value + Number(value ?? 0);
      if (newHpValue > this.actor.system.attributes.hp.max) {
        newHpValue = this.actor.system.attributes.hp.max;
      }
      await this.actor.update({ "system.attributes.hp.value": newHpValue });
    }
    let hitPointsRecovered = 0;
    let hitPointUpdates = {};
    let hitDiceRecovered = 0;
    let hitDiceUpdates = [];
    const rolls = [];
    if (longRest) {
      ({ updates: hitPointUpdates, hitPointsRecovered } = this.actor._getRestHitPointRecovery());
      ({ updates: hitDiceUpdates, hitDiceRecovered } = this.actor._getRestHitDiceRecovery());
    }
    const result = {
      dhd: dhd + hitDiceRecovered,
      dhp: dhp + hitPointsRecovered,
      updateData: {
        ...hitPointUpdates,
        ...this.actor._getRestResourceRecovery({
          recoverShortRestResources: !longRest,
          recoverLongRestResources: longRest
        }),
        ...this.actor._getRestSpellRecovery({ recoverSpells: longRest })
      },
      updateItems: [
        ...hitDiceUpdates,
        ...await this.actor._getRestItemUsesRecovery({
          recoverLongRestUses: longRest,
          recoverDailyUses: newDay,
          rolls
        })
      ],
      longRest,
      newDay
    };
    result.rolls = rolls;
    if (Hooks.call("dnd5e.preRestCompleted", this.actor, result) === false)
      return result;
    await this.actor.update(result.updateData);
    await this.actor.updateEmbeddedDocuments("Item", result.updateItems);
    if (chat)
      await this.actor._displayRestResultMessage(result, longRest);
    Hooks.callAll("dnd5e.restCompleted", this.actor, result);
    return result;
  }
  /* -------------------------------------------- */
  /**
   * Perform a death saving throw, rolling a d20 plus any global save bonuses
   * @param {object} options          Additional options which modify the roll
   * @returns {Promise<D20Roll|null>} A Promise which resolves to the Roll instance
   */
  async _rollDeathSave(options = {}) {
    const death = this.actor.flags[CONSTANTS.MODULE_ID].death ?? {};
    if (this.actor.system.attributes.hp.value > 0 || death.failure >= 3 || death.success >= 3) {
      ui.notifications.warn(game.i18n.localize("DND5E.DeathSaveUnnecessary"));
      return null;
    }
    const speaker = options.speaker || ChatMessage.getSpeaker({ actor: this });
    const globalBonuses = this.actor.system.bonuses?.abilities ?? {};
    const parts = [];
    const data = this.actor.getRollData();
    if (this.actor.getFlag("dnd5e", "diamondSoul")) {
      parts.push("@prof");
      data.prof = new Proficiency(this.actor.system.attributes.prof, 1).term;
    }
    if (globalBonuses.save) {
      parts.push("@saveBonus");
      data.saveBonus = Roll.replaceFormulaData(globalBonuses.save, data);
    }
    const flavor = game.i18n.localize("DND5E.DeathSavingThrow");
    const rollData = foundry.utils.mergeObject(
      {
        data,
        title: `${flavor}: ${this.actor.name}`,
        flavor,
        halflingLucky: this.actor.getFlag("dnd5e", "halflingLucky"),
        targetValue: 10,
        messageData: {
          speaker,
          "flags.dnd5e.roll": { type: "death" }
        }
      },
      options
    );
    rollData.parts = parts.concat(options.parts ?? []);
    const roll = await d20Roll(rollData);
    if (!roll)
      return null;
    const details = {};
    if (roll.total >= (roll.options.targetValue ?? 10)) {
      let successes = (death.success || 0) + 1;
      if (roll.isCritical) {
        details.updates = {
          "flags.tidy5e-sheet.death.success": 0,
          "flags.tidy5e-sheet.death.failure": 0,
          "system.attributes.hp.value": 1
        };
        details.chatString = "DND5E.DeathSaveCriticalSuccess";
      } else if (successes === 3) {
        details.updates = {
          "flags.tidy5e-sheet.death.success": 0,
          "flags.tidy5e-sheet.death.failure": 0
        };
        details.chatString = "DND5E.DeathSaveSuccess";
      } else
        details.updates = { "flags.tidy5e-sheet.death.success": Math.clamped(successes, 0, 3) };
    } else {
      let failures = (death.failure || 0) + (roll.isFumble ? 2 : 1);
      details.updates = { "flags.tidy5e-sheet.death.failure": Math.clamped(failures, 0, 3) };
      if (failures >= 3) {
        details.chatString = "DND5E.DeathSaveFailure";
      }
    }
    if (!foundry.utils.isEmpty(details.updates))
      await this.actor.update(details.updates);
    if (details.chatString) {
      let chatData = { content: game.i18n.format(details.chatString, { name: this.actor.name }), speaker };
      ChatMessage.applyRollMode(chatData, roll.options.rollMode);
      await ChatMessage.create(chatData);
    }
    return roll;
  }
  /* -------------------------------------------- */
  // add actions module
  async _renderInner(...args) {
    const html = await super._renderInner(...args);
    const actionsListApi = game.modules.get("character-actions-list-5e")?.api;
    let injectNPCSheet;
    if (game.modules.get("character-actions-list-5e")?.active) {
      injectNPCSheet = game.settings.get("character-actions-list-5e", "inject-npcs");
    }
    try {
      if (game.modules.get("character-actions-list-5e")?.active && injectNPCSheet) {
        const actionsTabButton = $(
          '<a class="item" data-tab="actions">' + game.i18n.localize(`DND5E.ActionPl`) + "</a>"
        );
        const tabs = html.find('.tabs[data-group="primary"]');
        tabs.prepend(actionsTabButton);
        const sheetBody = html.find(".sheet-body");
        const actionsTab = $(`<div class="tab actions" data-group="primary" data-tab="actions"></div>`);
        const actionsLayout = $(`<div class="list-layout"></div>`);
        actionsTab.append(actionsLayout);
        sheetBody.prepend(actionsTab);
        const actionsTabHtml = $(await actionsListApi.renderActionsList(this.actor));
        actionsLayout.html(actionsTabHtml);
      }
    } catch (err) {
      error(err?.message, true);
    }
    return html;
  }
}
async function restoreScrollPosition(app, html, data) {
  html.find(".tab.attributes").scrollTop(npcScrollPos);
}
__name(restoreScrollPosition, "restoreScrollPosition");
async function toggleSkillList(app, html, data) {
  html.find(".skills-list:not(.always-visible):not(.expanded) .skill:not(.proficient)").remove();
}
__name(toggleSkillList, "toggleSkillList");
async function toggleTraitsList$2(app, html, data) {
  html.find(".traits:not(.always-visible):not(.expanded) .form-group.inactive").remove();
}
__name(toggleTraitsList$2, "toggleTraitsList$2");
async function checkDeathSaveStatus$1(app, html, data) {
  if (data.editable) {
    let actor2 = app.actor;
    var currentHealth = actor2.system.attributes.hp.value;
    var deathSaveSuccess = actor2.flags[CONSTANTS.MODULE_ID].death.success;
    var deathSaveFailure = actor2.flags[CONSTANTS.MODULE_ID].death.failure;
    debug(
      `tidy5e-npc | checkDeathSaveStatus | current HP NPC : ${currentHealth}, success: ${deathSaveSuccess}, failure: ${deathSaveFailure}`
    );
    if (currentHealth <= 0) {
      html.find(".tidy5e-sheet.tidy5e-npc .profile").addClass("dead");
    }
    if (currentHealth > 0 && deathSaveSuccess != 0 || currentHealth > 0 && deathSaveFailure != 0) {
      await actor2.update({ "flags.tidy5e-sheet.death.success": 0 });
      await actor2.update({ "flags.tidy5e-sheet.death.failure": 0 });
    }
  }
}
__name(checkDeathSaveStatus$1, "checkDeathSaveStatus$1");
async function toggleItemMode(app, html, data) {
  html.find(".item-toggle").click((ev) => {
    ev.preventDefault();
    let itemId = ev.currentTarget.closest(".item").dataset.itemId;
    let item = app.actor.items.get(itemId);
    debug(`tidy5e-npc | toggleItemMode | item.type: ${item.type}`);
    let attr = item.type === "spell" ? "system.preparation.prepared" : "system.equipped";
    if (item.type !== "feat") {
      return item.update({ [attr]: !foundry.utils.getProperty(item, attr) });
    }
  });
}
__name(toggleItemMode, "toggleItemMode");
async function resetTempHp(app, html, data) {
  let actor2 = app.actor;
  if (data.editable && !actor2.compendium) {
    let temp = actor2.system.attributes.hp.temp, tempmax = actor2.system.attributes.hp.tempmax;
    if (temp == 0) {
      actor2.update({ "system.attributes.hp.temp": null });
    }
    if (tempmax == 0) {
      actor2.update({ "system.attributes.hp.tempmax": null });
    }
  }
}
__name(resetTempHp, "resetTempHp");
async function setSheetClasses$2(app, html, data) {
  const { token } = app;
  const actor2 = app.actor;
  if (actor2.getFlag(CONSTANTS.MODULE_ID, "showNpcPersonalityInfo")) {
    html.find(".tidy5e-sheet.tidy5e-npc .left-notes").removeClass("hidden");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "journalTabNPCDisabled")) {
    html.find('.tidy5e-sheet.tidy5e-npc .tidy5e-navigation a[data-tab="journal"]').remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
    if (game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
      html.find(".tidy5e-sheet.tidy5e-npc .grid-layout .items-list").addClass("alt-context");
    } else {
      html.find(".tidy5e-sheet.tidy5e-npc .items-list").addClass("alt-context");
    }
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
    html.find(".tidy5e-sheet.tidy5e-npc .items-header-controls").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "traitsMovedBelowResourceNpc")) {
    let altPos = html.find(".alt-trait-pos");
    let traits = html.find(".traits");
    altPos.append(traits);
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "restingForNpcsEnabled")) {
    html.find(".tidy5e-sheet.tidy5e-npc .rest-container").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "npc" || game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "all") {
    html.find(".tidy5e-sheet.tidy5e-npc .profile").addClass("roundPortrait");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayDisabledNpc")) {
    html.find(".tidy5e-sheet.tidy5e-npc .profile").addClass("disable-hp-overlay");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpBarDisabled")) {
    html.find(".tidy5e-sheet.tidy5e-npc .profile").addClass("disable-hp-bar");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderNpc") > 0) {
    $(".system-dnd5e").get(0).style.setProperty("--npc-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderNpc") + "px");
  } else {
    $(".system-dnd5e").get(0).style.removeProperty("--npc-border");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "traitsAlwaysShownNpc")) {
    html.find(".tidy5e-sheet.tidy5e-npc .traits").addClass("always-visible");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "traitLabelsEnabled")) {
    html.find(".tidy5e-sheet.tidy5e-npc .traits").addClass("show-labels");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "skillsAlwaysShownNpc")) {
    html.find(".tidy5e-sheet.tidy5e-npc .skills-list").addClass("always-visible");
  }
  if (token && token.actor.prototypeToken.actorLink && game.settings.get(CONSTANTS.MODULE_ID, "linkMarkerNpc") == "both") {
    html.find(".tidy5e-sheet.tidy5e-npc").addClass("linked");
  }
  if (token && !token.actor.prototypeToken.actorLink && (game.settings.get(CONSTANTS.MODULE_ID, "linkMarkerNpc") == "unlinked" || game.settings.get(CONSTANTS.MODULE_ID, "linkMarkerNpc") == "both")) {
    html.find(".tidy5e-sheet.tidy5e-npc").addClass("unlinked");
  }
  if (!token && (game.settings.get(CONSTANTS.MODULE_ID, "linkMarkerNpc") == "unlinked" || game.settings.get(CONSTANTS.MODULE_ID, "linkMarkerNpc") == "both")) {
    html.find(".tidy5e-sheet.tidy5e-npc").addClass("original");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionDisabled")) {
    html.find(".tidy5e-sheet.tidy5e-npc .profile .exhaustion-container").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionOnHover")) {
    html.find(".tidy5e-sheet.tidy5e-npc .profile").addClass("exhaustionOnHover");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hiddenDeathSavesEnabled") && !game.user.isGM) {
    html.find(".tidy5e-sheet.tidy5e-npc .death-saves").addClass("gmOnly");
  }
  $(".info-card-hint .key").html(game.settings.get(CONSTANTS.MODULE_ID, "itemCardsFixKey"));
  applyColorPickerCustomization(html);
}
__name(setSheetClasses$2, "setSheetClasses$2");
async function abbreviateCurrency$2(app, html, data) {
  html.find(".currency .currency-item label").each(function() {
    let currency = $(this).data("denom").toUpperCase();
    let abbr = game.i18n.localize(`DND5E.CurrencyAbbr${currency}`);
    if (abbr == `DND5E.CurrencyAbbr${currency}`) {
      abbr = currency;
    }
    $(this).html(abbr);
  });
}
__name(abbreviateCurrency$2, "abbreviateCurrency$2");
async function hideSpellbook(app, html, data) {
  let spellbook = html.find(".spellbook-footer");
  if (spellbook.hasClass("spellbook-empty")) {
    html.find(".spellbook-title").addClass("toggle-spellbook");
    html.find(".spellbook-title + .list-layout").hide();
    html.find(".spellcasting-ability").hide();
    $(".toggle-spellbook").on("click", function() {
      html.find(".spellbook-title").toggleClass("show");
      html.find(".spellbook-title + .list-layout").toggle();
      html.find(".spellcasting-ability").toggle();
    });
  }
}
__name(hideSpellbook, "hideSpellbook");
async function editProtection$2(app, html, data) {
  let actor2 = app.actor;
  if (!actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    let itemContainer = html.find(".inventory-list:not(.spellbook-list).items-list");
    html.find(".inventory-list:not(.spellbook-list) .items-header").each(function() {
      if ($(this).next(".item-list").find("li").length - $(this).next(".item-list").find("li.items-footer").length == 0) {
        $(this).next(".item-list").addClass("hidden").hide();
        $(this).addClass("hidden").hide();
      }
    });
    html.find(".inventory-list .items-footer").addClass("hidden").hide();
    html.find(".inventory-list .item-control.item-delete").remove();
    html.find(".inventory-list .item-control.item-duplicate").remove();
    html.find(".effects .effect-control.effect-delete").remove();
    html.find(".effects .effect-control.effect-duplicate").remove();
    let actor3 = app.actor, legAct = actor3.system.resources.legact.max, legRes = actor3.system.resources.legres.max, lair = actor3.system.resources.lair.value;
    if (!lair && legAct < 1 && legRes < 1) {
      html.find(".counters").addClass("hidden").hide();
    }
    if (itemContainer.children().length < 1) {
      itemContainer.append(`<span class="notice">This section is empty. Unlock the sheet to edit.</span>`);
    }
  }
}
__name(editProtection$2, "editProtection$2");
async function npcFavorites(app, html, data) {
}
__name(npcFavorites, "npcFavorites");
function spellSlotMarker$1(app, html, data) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "hideSpellSlotMarker")) {
    return;
  }
  let actor2 = app.actor;
  data.actor.items;
  let options = ["pact", "spell1", "spell2", "spell3", "spell4", "spell5", "spell6", "spell7", "spell8", "spell9"];
  for (let o of options) {
    let max = html.find(`.spell-max[data-level=${o}]`);
    let name = max.closest(".spell-slots");
    let spellData = actor2.system.spells[o];
    if (spellData.max === 0) {
      continue;
    }
    let contents = ``;
    for (let i = 1; i <= spellData.max; i++) {
      if (i <= spellData.value) {
        contents += `<span class="dot"></span>`;
      } else {
        contents += `<span class="dot empty"></span>`;
      }
    }
    name.before(`<div class="spellSlotMarker">${contents}</div>`);
  }
  html.find(".spellSlotMarker .dot").mouseenter((ev) => {
    const parentEl = ev.currentTarget.parentElement;
    const index = [...parentEl.children].indexOf(ev.currentTarget);
    const dots = parentEl.querySelectorAll(".dot");
    if (ev.currentTarget.classList.contains("empty")) {
      for (let i = 0; i < dots.length; i++) {
        if (i <= index) {
          dots[i].classList.contains("empty") ? dots[i].classList.add("change") : "";
        }
      }
    } else {
      for (let i = 0; i < dots.length; i++) {
        if (i >= index) {
          dots[i].classList.contains("empty") ? "" : dots[i].classList.add("change");
        }
      }
    }
  });
  html.find(".spellSlotMarker .dot").mouseleave((ev) => {
    const parentEl = ev.currentTarget.parentElement;
    $(parentEl).find(".dot").removeClass("change");
  });
  html.find(".spellSlotMarker .dot").click(async (ev) => {
    const index = [...ev.currentTarget.parentElement.children].indexOf(ev.currentTarget);
    const slots = $(ev.currentTarget).parents(".spell-level-slots");
    const spellLevel = slots.find(".spell-max").data("level");
    debug(`tidy5e-npc | spellSlotMarker | spellLevel: ${spellLevel}, index: ${index}`);
    if (spellLevel) {
      let path = `data.spells.${spellLevel}.value`;
      if (ev.currentTarget.classList.contains("empty")) {
        await actor2.update({
          [path]: index + 1
        });
      } else {
        await actor2.update({
          [path]: index
        });
      }
    }
  });
}
__name(spellSlotMarker$1, "spellSlotMarker$1");
function hideStandardEncumbranceBar$1(app, html, data) {
  if (!game.settings.get(CONSTANTS.MODULE_ID, "hideStandardEncumbranceBar")) {
    return;
  }
  const elements = html.find(".encumbrance");
  if (elements && elements.length > 0) {
    for (const elem of elements) {
      elem.style.display = "none";
    }
  }
}
__name(hideStandardEncumbranceBar$1, "hideStandardEncumbranceBar$1");
async function _onUsesChange$1(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = Math.clamped(0, parseInt(event.target.value), item.system.uses.max);
  event.target.value = uses;
  return item.update({ "system.uses.value": uses });
}
__name(_onUsesChange$1, "_onUsesChange$1");
async function _onUsesMaxChange$1(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = parseInt(event.target.value ?? item.system.uses.max ?? 0);
  return item.update({ "system.uses.max": uses });
}
__name(_onUsesMaxChange$1, "_onUsesMaxChange$1");
async function _onQuantityChange$1(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = parseInt(event.target.value ?? item.system.quantity);
  event.target.value = uses;
  return item.update({ "system.quantity": uses });
}
__name(_onQuantityChange$1, "_onQuantityChange$1");
function Tidy5eSheetNPCInitialize() {
  Actors.registerSheet("dnd5e", Tidy5eNPC, {
    types: ["npc"],
    makeDefault: true,
    label: "TIDY5E.Tidy5eNPC"
  });
}
__name(Tidy5eSheetNPCInitialize, "Tidy5eSheetNPCInitialize");
Hooks.on("renderTidy5eNPC", (app, html, data) => {
  setSheetClasses$2(app, html);
  toggleSkillList(app, html);
  toggleTraitsList$2(app, html);
  checkDeathSaveStatus$1(app, html, data);
  toggleItemMode(app, html);
  restoreScrollPosition(app, html);
  abbreviateCurrency$2(app, html);
  hideSpellbook(app, html);
  resetTempHp(app, html, data);
  editProtection$2(app, html);
  npcFavorites();
  spellSlotMarker$1(app, html, data);
  hideStandardEncumbranceBar$1(app, html);
  applyLazyMoney(app, html, data);
  if (game.user.isGM) {
    if (!game.settings.get(CONSTANTS.MODULE_ID, "enablePermanentUnlockOnNPCIfYouAreGM")) {
      applyLocksNpcSheet(app, html);
    } else {
      if (!app.actor?.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
        app.actor?.setFlag(CONSTANTS.MODULE_ID, "allow-edit", true);
      }
    }
  } else {
    applyLocksNpcSheet(app, html);
  }
});
const tidy5eSearchFilter = /* @__PURE__ */ __name(function(html, actor2) {
  let searchInput = html.find(".filter-search input");
  searchInput.on("input", function() {
    filterInventoryList(this);
  });
  (function() {
    searchInput.each(function() {
      if ($(this).val() != "") {
        filterInventoryList($(this));
      }
    });
  })();
  searchInput.on("blur", async function() {
    let id = $(this).attr("id"), value = $(this).val();
    switch (id) {
      case "item-search":
        await actor2.setFlag(CONSTANTS.MODULE_ID, "item-search", value);
        break;
      case "spell-search":
        await actor2.setFlag(CONSTANTS.MODULE_ID, "spell-search", value);
        break;
      case "feat-search":
        await actor2.setFlag(CONSTANTS.MODULE_ID, "feat-search", value);
        break;
    }
  });
  async function filterInventoryList(input) {
    let searchField = $(input), clearSearch = searchField.siblings(".clear-search"), id = searchField.attr("id"), searchTarget, value = searchField.val();
    switch (id) {
      case "item-search":
        searchTarget = html.find(
          ".list-layout .inventory-list:not(.spellbook-list):not(.features-list) .item-name, .grid-layout .inventory-list:not(.spellbook-list):not(.features-list) .info-card-name"
        );
        break;
      case "spell-search":
        searchTarget = html.find(
          ".list-layout .spellbook-list .item-name, .grid-layout .spellbook-list .info-card-name"
        );
        break;
      case "feat-search":
        searchTarget = html.find(".list-layout .features-list .item-name");
        break;
    }
    if (value != "") {
      clearSearch.removeClass("hidden");
    } else {
      clearSearch.addClass("hidden");
    }
    value = value.toLowerCase().replace(/\b[a-z]/g, function(letter) {
      return letter.toUpperCase();
    });
    searchTarget.each(function() {
      if ($(this).text().search(value) > -1) {
        $(this).closest(".item").removeClass("filtered").show();
      } else {
        $(this).closest(".item").addClass("filtered").hide();
      }
      if ($(this).closest(".item-list").find(".filtered").length + 1 == $(this).closest(".item-list").children().length) {
        $(this).closest(".item-list").hide();
        $(this).closest(".item-list").prev(".items-header").hide();
      } else {
        $(this).closest(".item-list").show();
        $(this).closest(".item-list").prev(".items-header").show();
      }
    });
    clearSearch.on("click", async function(e) {
      e.preventDefault();
      $(this).toggleClass("hidden");
      searchInput.val("");
      filterInventoryList(searchField);
      switch (id) {
        case "item-search":
          await actor2.setFlag(CONSTANTS.MODULE_ID, "item-search", "");
          break;
        case "spell-search":
          await actor2.setFlag(CONSTANTS.MODULE_ID, "spell-search", "");
          break;
        case "feat-search":
          await actor2.setFlag(CONSTANTS.MODULE_ID, "feat-search", "");
          break;
      }
    });
  }
  __name(filterInventoryList, "filterInventoryList");
}, "tidy5eSearchFilter");
const tidy5eSpellLevelButtons = /* @__PURE__ */ __name(async function(app, html, options) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "enableSpellLevelButtons") && // The module already do the job so for avoid redundance...
  !game.modules.get("spell-level-buttons-for-dnd5e")?.active) {
    if (app?.item?.type != "spell") {
      return;
    }
    if (html.find('[name="consumeSpellSlot"]').length == 0) {
      return;
    }
    const optionsApplication = app;
    if ($('.dnd5e.dialog #ability-use-form select[name="consumeSpellLevel"]').length > 0) {
      let originalWindowHeight = parseInt($(optionsApplication._element[0]).css("height"));
      let heightOffset = 42;
      $(optionsApplication._element[0]).height(originalWindowHeight + heightOffset);
      let levelSelectWrapper = $(optionsApplication._element[0]).find(`.form-group label:contains("${game.i18n.localize(`DND5E.SpellCastUpcast`)}")`).parent();
      let selectedLevel = levelSelectWrapper.find("select").val();
      let appId = optionsApplication.appId;
      levelSelectWrapper.css("display", "none");
      levelSelectWrapper.after(`
            <div class="form-group spell-lvl-btn">
                <label>${game.i18n.localize(`DND5E.SpellCastUpcast`)}</label>
                <div class="form-fields"></div>
            </div>
        `);
      $(optionsApplication._element[0]).find(`select[name="consumeSpellLevel"] option`).each(function() {
        let availableTextSlotsFounded = $(this).text().match(/\(\d+\s\w+\)/);
        if (!availableTextSlotsFounded) {
          availableTextSlotsFounded = $(this).text().match(/\d+/g);
          const lastMatch = availableTextSlotsFounded[availableTextSlotsFounded.length - 1];
          if (lastMatch) {
            availableTextSlotsFounded = lastMatch;
          }
        }
        if (!availableTextSlotsFounded) {
          warn(
            `tidy5e-spell-level-buttons | tidy5eSpellLevelButtons | Cannot find the spell slots on text '${$(
              this
            ).text()}' with ${/\(\d+\s\w+\)/}`
          );
        }
        let availableSlotsFounded = availableTextSlotsFounded ? availableTextSlotsFounded[0].match(/\d+/) : void 0;
        if (!availableSlotsFounded) {
          warn(
            `tidy5e-spell-level-buttons | tidy5eSpellLevelButtons | Cannot find the spell slots on text '${$(
              this
            ).text()}' with ${/\d+/}`
          );
        }
        let availableSlots = availableSlotsFounded ? availableSlotsFounded[0] : 0;
        let availableSlotsBadge = "";
        let value = $(this).val();
        let i;
        if (value == "pact") {
          let availablePactSlotsFounded = $(this).text().match(/\d/);
          if (!availablePactSlotsFounded) {
            warn(
              `tidy5e-spell-level-buttons | tidy5eSpellLevelButtons | Cannot find the pact slots on text '${$(
                this
              ).text()}' with ${/\d/}`
            );
          }
          if (availablePactSlotsFounded) {
            i = "p" + availablePactSlotsFounded[0];
          } else {
            i = "p0";
          }
        } else {
          i = value;
        }
        if (availableSlots > 0) {
          availableSlotsBadge = `<span class="available-slots">${availableSlots}</span>`;
        }
        $(optionsApplication._element[0]).find(".spell-lvl-btn .form-fields").append(`
                <label title="${$(this).text()}" class="spell-lvl-btn__label" for="${appId}lvl-btn-${i}">
                    <input type="radio" id="${appId}lvl-btn-${i}" name="lvl-btn" value="${value}">
                    <div class="spell-lvl-btn__btn">${i}</div>
                    ${availableSlotsBadge}
                </label>
            `);
      });
      $(optionsApplication._element[0]).find(`#${appId}lvl-btn-${selectedLevel}`).trigger("click");
      $(optionsApplication._element[0]).find(".spell-lvl-btn__label").on("click", function() {
        levelSelectWrapper.find("select").val($(this).find("input").val());
      });
    }
  }
}, "tidy5eSpellLevelButtons");
let position = 0;
class Tidy5eSheet extends dnd5e.applications.actor.ActorSheet5eCharacter {
  static {
    __name(this, "Tidy5eSheet");
  }
  get template() {
    if (!game.user.isGM && this.actor.limited && !game.settings.get(CONSTANTS.MODULE_ID, "expandedSheetEnabled"))
      return "modules/tidy5e-sheet/templates/actors/tidy5e-sheet-ltd.html";
    return "modules/tidy5e-sheet/templates/actors/tidy5e-sheet.html";
  }
  static get defaultOptions() {
    let defaultTab = game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") != "default" ? game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") : "attributes";
    if (!game.modules.get("character-actions-list-5e")?.active && game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") == "actions") {
      defaultTab = "attributes";
    }
    return mergeObject(super.defaultOptions, {
      classes: ["tidy5e", "sheet", "actor", "character"],
      blockFavTab: true,
      width: game.settings.get(CONSTANTS.MODULE_ID, "playerSheetWidth") ?? 740,
      height: 840,
      tabs: [
        {
          navSelector: ".tabs",
          contentSelector: ".sheet-body",
          initial: defaultTab
        }
      ]
    });
  }
  /**
   * Add some extra data when rendering the sheet to reduce the amount of logic required within the template.
   */
  async getData(options) {
    const context = await super.getData(options);
    Object.keys(context.abilities).forEach((id) => {
      context.abilities[id].abbr = CONFIG.DND5E.abilities[id].abbreviation;
    });
    context.journalNotes1HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes1?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes2HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes2?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes3HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes3?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalNotes4HTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes4?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.journalHTML = await TextEditor.enrichHTML(context.actor.flags[CONSTANTS.MODULE_ID]?.notes?.value, {
      secrets: this.actor.isOwner,
      rollData: context.rollData,
      async: true,
      relativeTo: this.actor
    });
    context.appId = this.appId;
    context.allowCantripToBePreparedOnContext = game.settings.get(
      CONSTANTS.MODULE_ID,
      "allowCantripToBePreparedOnContext"
    );
    context.isGM = game.user.isGM;
    context.allowHpMaxOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpMaxOverride");
    context.allowHpConfigOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpConfigOverride");
    context.rightClickDisabled = game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled");
    context.classicControlsEnabled = game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.classicControlsDisabled = !game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.notHideIconsNextToTheItemName = !game.settings.get(CONSTANTS.MODULE_ID, "hideIconsNextToTheItemName");
    context.hpOverlayCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpOverlayCalculationCurrent = context.hpOverlayCalculationCurrent + "%";
    context.hpBarCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpBarCalculationCurrent = context.hpBarCalculationCurrent + "%";
    const exhaustionTooltipPrefix = `${game.i18n.localize("DND5E.Exhaustion")} ${game.i18n.localize(
      "DND5E.AbbreviationLevel"
    )} ${this.actor.system.attributes.exhaustion}`;
    if (this.actor.system.attributes.exhaustion === 0) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion0")}`;
    } else if (this.actor.system.attributes.exhaustion === 1) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion1")}`;
    } else if (this.actor.system.attributes.exhaustion === 2) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion2")}`;
    } else if (this.actor.system.attributes.exhaustion === 3) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion3")}`;
    } else if (this.actor.system.attributes.exhaustion === 4) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion4")}`;
    } else if (this.actor.system.attributes.exhaustion === 5) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion5")}`;
    } else if (this.actor.system.attributes.exhaustion === 6) {
      context.exhaustionTooltip = exhaustionTooltipPrefix + `, ${game.i18n.localize("TIDY5E.Exhaustion6")}`;
    } else {
      context.exhaustionTooltip = exhaustionTooltipPrefix;
    }
    return context;
  }
  _createEditor(target, editorOptions, initialContent) {
    editorOptions.min_height = 200;
    super._createEditor(target, editorOptions, initialContent);
  }
  // save all simultaneously open editor field when one field is saved
  async _onEditorSave(target, element, content) {
    return this.submit();
  }
  activateListeners(html) {
    super.activateListeners(html);
    let actor2 = this.actor;
    tidy5eListeners(html, actor2, this);
    tidy5eContextMenu(html, this);
    tidy5eSearchFilter(html, actor2);
    tidy5eShowActorArt(html, actor2);
    tidy5eItemCard(html, actor2);
    tidy5eAmmoSwitch(html, actor2);
    const attributesTab = html.find(".tab.attributes");
    attributesTab.scroll(function() {
      position = this.scrollPos = { top: attributesTab.scrollTop() };
    });
    let tabNav = html.find('a.item:not([data-tab="attributes"])');
    tabNav.click(function() {
      this.scrollPos = { top: 0 };
      attributesTab.scrollTop(0);
    });
    html.find(".toggle-layout.inventory-layout").click(async (event) => {
      event.preventDefault();
      if ($(event.currentTarget).hasClass("spellbook-layout")) {
        if (actor2.getFlag(CONSTANTS.MODULE_ID, "spellbook-grid")) {
          await actor2.unsetFlag(CONSTANTS.MODULE_ID, "spellbook-grid");
        } else {
          await actor2.setFlag(CONSTANTS.MODULE_ID, "spellbook-grid", true);
        }
      } else {
        if (actor2.getFlag(CONSTANTS.MODULE_ID, "inventory-grid")) {
          await actor2.unsetFlag(CONSTANTS.MODULE_ID, "inventory-grid");
        } else {
          await actor2.setFlag(CONSTANTS.MODULE_ID, "inventory-grid", true);
        }
      }
    });
    html.find(".traits-toggle").click(async (event) => {
      event.preventDefault();
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "traits-compressed")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "traits-compressed");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "traits-compressed", true);
      }
    });
    html.find(".exhaust-level li").click(async (event) => {
      event.preventDefault();
      let target = event.currentTarget;
      let value = Number(target.dataset.elvl);
      await actor2.update({ "system.attributes.exhaustion": value });
      setProperty(actor2, "system.attributes.exhaustion", value);
      if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionEffectsEnabled") != "default") {
        if (actor2.constructor.name != "Actor5e")
          ;
        else {
          updateExhaustion(actor2);
        }
      }
    });
    html.find(".item:not(.items-header) input").change((event) => {
      event.target.value;
      let itemId = $(event.target).parents(".item")[0].dataset.itemId;
      let path = event.target.dataset.path;
      let data = {};
      data[path] = Number(event.target.value);
      actor2.items.get(itemId).update(data);
    });
    html.find(".inventory-list .item .addCharges").click((event) => {
      let itemId = $(event.target).parents(".item")[0].dataset.itemId;
      let item = actor2.items.get(itemId);
      item.system.uses = { value: 1, max: 1 };
      let data = {};
      data["system.uses.value"] = 1;
      data["system.uses.max"] = 1;
      actor2.items.get(itemId).update(data);
    });
    html.find(".traits .toggle-traits").click(async (event) => {
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "traitsExpanded")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "traitsExpanded");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "traitsExpanded", true);
      }
    });
    html.find(".item-control.item-attunement").click(async (event) => {
      event.preventDefault();
      let li = $(event.currentTarget).closest(".item"), item = actor2.items.get(li.data("item-id")), count = actor2.system.attributes.attunement.value;
      if (item.system.attunement == 2) {
        actor2.items.get(li.data("item-id")).update({ "system.attunement": 1 });
      } else {
        if (count >= actor2.system.attributes.attunement.max) {
          ui.notifications.warn(`${game.i18n.format("TIDY5E.AttunementWarning", { number: count })}`);
        } else {
          actor2.items.get(li.data("item-id")).update({ "system.attunement": 2 });
        }
      }
    });
    html.find(".item-detail input.uses-max").off("change");
    html.find(".item-detail input.uses-max").click((ev) => ev.target.select()).change(_onUsesMaxChange.bind(this));
    html.find(".item-detail input.uses-value").off("change");
    html.find(".item-detail input.uses-value").click((ev) => ev.target.select()).change(_onUsesChange.bind(this));
    html.find(".item-quantity input.item-count").off("change");
    html.find(".item-quantity input.item-count").click((ev) => ev.target.select()).change(_onQuantityChange.bind(this));
  }
  /* -------------------------------------------- */
  /**
   * Handle duplicate an existing Item entry from the Advancement.
   * @param {Event} event        The originating click event.
   * @returns {Promise<Item5e>}  The updated parent Item after the application re-renders.
   * @protected
   */
  async _onItemDuplicate(event) {
    event.preventDefault();
    const uuidToDuplicate = event.currentTarget.closest("[data-item-id]")?.dataset.itemId;
    if (!uuidToDuplicate)
      return;
    const item = this.actor.items.get(uuidToDuplicate);
    item.clone({ name: game.i18n.format("DOCUMENT.CopyOf", { name: item.name }) }, { save: true });
  }
  /* -------------------------------------------- */
  // add actions module
  async _renderInner(...args) {
    const html = await super._renderInner(...args);
    let injectCharacterSheet;
    if (game.modules.get("character-actions-list-5e")?.active) {
      injectCharacterSheet = game.settings.get("character-actions-list-5e", "inject-characters");
      const actionsListApi = game.modules.get("character-actions-list-5e")?.api;
      try {
        if (injectCharacterSheet) {
          const actionsTabButton = $(
            '<a class="item" data-tab="actions">' + game.i18n.localize(`DND5E.ActionPl`) + "</a>"
          );
          const tabs = html.find('.tabs[data-group="primary"]');
          tabs.prepend(actionsTabButton);
          const sheetBody = html.find(".sheet-body");
          const actionsTab = $(`<div class="tab actions" data-group="primary" data-tab="actions"></div>`);
          const actionsLayout = $(`<div class="list-layout"></div>`);
          actionsTab.append(actionsLayout);
          sheetBody.prepend(actionsTab);
          const actionsTabHtml = $(await actionsListApi.renderActionsList(this.actor));
          actionsLayout.html(actionsTabHtml);
        }
        if (game.modules.get("character-actions-list-5e")?.active && game.settings.get(CONSTANTS.MODULE_ID, "enableActionListOnFavoritePanel")) {
          const actionsTab = html.find(".actions-target");
          const actionsTabHtml = $(await actionsListApi.renderActionsList(this.actor));
          actionsTab.html(actionsTabHtml);
          actionsTab.find(".item-controls.context-menu").hide();
          actionsTab.find("item-controls items-header-controls").hide();
          actionsTab.find(".item-name").css("min-width", "130px");
          actionsTab.find(".item-name").css("max-width", "130px");
        }
      } catch (err) {
        error(err?.message, true);
      }
    }
    return html;
  }
}
async function countInventoryItems(app, html, data) {
  if (game.user.isGM) {
    html.find(".attuned-items-counter").addClass("isGM");
  }
  html.find(".tab.inventory .item-list").each(function() {
    let itemlist = this;
    let items = $(itemlist).find("li");
    let itemCount = items.length - 1;
    $(itemlist).prev(".items-header").find(".item-name").append(" (" + itemCount + ")");
  });
}
__name(countInventoryItems, "countInventoryItems");
async function countAttunedItems(app, html, data) {
  const actor2 = app.actor;
  const count = actor2.system.attributes.attunement.value;
  if (actor2.system.attributes.attunement.value > actor2.system.attributes.attunement.max) {
    html.find(".attuned-items-counter").addClass("overattuned");
    ui.notifications.warn(`${game.i18n.format("TIDY5E.AttunementWarning", { number: count })}`);
  }
}
__name(countAttunedItems, "countAttunedItems");
async function toggleTraitsList$1(app, html, data) {
  html.find(".traits:not(.always-visible):not(.expanded) .form-group.inactive").remove();
}
__name(toggleTraitsList$1, "toggleTraitsList$1");
async function checkDeathSaveStatus(app, html, data) {
  if (data.editable) {
    let actor2 = app.actor;
    var currentHealth = actor2.system.attributes.hp.value;
    var deathSaveSuccess = actor2.system.attributes.death.success;
    var deathSaveFailure = actor2.system.attributes.death.failure;
    debug(
      `tidy5e-sheet | checkDeathSaveStatus | current HP Character : ${currentHealth}, success: ${deathSaveSuccess}, failure: ${deathSaveFailure}`
    );
    if (currentHealth <= 0) {
      html.find(".tidy5e-sheet .profile").addClass("dead");
    }
    if (currentHealth > 0 && deathSaveSuccess != 0 || currentHealth > 0 && deathSaveFailure != 0) {
      await actor2.update({ "system.attributes.death.success": 0 });
      await actor2.update({ "system.attributes.death.failure": 0 });
    }
  }
}
__name(checkDeathSaveStatus, "checkDeathSaveStatus");
async function editProtection$1(app, html, data) {
  let actor2 = app.actor;
  if (game.user.isGM && game.settings.get(CONSTANTS.MODULE_ID, "editGmAlwaysEnabled")) {
    html.find(".classic-controls").addClass("gmEdit");
  } else if (!actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    let resourcesUsed = 0;
    html.find('.resources input[type="text"]').each(function() {
      if ($(this).val() != "") {
        resourcesUsed++;
      }
    });
    if (resourcesUsed == 0) {
      html.find(".resources").hide();
    }
    let itemContainer = html.find(".inventory-list.items-list, .effects-list.items-list");
    html.find(".inventory-list .items-header:not(.spellbook-header), .effects-list .items-header").each(function() {
      if ($(this).next(".item-list").find("li").length - $(this).next(".item-list").find("li.items-footer").length == 0) {
        $(this).next(".item-list").addClass("hidden").hide();
        $(this).addClass("hidden").hide();
      }
    });
    html.find(".inventory-list .items-footer").addClass("hidden").hide();
    html.find(".inventory-list .item-control.item-delete").remove();
    html.find(".inventory-list .item-control.item-duplicate").remove();
    html.find(".effects .effect-control.effect-delete").remove();
    html.find(".effects .effect-control.effect-duplicate").remove();
    if (game.settings.get(CONSTANTS.MODULE_ID, "editEffectsGmOnlyEnabled") && !game.user.isGM) {
      html.find(".effects-list .items-footer, .effects-list .effect-controls").remove();
    } else {
      html.find(".effects-list .items-footer, .effects-list .effect-control.effect-delete").remove();
    }
    itemContainer.each(function() {
      let hiddenSections = $(this).find("> .hidden").length;
      let totalSections = $(this).children().not(".notice").length;
      debug(`tidy5e-sheet | editProtection | hidden: ${hiddenSections}'/ total: ${totalSections}`);
      if (hiddenSections >= totalSections) {
        if ($(this).hasClass("effects-list") && !game.user.isGM && game.settings.get(CONSTANTS.MODULE_ID, "editEffectsGmOnlyEnabled")) {
          $(this).prepend(`<span class="notice">${game.i18n.localize("TIDY5E.GmOnlyEdit")}</span>`);
        } else {
          $(this).append(`<span class="notice">${game.i18n.localize("TIDY5E.EmptySection")}</span>`);
        }
      }
    });
  } else if (!game.user.isGM && actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit") && game.settings.get(CONSTANTS.MODULE_ID, "editEffectsGmOnlyEnabled")) {
    let itemContainer = html.find(".effects-list.items-list");
    itemContainer.prepend(`<span class="notice">${game.i18n.localize("TIDY5E.GmOnlyEdit")}</span>`);
    html.find(".effects-list .items-footer, .effects-list .effect-controls").remove();
    html.find(".effects-list .items-header").each(function() {
      if ($(this).next(".item-list").find("li").length < 1) {
        $(this).next(".item-list").addClass("hidden").hide();
        $(this).addClass("hidden").hide();
      }
    });
  }
}
__name(editProtection$1, "editProtection$1");
async function addClassList(app, html, data) {
  if (data.editable) {
    if (!game.settings.get(CONSTANTS.MODULE_ID, "classListDisabled")) {
      let actor2 = app.actor;
      let classList = [];
      let items = data.actor.items;
      for (let item of items) {
        if (item.type === "class") {
          let levelsHtml = item.system.levels ? `<span class='levels-info'>${item.system.levels}</span>` : ``;
          classList.push(
            `<li class='class-item' data-tooltip='${item.name} (${item.system.levels})'>${item.name + levelsHtml}</li>`
          );
        }
        if (item.type === "subclass") {
          classList.push(`<li class='class-item' data-tooltip='${item.name}'>${item.name}</li>`);
        }
      }
      let classListHtml = `<ul class='class-list'>${classList.join("")}</ul>`;
      mergeObject(actor2, { "flags.tidy5e-sheet.classlist": classListHtml });
      let classListTarget = html.find(".bonus-information");
      classListTarget.append(classListHtml);
    }
    html.find(".origin-summary span.origin-summary-text").each(function() {
      let originalText = $(this).text();
      $(this).attr("data-tooltip", originalText);
    });
  }
}
__name(addClassList, "addClassList");
async function spellAttackMod(app, html, data) {
  let actor2 = app.actor;
  let prof = actor2.system.attributes.prof;
  let spellAbility = html.find(".spellcasting-attribute select option:selected").val();
  let abilityMod = spellAbility != "" ? actor2.system.abilities[spellAbility].mod : 0;
  let spellBonus = 0;
  const rollData = actor2.getRollData();
  let formula = Roll.replaceFormulaData(actor2.system.bonuses.rsak.attack, rollData, { missing: 0, warn: false });
  if (formula === "") {
    formula = "0";
  }
  try {
    spellBonus = Roll.safeEval(formula);
  } catch (err) {
    try {
      spellBonus = await new Roll(formula).evaluate({ async: true }).total;
    } catch (err2) {
      error("spell bonus calculation failed : " + err2?.message, true);
    }
  }
  let spellAttackMod2 = prof + abilityMod;
  let spellAttackModWihBonus = prof + abilityMod + spellBonus;
  let spellAttackTextWithBonus = spellAttackModWihBonus > 0 ? "+" + spellAttackModWihBonus : spellAttackModWihBonus;
  let spellAttackTextTooltip = `${prof} (prof.)+${abilityMod} (${spellAbility})`;
  let spellAttackTextTooltipWithBonus = `with bonus ${spellAttackTextWithBonus} = ${prof} (prof.)+${abilityMod} (${spellAbility})+${formula} (bonus 'actor.system.bonuses.rsak.attack')`;
  spellAttackTextTooltipWithBonus = spellAttackTextTooltipWithBonus.replace("++", "+");
  debug(
    `tidy5e-sheet | spellAttackMod | Prof: ${prof ?? ""} / Spell Ability: ${spellAbility ?? ""} / ability Mod: ${abilityMod ?? ""} / Spell Attack Mod: ${spellAttackMod2 ?? ""} / Spell Bonus : ${spellBonus ?? ""}`
  );
  html.find(".spell-mod .spell-attack-mod").html(spellAttackTextWithBonus);
  html.find(".spell-mod .spell-attack-mod").attr("data-tooltip", `${spellAttackTextTooltip} [${spellAttackTextTooltipWithBonus}] `);
}
__name(spellAttackMod, "spellAttackMod");
async function abbreviateCurrency$1(app, html, data) {
  html.find(".currency .currency-item label").each(function() {
    let currency = $(this).data("denom").toUpperCase();
    debug(
      `tidy5e-sheet | abbreviateCurrency | Currency Abbr: ${CONFIG.DND5E.currencies[currency]?.abbreviation ?? ""}`
    );
    let abbr = game.i18n.localize(`DND5E.CurrencyAbbr${currency}`);
    if (abbr == `DND5E.CurrencyAbbr${currency}`) {
      abbr = currency;
    }
    $(this).html(abbr);
  });
}
__name(abbreviateCurrency$1, "abbreviateCurrency$1");
async function tidyCustomEffect(actor2, changes) {
  const changeMaxPreparedList = changes.find((c) => {
    return c.key === "flags.tidy5e-sheet.maxPreparedSpells";
  });
  if (changeMaxPreparedList) {
    if (changeMaxPreparedList.value?.length > 0) {
      let oldValue = getProperty(actor2, changeMaxPreparedList.key) || 0;
      let changeMaxPreparedListText = changeMaxPreparedList.value.trim();
      let op = changeMaxPreparedList.mode;
      const rollData = actor2.getRollData();
      Object.keys(rollData.abilities).forEach((abl) => {
        rollData.abilities[abl].mod = Math.floor((rollData.abilities[abl].value - 10) / 2);
      });
      const roll_value = await new Roll(changeMaxPreparedListText, rollData).roll();
      const value = roll_value.total;
      oldValue = Number.isNumeric(oldValue) ? parseInt(oldValue) : 0;
      if (oldValue != value) {
        switch (op) {
          case CONST.ACTIVE_EFFECT_MODES.ADD: {
            setProperty(actor2, changeMaxPreparedList.key, oldValue + value);
            break;
          }
          case CONST.ACTIVE_EFFECT_MODES.DOWNGRADE: {
            setProperty(actor2, changeMaxPreparedList.key, oldValue - value);
            break;
          }
          case CONST.ACTIVE_EFFECT_MODES.MULTIPLY: {
            setProperty(actor2, changeMaxPreparedList.key, oldValue * value);
            break;
          }
          case CONST.ACTIVE_EFFECT_MODES.UPGRADE: {
            setProperty(actor2, changeMaxPreparedList.key, value);
            break;
          }
          case CONST.ACTIVE_EFFECT_MODES.OVERRIDE: {
            throw error(`Do not use the mode 'OVERRIDE' when you try to set the Max Prepared Spells`, true);
          }
          case CONST.ACTIVE_EFFECT_MODES.CUSTOM: {
            setProperty(actor2, changeMaxPreparedList.key, value);
            break;
          }
          default: {
            setProperty(actor2, changeMaxPreparedList.key, value);
            break;
          }
        }
        await actor2.update({
          "flags.tidy5e-sheet.maxPreparedSpells": getProperty(actor2, changeMaxPreparedList.key)
        });
        return getProperty(actor2, changeMaxPreparedList.key);
      } else {
        return void 0;
      }
    }
  }
}
__name(tidyCustomEffect, "tidyCustomEffect");
function markActiveEffects(app, html, data) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "activeEffectsMarker")) {
    app.actor;
    let items = data.actor.items;
    let marker = `<span class="ae-marker" title="Item has active effects">Æ</span>`;
    for (let item of items) {
      debug(`tidy5e-sheet | markActiveEffects | item: ${item}`);
      if (item.effects.length > 0) {
        let id = item._id;
        debug(`tidy5e-sheet | markActiveEffects | itemId: ${id}`);
        html.find(`.item[data-item-id="${id}"] .item-name h4`).append(marker);
      }
    }
  }
}
__name(markActiveEffects, "markActiveEffects");
function spellSlotMarker(app, html, data) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "hideSpellSlotMarker")) {
    return;
  }
  let actor2 = app.actor;
  data.actor.items;
  let options = ["pact", "spell1", "spell2", "spell3", "spell4", "spell5", "spell6", "spell7", "spell8", "spell9"];
  for (let o of options) {
    let max = html.find(`.spell-max[data-level=${o}]`);
    let name = max.closest(".spell-slots");
    let spellData = actor2.system.spells[o];
    if (spellData.max === 0) {
      continue;
    }
    let contents = ``;
    for (let i = 1; i <= spellData.max; i++) {
      if (i <= spellData.value) {
        contents += `<span class="dot"></span>`;
      } else {
        contents += `<span class="dot empty"></span>`;
      }
    }
    name.before(`<div class="spellSlotMarker">${contents}</div>`);
  }
  html.find(".spellSlotMarker .dot").mouseenter((ev) => {
    const parentEl = ev.currentTarget.parentElement;
    const index = [...parentEl.children].indexOf(ev.currentTarget);
    const dots = parentEl.querySelectorAll(".dot");
    if (ev.currentTarget.classList.contains("empty")) {
      for (let i = 0; i < dots.length; i++) {
        if (i <= index) {
          dots[i].classList.contains("empty") ? dots[i].classList.add("change") : "";
        }
      }
    } else {
      for (let i = 0; i < dots.length; i++) {
        if (i >= index) {
          dots[i].classList.contains("empty") ? "" : dots[i].classList.add("change");
        }
      }
    }
  });
  html.find(".spellSlotMarker .dot").mouseleave((ev) => {
    const parentEl = ev.currentTarget.parentElement;
    $(parentEl).find(".dot").removeClass("change");
  });
  html.find(".spellSlotMarker .dot").click(async (ev) => {
    const index = [...ev.currentTarget.parentElement.children].indexOf(ev.currentTarget);
    const slots = $(ev.currentTarget).parents(".spell-level-slots");
    const spellLevel = slots.find(".spell-max").data("level");
    debug(`tidy5e-sheet | spellSlotMarker | spellLevel: ${spellLevel}, index: ${index}`);
    if (spellLevel) {
      let path = `data.spells.${spellLevel}.value`;
      if (ev.currentTarget.classList.contains("empty")) {
        await actor2.update({
          [path]: index + 1
        });
      } else {
        await actor2.update({
          [path]: index
        });
      }
    }
  });
}
__name(spellSlotMarker, "spellSlotMarker");
function hideStandardEncumbranceBar(app, html, data) {
  if (!game.settings.get(CONSTANTS.MODULE_ID, "hideStandardEncumbranceBar")) {
    return;
  }
  const elements = html.find(".encumbrance");
  if (elements && elements.length > 0) {
    for (const elem of elements) {
      elem.style.display = "none";
    }
  }
}
__name(hideStandardEncumbranceBar, "hideStandardEncumbranceBar");
async function setSheetClasses$1(app, html, data) {
  app.actor;
  if (!game.settings.get(CONSTANTS.MODULE_ID, "playerNameEnabled")) {
    html.find(".tidy5e-sheet #playerName").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "journalTabDisabled")) {
    html.find('.tidy5e-sheet .tidy5e-navigation a[data-tab="journal"]').remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
    if (game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
      html.find(".tidy5e-sheet .grid-layout .items-list").addClass("alt-context");
    } else {
      html.find(".tidy5e-sheet .items-list").addClass("alt-context");
    }
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
    html.find(".tidy5e-sheet .items-header-controls").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "pc" || game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "all") {
    html.find(".tidy5e-sheet .profile").addClass("roundPortrait");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayDisabled")) {
    html.find(".tidy5e-sheet .profile").addClass("disable-hp-overlay");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpBarDisabled")) {
    html.find(".tidy5e-sheet .profile").addClass("disable-hp-bar");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "inspirationDisabled")) {
    html.find(".tidy5e-sheet .profile .inspiration").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "inspirationAnimationDisabled")) {
    html.find(".tidy5e-sheet .profile .inspiration label i").addClass("disable-animation");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorder") > 0) {
    $(".system-dnd5e").get(0).style.setProperty("--pc-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorder") + "px");
  } else {
    $(".system-dnd5e").get(0).style.removeProperty("--pc-border");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hideIfZero")) {
    html.find(".tidy5e-sheet .profile").addClass("autohide");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionDisabled")) {
    html.find(".tidy5e-sheet .profile .exhaustion-container").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "exhaustionOnHover")) {
    html.find(".tidy5e-sheet .profile").addClass("exhaustionOnHover");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "inspirationOnHover")) {
    html.find(".tidy5e-sheet .profile").addClass("inspirationOnHover");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "traitsMovedBelowResource")) {
    let altPos = html.find(".alt-trait-pos");
    let traits = html.find(".traits");
    altPos.append(traits);
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "traitsTogglePc")) {
    html.find(".tidy5e-sheet .traits").addClass("always-visible");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "traitLabelsEnabled")) {
    html.find(".tidy5e-sheet .traits").addClass("show-labels");
  }
  if (game.user.isGM) {
    html.find(".tidy5e-sheet").addClass("isGM");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hiddenDeathSavesEnabled") && !game.user.isGM) {
    html.find(".tidy5e-sheet .death-saves").addClass("gmOnly");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "quantityAlwaysShownEnabled")) {
    html.find(".item").addClass("quantityAlwaysShownEnabled");
  }
  $(".info-card-hint .key").html(game.settings.get(CONSTANTS.MODULE_ID, "itemCardsFixKey"));
  applyColorPickerCustomization(html);
}
__name(setSheetClasses$1, "setSheetClasses$1");
async function _onUsesChange(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = Math.clamped(0, parseInt(event.target.value), item.system.uses.max);
  event.target.value = uses;
  return item.update({ "system.uses.value": uses });
}
__name(_onUsesChange, "_onUsesChange");
async function _onUsesMaxChange(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = parseInt(event.target.value ?? item.system.uses.max ?? 0);
  return item.update({ "system.uses.max": uses });
}
__name(_onUsesMaxChange, "_onUsesMaxChange");
async function _onQuantityChange(event) {
  event.preventDefault();
  const itemId = event.currentTarget.closest(".item").dataset.itemId;
  const item = this.actor.items.get(itemId);
  const uses = parseInt(event.target.value ?? item.system.quantity);
  event.target.value = uses;
  return item.update({ "system.quantity": uses });
}
__name(_onQuantityChange, "_onQuantityChange");
function Tidy5eSheetInitialize() {
  Actors.registerSheet("dnd5e", Tidy5eSheet, {
    types: ["character"],
    makeDefault: true
  });
}
__name(Tidy5eSheetInitialize, "Tidy5eSheetInitialize");
function Tidy5eSheetApplyActiveEffect(actor2, effect, options) {
  if (!actor2 || !effect) {
    return;
  }
  debug(`tidy5e-sheet | Tidy5eSheetApplyActiveEffect | start`);
  if (actor2 instanceof Actor && effect.effect?.changes) {
    const changes = effect.effect.changes;
    tidyCustomEffect(actor2, changes);
  } else if (actor2.parent && actor2.parent instanceof Actor && effect.changes) {
    warn(`are you using the old hook ?`);
    const changes = effect.changes;
    tidyCustomEffect(actor2.parent, changes);
  }
  debug(`tidy5e-sheet | Tidy5eSheetApplyActiveEffect | end`);
}
__name(Tidy5eSheetApplyActiveEffect, "Tidy5eSheetApplyActiveEffect");
function Tidy5eSheetCreateActiveEffect(activeEffect, _config, options) {
  if (!(activeEffect?.parent instanceof Actor) || !_config.changes) {
    return;
  }
  debug(`tidy5e-sheet | Tidy5eSheetCreateActiveEffect | start`);
  const changes = _config.changes;
  tidyCustomEffect(activeEffect?.parent, changes);
  debug(`tidy5e-sheet | Tidy5eSheetCreateActiveEffect | end`);
}
__name(Tidy5eSheetCreateActiveEffect, "Tidy5eSheetCreateActiveEffect");
function Tidy5eSheetUpdateActiveEffect(activeEffect, _config, options) {
  if (!(activeEffect?.parent instanceof Actor) || !_config.changes) {
    return;
  }
  debug(`tidy5e-sheet | Tidy5eSheetUpdateActiveEffect | start`);
  const changes = _config.changes;
  tidyCustomEffect(activeEffect?.parent, changes);
  debug(`tidy5e-sheet | Tidy5eSheetUpdateActiveEffect | end`);
}
__name(Tidy5eSheetUpdateActiveEffect, "Tidy5eSheetUpdateActiveEffect");
function Tidy5eSheetDeleteActiveEffect(activeEffect, _config, options) {
  if (!(activeEffect?.parent instanceof Actor) || !_config.changes) {
    return;
  }
  debug(`tidy5e-sheet | Tidy5eSheetDeleteActiveEffect | start`);
  const changes = _config.changes;
  tidyCustomEffect(activeEffect?.parent, changes);
  debug(`tidy5e-sheet | Tidy5eSheetDeleteActiveEffect | end`);
}
__name(Tidy5eSheetDeleteActiveEffect, "Tidy5eSheetDeleteActiveEffect");
Hooks.on("renderTidy5eSheet", (app, html, data) => {
  setSheetClasses$1(app, html);
  editProtection$1(app, html);
  addClassList(app, html, data);
  toggleTraitsList$1(app, html);
  checkDeathSaveStatus(app, html, data);
  abbreviateCurrency$1(app, html);
  spellAttackMod(app, html);
  addFavorites(app, html, data, position);
  countAttunedItems(app, html);
  countInventoryItems(app, html);
  markActiveEffects(app, html, data);
  spellSlotMarker(app, html, data);
  hideStandardEncumbranceBar(app, html);
  applyLazyMoney(app, html, data);
  applySpellClassFilterActorSheet(app, html);
  applyLocksCharacterSheet(app, html);
});
function Tidy5eSheetRenderAbilityUseDialog(app, html, options) {
  debug(`tidy5e-sheet | Tidy5eSheetRenderAbilityUseDialog | start`);
  tidy5eSpellLevelButtons(app, html);
  tidy5eHBEnableUpcastFreeSpell(app, html);
  debug(`tidy5e-sheet | Tidy5eSheetRenderAbilityUseDialog | end`);
}
__name(Tidy5eSheetRenderAbilityUseDialog, "Tidy5eSheetRenderAbilityUseDialog");
class Tidy5eVehicle extends dnd5e.applications.actor.ActorSheet5eVehicle {
  static {
    __name(this, "Tidy5eVehicle");
  }
  static get defaultOptions() {
    let defaultTab = game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") != "default" ? game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") : "attributes";
    if (!game.modules.get("character-actions-list-5e")?.active && game.settings.get(CONSTANTS.MODULE_ID, "defaultActionsTab") == "actions") {
      defaultTab = "attributes";
    }
    return mergeObject(super.defaultOptions, {
      classes: ["tidy5e", "sheet", "actor", "vehicle"],
      width: game.settings.get(CONSTANTS.MODULE_ID, "vehicleSheetWidth") ?? 740,
      height: 720,
      tabs: [{ navSelector: ".tabs", contentSelector: ".sheet-body", initial: defaultTab }]
    });
  }
  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */
  /**
   * Get the correct HTML template path to use for rendering this particular sheet
   * @type {String}
   */
  get template() {
    if (!game.user.isGM && this.actor.limited) {
      return "modules/tidy5e-sheet/templates/actors/tidy5e-vehicle-ltd.html";
    }
    return "modules/tidy5e-sheet/templates/actors/tidy5e-vehicle.html";
  }
  /**
   * Add some extra data when rendering the sheet to reduce the amount of logic required within the template.
   */
  async getData(options) {
    const context = await super.getData(options);
    Object.keys(context.abilities).forEach((id) => {
      context.abilities[id].abbr = CONFIG.DND5E.abilities[id].abbreviation;
    });
    context.isGM = game.user.isGM;
    context.allowHpMaxOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpMaxOverride");
    context.allowHpConfigOverride = game.settings.get(CONSTANTS.MODULE_ID, "allowHpConfigOverride");
    context.rightClickDisabled = game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled");
    context.classicControlsEnabled = game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.classicControlsDisabled = !game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled");
    context.notHideIconsNextToTheItemName = !game.settings.get(CONSTANTS.MODULE_ID, "hideIconsNextToTheItemName");
    context.hpOverlayCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpOverlayCalculationCurrent = context.hpOverlayCalculationCurrent + "%";
    context.hpBarCalculationCurrent = 100 / ((is_real_number(this.actor.system?.attributes?.hp?.max) ? this.actor.system.attributes.hp.max : 1) + (is_real_number(this.actor.system?.attributes?.hp?.tempmax) ? this.actor.system.attributes.hp.tempmax : 0)) * (is_real_number(this.actor.system?.attributes?.hp?.value) ? this.actor.system.attributes.hp.value : 0) + (is_real_number(this.actor.system?.attributes?.hp?.temp) ? this.actor.system.attributes.hp.temp : 0);
    context.hpBarCalculationCurrent = context.hpBarCalculationCurrent + "%";
    return context;
  }
  activateListeners(html) {
    super.activateListeners(html);
    let actor2 = this.actor;
    tidy5eListeners(html, actor2, this);
    tidy5eContextMenu(html, this);
    tidy5eShowActorArt(html, actor2);
    if (game.settings.get(CONSTANTS.MODULE_ID, "itemCardsForNpcs")) {
      tidy5eItemCard(html, actor2);
    }
    html.find(".traits .toggle-traits").click(async (event) => {
      if (actor2.getFlag(CONSTANTS.MODULE_ID, "traitsExpanded")) {
        await actor2.unsetFlag(CONSTANTS.MODULE_ID, "traitsExpanded");
      } else {
        await actor2.setFlag(CONSTANTS.MODULE_ID, "traitsExpanded", true);
      }
    });
  }
  /* -------------------------------------------- */
  /**
   * Handle duplicate an existing Item entry from the Advancement.
   * @param {Event} event        The originating click event.
   * @returns {Promise<Item5e>}  The updated parent Item after the application re-renders.
   * @protected
   */
  async _onItemDuplicate(event) {
    event.preventDefault();
    const uuidToDuplicate = event.currentTarget.closest("[data-item-id]")?.dataset.itemId;
    if (!uuidToDuplicate)
      return;
    const item = this.actor.items.get(uuidToDuplicate);
    item.clone({ name: game.i18n.format("DOCUMENT.CopyOf", { name: item.name }) }, { save: true });
  }
  /* -------------------------------------------- */
  // add actions module
  async _renderInner(...args) {
    const html = await super._renderInner(...args);
    const actionsListApi = game.modules.get("character-actions-list-5e")?.api;
    let injectVehicleSheet;
    if (game.modules.get("character-actions-list-5e")?.active)
      injectVehicleSheet = game.settings.get("character-actions-list-5e", "inject-vehicles");
    try {
      if (game.modules.get("character-actions-list-5e")?.active && injectVehicleSheet) {
        const actionsTabButton = $(
          '<a class="item" data-tab="actions">' + game.i18n.localize(`DND5E.ActionPl`) + "</a>"
        );
        const tabs = html.find('.tabs[data-group="primary"]');
        tabs.prepend(actionsTabButton);
        const sheetBody = html.find(".sheet-body");
        const actionsTab = $(`<div class="tab actions" data-group="primary" data-tab="actions"></div>`);
        const actionsLayout = $(`<div class="list-layout"></div>`);
        actionsTab.append(actionsLayout);
        sheetBody.prepend(actionsTab);
        const actionsTabHtml = $(await actionsListApi.renderActionsList(this.actor));
        actionsLayout.html(actionsTabHtml);
      }
    } catch (e) {
    }
    return html;
  }
}
async function editProtection(app, html, data) {
  let actor2 = app.actor;
  if (!actor2.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
    let itemContainer = html.find(".inventory-list.items-list");
    html.find(".inventory-list .items-header").each(function() {
      if ($(this).next(".item-list").find("li").length - $(this).next(".item-list").find("li.items-footer").length == 0) {
        $(this).next(".item-list").remove();
        $(this).remove();
      }
    });
    html.find(".inventory-list .items-footer").hide();
    html.find(".inventory-list .item-control.item-delete").remove();
    html.find(".inventory-list .item-control.item-duplicate").remove();
    html.find(".effects .effect-control.effect-delete").remove();
    html.find(".effects .effect-control.effect-duplicate").remove();
    itemContainer.each(function() {
      if ($(this).children().length < 1) {
        $(this).append(`<span class="notice">This section is empty. Unlock the sheet to edit.</span>`);
      }
    });
  }
}
__name(editProtection, "editProtection");
async function toggleTraitsList(app, html, data) {
  html.find(".traits:not(.always-visible):not(.expanded) .form-group.inactive").addClass("trait-hidden").hide();
  let visibleTraits = html.find(".traits .form-group:not(.trait-hidden)");
  for (let i = 0; i < visibleTraits.length; i++) {
    if (i % 2 != 0) {
      visibleTraits[i].classList.add("even");
    }
  }
}
__name(toggleTraitsList, "toggleTraitsList");
async function abbreviateCurrency(app, html, data) {
  html.find(".currency .currency-item label").each(function() {
    let currency = $(this).data("denom").toUpperCase();
    let abbr = game.i18n.localize(`DND5E.CurrencyAbbr${currency}`);
    $(this).html(abbr);
  });
}
__name(abbreviateCurrency, "abbreviateCurrency");
async function setSheetClasses(app, html, data) {
  if (game.settings.get(CONSTANTS.MODULE_ID, "rightClickDisabled")) {
    if (game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
      html.find(".tidy5e-sheet.tidy5e-vehicle .grid-layout .items-list").addClass("alt-context");
    } else {
      html.find(".tidy5e-sheet.tidy5e-vehicle .items-list").addClass("alt-context");
    }
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "classicControlsEnabled")) {
    html.find(".tidy5e-sheet.tidy5e-vehicle .items-header-controls").remove();
  }
  if (!game.settings.get(CONSTANTS.MODULE_ID, "restingForNpcsEnabled")) {
    html.find(".tidy5e-sheet.tidy5e-vehicle .rest-container").remove();
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "npc" || game.settings.get(CONSTANTS.MODULE_ID, "portraitStyle") == "all") {
    html.find(".tidy5e-sheet.tidy5e-vehicle .profile").addClass("roundPortrait");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderVehicle") > 0) {
    $(".system-dnd5e").get(0).style.setProperty("--vehicle-border", game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayBorderVehicle") + "px");
  } else {
    $(".system-dnd5e").get(0).style.removeProperty("--vehicle-border");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpOverlayDisabledVehicle")) {
    html.find(".tidy5e-sheet.tidy5e-vehicle .profile").addClass("disable-hp-overlay");
  }
  if (game.settings.get(CONSTANTS.MODULE_ID, "hpBarDisabled")) {
    html.find(".tidy5e-sheet.tidy5e-vehicle .profile").addClass("disable-hp-bar");
  }
  $(".info-card-hint .key").html(game.settings.get(CONSTANTS.MODULE_ID, "itemCardsFixKey"));
  applyColorPickerCustomization(html);
}
__name(setSheetClasses, "setSheetClasses");
function Tidy5eSheetVehicleInitialize() {
  Actors.registerSheet("dnd5e", Tidy5eVehicle, {
    types: ["vehicle"],
    makeDefault: true,
    label: "TIDY5E.Tidy5eVehicle"
  });
}
__name(Tidy5eSheetVehicleInitialize, "Tidy5eSheetVehicleInitialize");
Hooks.on("renderTidy5eVehicle", (app, html, data) => {
  setSheetClasses(app, html);
  editProtection(app, html);
  toggleTraitsList(app, html);
  abbreviateCurrency(app, html);
  applyLazyMoney(app, html, data);
  if (game.user.isGM) {
    if (!game.settings.get(CONSTANTS.MODULE_ID, "enablePermanentUnlockOnVehicleIfYouAreGM")) {
      applyLocksVehicleSheet(app, html);
    } else {
      if (!app.actor?.getFlag(CONSTANTS.MODULE_ID, "allow-edit")) {
        app.actor?.setFlag(CONSTANTS.MODULE_ID, "allow-edit", true);
      }
    }
  } else {
    applyLocksVehicleSheet(app, html);
  }
});
Hooks.once("init", async () => {
  Tidy5eUserSettings.init();
  debug(`module | init | start`);
  preloadTidy5eHandlebarsTemplates();
  Tidy5eSheetInitialize();
  Tidy5eSheetNPCInitialize();
  Tidy5eSheetVehicleInitialize();
  Tidy5eSheetItemInitialize();
  debug(`module | init | end`);
});
Hooks.once("ready", async (app, html, data) => {
  debug(`module | ready | start`);
  if (!game.modules.get("colorsettings")?.active && game.user?.isGM) {
    let word = "install and activate";
    if (game.modules.get("colorsettings"))
      word = "activate";
    const errorText = `module | I'ts advisable to install the 'colorsettings' module for a better behaviour. Please ${word} it.`.replace(
      "<br>",
      "\n"
    );
    warn(errorText);
  }
  debug(`module | ready | end`);
});
Hooks.on("renderActorSheet", (app, html, data) => {
  debug(`module | renderActorSheet | start`);
  if (!isEmptyObject(app.actor.system?.attributes?.init?.bonus) && !is_real_number(Number(app.actor.system.attributes.init.bonus))) {
    app.actor.update({
      "system.attributes.init.bonus": 0
    });
    warn(
      `module | renderActorSheet | Patch 'system.attributes.init.bonus' for value ${app.actor.system?.attributes?.init?.bonus}`
    );
  }
  debug(`module | renderActorSheet | end`);
});
Hooks.on(`dnd5e.restCompleted`, (actorEntity, data) => {
  Tidy5eExhaustionDnd5eRestCompleted(actorEntity, data);
});
Hooks.on("applyActiveEffect", (actor2, effect, options) => {
  Tidy5eSheetApplyActiveEffect(actor2, effect);
});
Hooks.on(`createActiveEffect`, (activeEffect, _config, options) => {
  Tidy5eSheetCreateActiveEffect(activeEffect, _config);
  Tidy5eExhaustionCreateActiveEffect(activeEffect);
});
Hooks.on("updateActiveEffect", (activeEffect, _config, options) => {
  Tidy5eSheetUpdateActiveEffect(activeEffect, _config);
});
Hooks.on(`deleteActiveEffect`, (activeEffect, _config, options) => {
  Tidy5eSheetDeleteActiveEffect(activeEffect, _config);
  Tidy5eExhaustionDeleteActiveEffect(activeEffect);
});
Hooks.on("renderTidy5eUserSettings", () => {
  Tidy5eSettingsGmOnlySetup();
});
Hooks.on("dnd5e.preItemUsageConsumption", (item, config, options) => {
  Tidy5eHBUpcastFreeSpellsDnd5ePreItemUsageConsumption(item, config);
});
Hooks.on("renderAbilityUseDialog", (app, html, options) => {
  Tidy5eSheetRenderAbilityUseDialog(app, html);
});
//# sourceMappingURL=module.js.map
