const CONSTANTS = {
	MODULE_ID: `tidy5e-sheet`
};
CONSTANTS.PATH = `modules/${CONSTANTS.ID}/`;
export default CONSTANTS;
